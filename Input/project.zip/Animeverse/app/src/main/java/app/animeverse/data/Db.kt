package app.animeverse.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity data class CatalogItem(
    @PrimaryKey val id: String, val type: String, val title: String, val original: String?,
    val year: Int?, val poster: String?, val score: Double?, val synopsis: String?,
    val anilistId: Int?, val tmdbId: Int?
)
@Entity data class Favorite(@PrimaryKey val mediaId: String, val addedAt: Long)
@Entity data class WatchProgress(@PrimaryKey val url: String, val title: String, val format: String, val positionMs: Long, val durationMs: Long, val updatedAt: Long)
@Entity data class SearchHistory(@PrimaryKey val query: String, val at: Long)

@Dao interface CatalogDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(items: List<CatalogItem>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun addFav(f: Favorite)
    @Query("DELETE FROM Favorite WHERE mediaId = :id") suspend fun removeFav(id: String)
    @Query("SELECT mediaId FROM Favorite") fun favIds(): Flow<List<String>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun addSearch(s: SearchHistory)
    @Query("SELECT * FROM CatalogItem WHERE title LIKE '%' || :q || '%' OR original LIKE '%' || :q || '%' LIMIT 30")
    suspend fun local(q: String): List<CatalogItem>
    @Query("SELECT m.* FROM CatalogItem m JOIN Favorite f ON f.mediaId = m.id ORDER BY f.addedAt DESC") fun favorites(): Flow<List<CatalogItem>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveProgress(p: WatchProgress)
    @Query("SELECT * FROM WatchProgress WHERE url = :url") suspend fun progress(url: String): WatchProgress?
    @Query("SELECT * FROM WatchProgress ORDER BY updatedAt DESC LIMIT 20") fun recentProgress(): Flow<List<WatchProgress>>
    @Query("DELETE FROM WatchProgress") suspend fun clearProgress()
    @Query("SELECT `query` FROM SearchHistory ORDER BY `at` DESC LIMIT 10") fun recentSearches(): Flow<List<String>>
    @Query("DELETE FROM SearchHistory") suspend fun clearSearches()
}

@Database(entities = [CatalogItem::class, Favorite::class, SearchHistory::class, WatchProgress::class], version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() { abstract fun dao(): CatalogDao }
