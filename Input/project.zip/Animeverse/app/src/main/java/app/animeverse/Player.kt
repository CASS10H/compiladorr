package app.animeverse

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.*
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import app.animeverse.engine.Source
import kotlinx.coroutines.delay

data class PlayerPrefs(val sub: String = "pt", val audio: String = "ja", val speed: Float = 1f)

private data class Opt(val label: String, val selected: Boolean, val onClick: () -> Unit)

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

private fun trackLabel(type: Int, f: Format): String = when {
    type == C.TRACK_TYPE_VIDEO -> if (f.height > 0) "${f.height}p" else "?"
    else -> f.label ?: f.language?.uppercase() ?: "#"
}

private fun trackOptions(player: ExoPlayer, type: Int, noneLabel: String, bump: () -> Unit): List<Opt> {
    val params = player.trackSelectionParameters
    val groups = player.currentTracks.groups.filter { it.type == type }
    val textOff = type == C.TRACK_TYPE_TEXT && type in params.disabledTrackTypes
    val hasOverride = groups.any { params.overrides.containsKey(it.mediaTrackGroup) }
    val list = mutableListOf(Opt(noneLabel, if (type == C.TRACK_TYPE_TEXT) textOff else !hasOverride && !textOff) {
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .clearOverridesOfType(type).setTrackTypeDisabled(type, type == C.TRACK_TYPE_TEXT).build()
        bump()
    })
    groups.forEach { g ->
        for (j in 0 until g.length) if (g.isTrackSupported(j)) {
            list += Opt(trackLabel(type, g.getTrackFormat(j)), g.isTrackSelected(j) && !textOff) {
                player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                    .setTrackTypeDisabled(type, false).setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, j)).build()
                bump()
            }
        }
    }
    return list
}

@Composable
private fun MenuSection(title: Int, opts: List<Opt>) {
    Text(stringResource(title), Modifier.padding(top = 12.dp), style = MaterialTheme.typography.titleSmall, color = Purple)
    opts.forEach { o -> TextButton(o.onClick) { Text((if (o.selected) "✓ " else "    ") + o.label) } }
    if (opts.size <= 1) Text(stringResource(R.string.no_tracks), style = MaterialTheme.typography.bodySmall)
}

/** Reproduz queue[0] com fallback de fonte, retomada, progresso a cada 5 s, menu de faixas, velocidade e paisagem. */
@Composable
fun PlayerScreen(queue: List<Source>, startMs: Long, onProgress: (Source, Long, Long) -> Unit,
                 prefs: PlayerPrefs = PlayerPrefs(),
                 onPrev: (() -> Unit)? = null, onNext: (() -> Unit)? = null, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var index by remember { mutableIntStateOf(0) }
    val idx by rememberUpdatedState(index)
    var tick by remember { mutableIntStateOf(0) }
    var menu by remember { mutableStateOf(false) }
    var landscape by remember { mutableStateOf(false) }
    var speed by remember(prefs) { mutableFloatStateOf(prefs.speed) }
    val player = remember { ExoPlayer.Builder(ctx).build() }
    BackHandler(onBack = onBack)
    LaunchedEffect(speed) { player.setPlaybackSpeed(speed) }
    LaunchedEffect(prefs) {
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setPreferredAudioLanguage(prefs.audio)
            .setPreferredTextLanguage(prefs.sub.takeIf { it != "off" })
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, prefs.sub == "off").build()
    }
    DisposableEffect(Unit) {
        val act = ctx.findActivity()
        val ctrl = act?.let { WindowCompat.getInsetsController(it.window, it.window.decorView) }
        ctrl?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        ctrl?.hide(WindowInsetsCompat.Type.systemBars())
        onDispose {
            ctrl?.show(WindowInsetsCompat.Type.systemBars())
            act?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }
    DisposableEffect(index) {
        val l = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) { if (index + 1 < queue.size) index++ else onBack() }
            override fun onTracksChanged(tracks: Tracks) { tick++ }
        }
        player.addListener(l)
        player.setMediaItem(MediaItem.fromUri(Uri.parse(queue[index].url)))
        if (index == 0 && startMs > 0) player.seekTo(startMs)
        player.prepare(); player.playWhenReady = true
        onDispose { player.removeListener(l) }
    }
    LaunchedEffect(Unit) {
        while (true) { delay(5000); if (player.duration > 0) onProgress(queue[idx], player.currentPosition, player.duration) }
    }
    DisposableEffect(Unit) {
        onDispose { if (player.duration > 0) onProgress(queue[idx], player.currentPosition, player.duration); player.release() }
    }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView({ PlayerView(it).apply { this.player = player } }, Modifier.fillMaxSize())
        Row(Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding(), verticalAlignment = Alignment.CenterVertically) {
            onPrev?.let { TextButton(it) { Text("⏮") } }
            onNext?.let { TextButton(it) { Text("⏭") } }
            Spacer(Modifier.weight(1f))
            TextButton({ menu = true }) { Text("⚙") }
            TextButton({
                landscape = !landscape
                ctx.findActivity()?.requestedOrientation =
                    if (landscape) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            }) { Text("⟳") }
        }
    }
    if (menu) {
        val none = stringResource(R.string.subs_off); val auto = stringResource(R.string.quality_auto)
        AlertDialog(
            onDismissRequest = { menu = false },
            confirmButton = { TextButton({ menu = false }) { Text(stringResource(R.string.close)) } },
            text = {
                val subs = remember(tick) { trackOptions(player, C.TRACK_TYPE_TEXT, none) { tick++ } }
                val audio = remember(tick) { trackOptions(player, C.TRACK_TYPE_AUDIO, auto) { tick++ } }
                val video = remember(tick) { trackOptions(player, C.TRACK_TYPE_VIDEO, auto) { tick++ } }
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    MenuSection(R.string.subs_title, subs)
                    MenuSection(R.string.audio_title, audio)
                    MenuSection(R.string.quality_title, video)
                    Text(stringResource(R.string.speed_title), Modifier.padding(top = 12.dp), style = MaterialTheme.typography.titleSmall, color = Purple)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(0.5f, 1f, 1.5f, 2f).forEach { v -> FilterChip(speed == v, { speed = v }, { Text("${v}x") }) }
                    }
                }
            }
        )
    }
}
