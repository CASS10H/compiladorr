package app.animeverse.engine

import kotlinx.coroutines.*
import java.util.concurrent.ConcurrentHashMap

data class MediaQuery(val title: String, val originalTitle: String? = null, val year: Int? = null, val season: Int? = null, val episode: Int? = null)
enum class StreamFormat { HLS, DASH, MP4 }
data class Source(val provider: String, val url: String, val format: StreamFormat, val qualityP: Int, val language: String, val subtitles: List<String> = emptyList(), val available: Boolean = true)
data class ProviderError(val provider: String, val reason: String)
data class Discovery(val sources: List<Source>, val errors: List<ProviderError>)

interface PlaybackProvider {
    val id: String
    suspend fun findSources(query: MediaQuery): List<Source>
    suspend fun isAvailable(source: Source): Boolean = true
}

/** Provedor de demonstração: só responde à busca "demo" e usa vídeos públicos de teste (Big Buck Bunny, Blender Foundation, CC-BY). */
class DemoProvider : PlaybackProvider {
    override val id = "Demo (Big Buck Bunny)"
    override suspend fun findSources(query: MediaQuery): List<Source> =
        if (!query.title.contains("demo", true)) emptyList() else listOf(
            Source(id, "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8", StreamFormat.HLS, 720, "en"),
            Source(id, "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4", StreamFormat.MP4, 720, "en")
        )
}

class PlaybackProviderManager(private val timeoutMs: Long = 8000) {
    private val providers = mutableListOf<PlaybackProvider>()
    private val cache = ConcurrentHashMap<MediaQuery, List<Source>>()
    fun register(p: PlaybackProvider) { providers += p }
    fun clearCache() = cache.clear()

    suspend fun discover(q: MediaQuery): Discovery {
        cache[q]?.let { return Discovery(it, emptyList()) }
        val errors = ConcurrentHashMap.newKeySet<ProviderError>()
        val all = coroutineScope {
            providers.map { p ->
                async {
                    try { withTimeout(timeoutMs) { p.findSources(q).filter { p.isAvailable(it) } } }
                    catch (e: TimeoutCancellationException) { errors += ProviderError(p.id, "timeout"); emptyList() }
                    catch (e: CancellationException) { throw e }
                    catch (e: Exception) { errors += ProviderError(p.id, e.message ?: "erro"); emptyList() }
                }
            }.awaitAll().flatten()
        }
        val result = all.distinctBy { it.url }.sortedWith(compareByDescending<Source> { it.available }.thenByDescending { it.qualityP })
        if (result.isNotEmpty()) cache[q] = result
        return Discovery(result, errors.toList())
    }
}
