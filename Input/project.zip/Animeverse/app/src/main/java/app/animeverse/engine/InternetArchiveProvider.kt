package app.animeverse.engine

import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Busca vídeos hospedados pelo Internet Archive. Só aceita itens cuja licença
 * esteja explicitamente identificada como domínio público ou Creative Commons
 * permissiva (CC0, CC BY, CC BY-SA ou Public Domain Mark).
 */
class InternetArchiveProvider(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .callTimeout(12, TimeUnit.SECONDS)
        .connectTimeout(6, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build(),
    private val maxItems: Int = 8
) : PlaybackProvider {
    override val id: String = "Internet Archive (licenças abertas)"

    override suspend fun findSources(query: MediaQuery): List<Source> {
        val title = query.title.trim()
        if (title.length < 2) return emptyList()

        val searchUrl = "https://archive.org/advancedsearch.php".toHttpUrl().newBuilder()
            .addQueryParameter("q", "title:\"${title.replace("\\", "\\\\").replace("\"", "\\\"")}\" AND mediatype:movies")
            .addQueryParameter("fl[]", "identifier")
            .addQueryParameter("fl[]", "title")
            .addQueryParameter("rows", maxItems.toString())
            .addQueryParameter("page", "1")
            .addQueryParameter("output", "json")
            .addQueryParameter("sort[]", "downloads desc")
            .build()

        val search = getJson(searchUrl.toString())
        val docs = search.optJSONObject("response")?.optJSONArray("docs") ?: return emptyList()
        return coroutineScope {
            (0 until docs.length()).mapNotNull { docs.optJSONObject(it) }.map { doc ->
                async(Dispatchers.IO) { runCatching { sourcesFor(doc) }.getOrDefault(emptyList()) }
            }.awaitAll().flatten().distinctBy { it.url }.sortedByDescending { it.qualityP }
        }
    }

    private fun sourcesFor(doc: JSONObject): List<Source> {
        val identifier = doc.optString("identifier").takeIf { it.isNotBlank() } ?: return emptyList()
        val metadata = getJson("https://archive.org/metadata/${Uri.encode(identifier)}")
        val meta = metadata.optJSONObject("metadata") ?: return emptyList()
        val license = acceptedLicense(meta.optString("licenseurl")) ?: return emptyList()
        val files = metadata.optJSONArray("files") ?: return emptyList()
        val language = meta.optString("language").ifBlank { "und" }.lowercase().take(12)
        val results = mutableListOf<Source>()

        for (j in 0 until files.length()) {
            val file = files.optJSONObject(j) ?: continue
            val name = file.optString("name")
            val format = file.optString("format")
            if (name.isBlank() || file.optString("private") == "true") continue
            if (!name.endsWith(".mp4", true) && !name.endsWith(".m4v", true)) continue
            if (format.isNotBlank() && !format.contains("MPEG4", true) && !format.contains("MP4", true) && !name.endsWith(".m4v", true)) continue

            val height = file.optString("height").toIntOrNull()
                ?: Regex("(?i)(?:^|[._ -])(2160|1440|1080|720|576|480|360)p(?:[._ -]|$)")
                    .find(name)?.groupValues?.getOrNull(1)?.toIntOrNull()
                ?: 480
            val encodedName = Uri.encode(name)
            val url = "https://archive.org/download/${Uri.encode(identifier)}/$encodedName"
            results += Source(
                provider = id,
                url = url,
                format = StreamFormat.MP4,
                qualityP = height.coerceIn(144, 4320),
                language = language,
                licenseUrl = license
            )
        }
        return results
    }

    private fun getJson(url: String): JSONObject {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "Animeverse/1.0 (Android; open-media search)")
            .header("Accept", "application/json")
            .get()
            .build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IOException("HTTP ${response.code} em ${response.request.url.host}")
            val body = response.body?.string() ?: throw IOException("Resposta vazia")
            return JSONObject(body)
        }
    }

    private fun acceptedLicense(licenseUrl: String): String? {
        val normalized = licenseUrl.lowercase().trim()
        val allowed = listOf(
            "creativecommons.org/publicdomain/zero/1.0",
            "creativecommons.org/publicdomain/mark/1.0",
            "creativecommons.org/licenses/by/4.0",
            "creativecommons.org/licenses/by-sa/4.0",
            "creativecommons.org/licenses/by/3.0",
            "creativecommons.org/licenses/by-sa/3.0"
        )
        if (allowed.any(normalized::contains)) return licenseUrl
        return null
    }
}
