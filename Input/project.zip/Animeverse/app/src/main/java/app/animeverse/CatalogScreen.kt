package app.animeverse

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import app.animeverse.data.CatalogItem
import app.animeverse.data.Episode
import app.animeverse.data.Filters
import app.animeverse.data.WatchProgress
import app.animeverse.engine.*
import coil.compose.AsyncImage
import kotlinx.coroutines.launch

@Composable
fun App(manager: PlaybackProviderManager, vm: CatalogViewModel = viewModel()) {
    val scope = rememberCoroutineScope()
    val ui by vm.state.collectAsState()
    val favs by vm.favIds.collectAsState(emptyList())
    val library by vm.favorites.collectAsState(emptyList())
    val recent by vm.recentProgress.collectAsState(emptyList())
    val searches by vm.recentSearches.collectAsState(emptyList())
    val settings by vm.settings.collectAsState()
    val home by vm.home.collectAsState()
    var tab by remember { mutableIntStateOf(1) }
    var filter by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }
    var discovery by remember { mutableStateOf<Discovery?>(null) }
    var discTitle by remember { mutableStateOf("") }
    var queue by remember { mutableStateOf<List<Source>>(emptyList()) }
    var startMs by remember { mutableLongStateOf(0L) }
    var playTitle by remember { mutableStateOf("") }
    var playing by remember { mutableStateOf(false) }
    var detail by remember { mutableStateOf<CatalogItem?>(null) }
    var watchItem by remember { mutableStateOf<CatalogItem?>(null) }
    var epList by remember { mutableStateOf<List<Episode>>(emptyList()) }
    var epIndex by remember { mutableIntStateOf(0) }
    var fx by remember { mutableStateOf(Filters()) }
    var showFilters by remember { mutableStateOf(false) }

    fun watch(item: CatalogItem, eps: List<Episode>, i: Int) {
        scope.launch {
            val ep = eps.getOrNull(i)
            val d = manager.discover(MediaQuery(item.title, item.original, item.year, ep?.season, ep?.number))
            discovery = d; discTitle = item.title
            if (d.sources.isEmpty()) { playing = false; detail = null; tab = 2; return@launch }
            startMs = vm.resumeAt(d.sources.first().url)
            playTitle = item.title + (ep?.let { " · S${it.season}E${it.number}" } ?: "")
            watchItem = item; epList = eps; epIndex = i; queue = d.sources; playing = true
        }
    }
    if (playing && queue.isNotEmpty()) {
        val t = playTitle
        val hasEps = epList.isNotEmpty()
        key(queue, epIndex) {
            PlayerScreen(queue, startMs, { s, p, d -> vm.saveProgress(WatchProgress(s.url, t, s.format.name, p, d, System.currentTimeMillis())) },
                prefs = PlayerPrefs(settings.sub, settings.audio, settings.speed),
                onPrev = if (hasEps && epIndex > 0) ({ watch(watchItem!!, epList, epIndex - 1) }) else null,
                onNext = if (hasEps && epIndex < epList.lastIndex) ({ watch(watchItem!!, epList, epIndex + 1) }) else null) { playing = false }
        }
        return
    }
    detail?.let { item ->
        DetailsScreen(item, item.id in favs, { vm.toggleFav(item.id, item.id in favs) }, { detail = null }) { eps, i -> watch(item, eps, i) }
        return
    }
    fun find(q: MediaQuery, title: String) { scope.launch { discTitle = title; discovery = manager.discover(q); tab = 2 } }
    fun play(first: Source, all: List<Source>, title: String) {
        scope.launch { epList = emptyList(); startMs = vm.resumeAt(first.url); playTitle = title; queue = listOf(first) + all.filter { it != first }; playing = true }
    }
    LaunchedEffect(Unit) { if (home.shelves.isEmpty()) vm.loadHome() }
    LaunchedEffect(tab) { if (tab == 1 && !ui.searched && !ui.loading) vm.discover(fx.copy(type = filter)) }
    val tabs = listOf(R.string.tab_home to "⌂", R.string.tab_explore to "⌕", R.string.tab_watch to "▶", R.string.tab_library to "★", R.string.tab_profile to "☺")

    Scaffold(bottomBar = {
        NavigationBar {
            tabs.forEachIndexed { i, (label, icon) ->
                NavigationBarItem(tab == i, { tab = i }, { Text(icon) }, label = { Text(stringResource(label)) })
            }
        }
    }) { pad ->
        Column(Modifier.padding(pad).statusBarsPadding().padding(horizontal = 16.dp)) {
            Text("Animeverse", style = MaterialTheme.typography.headlineMedium, color = Purple)
            when (tab) {
                0 -> HomeScreen(home, recent, searches, { detail = it },
                    { r -> play(Source("", r.url, StreamFormat.valueOf(r.format), 0, ""), emptyList(), r.title) },
                    { q -> query = q; vm.search(q); tab = 1 }, { vm.loadHome() })
                1 -> Column {
                    Row(Modifier.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(query, { query = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text(stringResource(R.string.catalog_hint)) })
                        Spacer(Modifier.width(8.dp))
                        Button({ vm.search(query.trim()) }, enabled = query.isNotBlank()) { Text(stringResource(R.string.search)) }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(null to R.string.filter_all, "anime" to R.string.filter_anime, "movie" to R.string.filter_movie, "series" to R.string.filter_series).forEach { (f, l) ->
                            FilterChip(filter == f, { filter = f; if (query.isBlank()) vm.discover(fx.copy(type = f, status = if (f == "anime") fx.status else null)) }, { Text(stringResource(l)) })
                        }
                    }
                    TextButton({ showFilters = !showFilters }) { Text(stringResource(R.string.filters_title)) }
                    if (showFilters) ExploreFilters(fx, filter) { n ->
                        fx = n.copy(status = if (filter == "anime") n.status else null)
                        if (query.isBlank()) vm.discover(fx.copy(type = filter))
                    }
                    if (ui.loading) CircularProgressIndicator(color = Purple)
                    if (ui.offline) Text(stringResource(R.string.offline_cache), color = Purple)
                    if (ui.tmdbMissingKey) Text(stringResource(R.string.tmdb_key_missing))
                    val minS = fx.minScore; val yr = fx.year
                    val shown = ui.items.filter { (filter == null || it.type == filter) && (yr == null || it.year == yr) && (minS == null || (it.score ?: 0.0) >= minS) }
                    if (ui.searched && shown.isEmpty() && !ui.loading) Text(stringResource(R.string.no_results))
                    LazyColumn { items(shown, key = { it.id }) { item ->
                        ItemCard(item, item.id in favs, { vm.toggleFav(item.id, item.id in favs) }, { detail = item })
                    } }
                }
                2 -> LazyColumn {
                    item { Text("Busca automática em fontes abertas. A disponibilidade depende do título e da licença do vídeo.", style = MaterialTheme.typography.bodySmall) }
                    item { TextButton({ find(MediaQuery("demo"), "Demo") }) { Text(stringResource(R.string.demo_button)) } }
                    val d = discovery
                    if (d == null) item { Text(stringResource(R.string.empty_sources_hint)) }
                    else if (d.sources.isEmpty()) {
                        item { Text(stringResource(R.string.no_sources)) }
                        items(d.errors, key = { it.provider }) { error ->
                            Text("${error.provider}: ${error.reason}", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    else {
                        item { Text("${stringResource(R.string.sources_found)}: $discTitle", style = MaterialTheme.typography.titleMedium) }
                        items(d.sources, key = { it.url }) { s ->
                            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(s.provider)
                                        Text("${s.format} · ${s.qualityP}p · ${s.language}", color = Purple)
                                        s.licenseUrl?.let { Text("Licença aberta verificada", style = MaterialTheme.typography.labelSmall) }
                                    }
                                    Button({ play(s, d.sources, discTitle) }) { Text(stringResource(R.string.play)) }
                                }
                            }
                        }
                    }
                }
                3 -> LazyColumn {
                    if (library.isEmpty()) item { Text(stringResource(R.string.empty_library)) }
                    items(library, key = { it.id }) { item ->
                        ItemCard(item, true, { vm.toggleFav(item.id, true) }, { detail = item })
                    }
                }
                else -> ProfileScreen(settings, vm, manager)
            }
        }
    }
}

@Composable
fun ItemCard(item: CatalogItem, fav: Boolean, onFav: () -> Unit, onSources: () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(Modifier.padding(8.dp)) {
            AsyncImage(item.poster, item.title, Modifier.width(84.dp).height(120.dp).clip(MaterialTheme.shapes.medium), contentScale = ContentScale.Crop)
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Text(item.title, style = MaterialTheme.typography.titleSmall, maxLines = 2)
                Text("${item.type.uppercase()} · ${item.year ?: "—"} · ★ ${item.score?.let { "%.1f".format(it) } ?: "—"}", color = Purple)
                Text(item.synopsis.orEmpty(), maxLines = 3, style = MaterialTheme.typography.bodySmall)
                Row {
                    TextButton(onFav) { Text(stringResource(if (fav) R.string.unfavorite else R.string.favorite)) }
                    TextButton(onSources) { Text(stringResource(R.string.details)) }
                }
            }
        }
    }
}
