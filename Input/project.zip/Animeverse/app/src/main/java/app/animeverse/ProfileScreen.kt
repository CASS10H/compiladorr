package app.animeverse

import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.os.LocaleListCompat
import app.animeverse.data.CatalogApi
import app.animeverse.data.Settings
import app.animeverse.engine.PlaybackProviderManager
import coil.annotation.ExperimentalCoilApi
import coil.imageLoader

@Composable
private fun Section(title: Int) =
    Text(stringResource(title), Modifier.padding(top = 16.dp, bottom = 4.dp), style = MaterialTheme.typography.titleMedium, color = Purple)

@Composable
private fun Chips(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (key, label) -> FilterChip(selected == key, { onSelect(key) }, { Text(label) }) }
    }
}

@OptIn(ExperimentalCoilApi::class)
@Composable
fun ProfileScreen(s: Settings, vm: CatalogViewModel, manager: PlaybackProviderManager) {
    val ctx = LocalContext.current
    fun cacheMb() = (ctx.imageLoader.diskCache?.size ?: 0L) / 1_000_000
    var mb by remember { mutableLongStateOf(cacheMb()) }
    var locale by remember { mutableStateOf(AppCompatDelegate.getApplicationLocales().toLanguageTags()) }
    val langs = listOf("pt-BR" to "Português", "en" to "English", "ja" to "日本語")
    val short = langs.map { it.first.take(2) to it.second }
    Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 16.dp)) {
        Section(R.string.lang_ui)
        Chips(listOf("" to stringResource(R.string.lang_system)) + langs, locale) {
            locale = it; AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(it))
        }
        Section(R.string.subs_title)
        Chips(listOf("off" to stringResource(R.string.subs_off)) + short, s.sub) { vm.setSub(it) }
        Section(R.string.audio_title)
        Chips(short, s.audio) { vm.setAudio(it) }
        Section(R.string.speed_title)
        Chips(listOf("0.5" to "0.5x", "1.0" to "1x", "1.5" to "1.5x", "2.0" to "2x"), s.speed.toString()) { vm.setSpeed(it.toFloat()) }
        Section(R.string.appearance_title)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.amoled), Modifier.weight(1f))
            Switch(s.amoled, { vm.setAmoled(it) })
        }
        Section(R.string.cache_title)
        Text(stringResource(R.string.cache_size, mb))
        Row {
            Button({
                ctx.imageLoader.memoryCache?.clear(); ctx.imageLoader.diskCache?.clear()
                CatalogApi.clearCache(); manager.clearCache(); mb = cacheMb()
            }) { Text(stringResource(R.string.clear_cache)) }
            Spacer(Modifier.width(8.dp))
            OutlinedButton({ vm.clearHistory() }) { Text(stringResource(R.string.clear_history)) }
        }
        Text("Animeverse 0.9.0", Modifier.padding(top = 24.dp), style = MaterialTheme.typography.bodySmall)
    }
}
