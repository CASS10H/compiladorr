package app.animeverse

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import app.animeverse.data.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class UiState(val items: List<CatalogItem> = emptyList(), val loading: Boolean = false,
                   val offline: Boolean = false, val tmdbMissingKey: Boolean = false, val searched: Boolean = false)

data class HomeState(val shelves: List<Pair<String, List<CatalogItem>>> = emptyList(), val loading: Boolean = false)

class CatalogViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = Room.databaseBuilder(app, AppDatabase::class.java, "animeverse.db").fallbackToDestructiveMigration().build().dao()
    val state = MutableStateFlow(UiState())
    val home = MutableStateFlow(HomeState())

    fun loadHome() = viewModelScope.launch {
        if (home.value.loading) return@launch
        home.value = HomeState(home.value.shelves, true)
        val shelves = runCatching { CatalogApi.home() }.getOrDefault(emptyList())
        shelves.forEach { dao.upsert(it.second) }
        home.value = HomeState(if (shelves.isEmpty()) home.value.shelves else shelves, false)
    }

    fun discover(f: Filters) = viewModelScope.launch {
        state.value = UiState(loading = true)
        val r = CatalogApi.discover(f)
        if (r.items.isNotEmpty()) dao.upsert(r.items)
        state.value = UiState(items = r.items, offline = !r.anilistOk && !r.tmdbOk, tmdbMissingKey = r.tmdbMissingKey, searched = true)
    }
    private val settingsRepo = SettingsRepo(app)
    val settings = settingsRepo.flow.stateIn(viewModelScope, SharingStarted.Eagerly, Settings())
    fun setSub(v: String) = viewModelScope.launch { settingsRepo.update { this[SettingsRepo.SUB] = v } }
    fun setAudio(v: String) = viewModelScope.launch { settingsRepo.update { this[SettingsRepo.AUDIO] = v } }
    fun setSpeed(v: Float) = viewModelScope.launch { settingsRepo.update { this[SettingsRepo.SPEED] = v } }
    fun setAmoled(v: Boolean) = viewModelScope.launch { settingsRepo.update { this[SettingsRepo.AMOLED] = v } }
    val favIds = dao.favIds()
    val favorites = dao.favorites()
    val recentProgress = dao.recentProgress()
    val recentSearches = dao.recentSearches()
    fun saveProgress(p: WatchProgress) = viewModelScope.launch { dao.saveProgress(p) }
    suspend fun resumeAt(url: String): Long = dao.progress(url)?.takeIf { it.durationMs - it.positionMs > 10_000 }?.positionMs ?: 0L
    fun clearHistory() = viewModelScope.launch { dao.clearProgress(); dao.clearSearches() }

    fun search(q: String) = viewModelScope.launch {
        state.value = UiState(loading = true)
        dao.addSearch(SearchHistory(q, System.currentTimeMillis()))
        val r = CatalogApi.search(q)
        if (r.items.isNotEmpty()) dao.upsert(r.items)
        state.value = if (!r.anilistOk && !r.tmdbOk)
            UiState(items = dao.local(q), offline = true, tmdbMissingKey = r.tmdbMissingKey, searched = true)
        else UiState(items = r.items, tmdbMissingKey = r.tmdbMissingKey, searched = true)
    }

    fun toggleFav(id: String, isFav: Boolean) = viewModelScope.launch {
        if (isFav) dao.removeFav(id) else dao.addFav(Favorite(id, System.currentTimeMillis()))
    }
}
