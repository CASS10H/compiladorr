package app.animeverse.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("settings")

data class Settings(val sub: String = "pt", val audio: String = "ja", val speed: Float = 1f, val amoled: Boolean = false)

class SettingsRepo(private val ctx: Context) {
    companion object {
        val SUB = stringPreferencesKey("sub"); val AUDIO = stringPreferencesKey("audio")
        val SPEED = floatPreferencesKey("speed"); val AMOLED = booleanPreferencesKey("amoled")
    }
    val flow: Flow<Settings> = ctx.dataStore.data.map { p ->
        Settings(p[SUB] ?: "pt", p[AUDIO] ?: "ja", p[SPEED] ?: 1f, p[AMOLED] ?: false)
    }
    suspend fun update(block: MutablePreferences.() -> Unit) { ctx.dataStore.edit { it.block() } }
}
