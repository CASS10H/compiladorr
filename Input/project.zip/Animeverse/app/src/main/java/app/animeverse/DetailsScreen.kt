package app.animeverse

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import app.animeverse.data.*
import coil.compose.AsyncImage

@Composable
fun DetailsScreen(item: CatalogItem, fav: Boolean, onFav: () -> Unit, onBack: () -> Unit, onWatch: (List<Episode>, Int) -> Unit) {
    BackHandler(onBack = onBack)
    val movie = item.type == "movie"
    var seasons by remember { mutableStateOf<List<SeasonInfo>>(emptyList()) }
    var season by remember { mutableIntStateOf(1) }
    var episodes by remember { mutableStateOf<List<Episode>>(emptyList()) }
    var loading by remember { mutableStateOf(!movie) }
    var extra by remember { mutableStateOf<Extra?>(null) }
    LaunchedEffect(item.id) { extra = runCatching { CatalogApi.extra(item) }.getOrNull() }
    LaunchedEffect(item.id) {
        if (!movie) {
            seasons = runCatching { CatalogApi.seasons(item) }.getOrDefault(emptyList())
            season = seasons.firstOrNull()?.number ?: 1
            if (seasons.isEmpty()) loading = false
        }
    }
    LaunchedEffect(season, seasons) {
        if (!movie && seasons.isNotEmpty()) {
            loading = true
            episodes = runCatching { CatalogApi.episodes(item, season) }.getOrDefault(emptyList())
            loading = false
        }
    }
    val ex = extra
    LazyColumn(Modifier.statusBarsPadding().padding(16.dp)) {
        ex?.banner?.let { b ->
            item { AsyncImage(b, null, Modifier.fillMaxWidth().height(160.dp).padding(bottom = 8.dp).clip(MaterialTheme.shapes.medium), contentScale = ContentScale.Crop) }
        }
        item {
            Row {
                AsyncImage(item.poster, item.title, Modifier.width(120.dp).height(170.dp).clip(MaterialTheme.shapes.medium), contentScale = ContentScale.Crop)
                Column(Modifier.padding(start = 12.dp)) {
                    Text(item.title, style = MaterialTheme.typography.titleLarge, color = Purple)
                    item.original?.takeIf { it.isNotBlank() && it != item.title }?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                    Text("${item.type.uppercase()} · ${item.year ?: "—"} · ★ ${item.score?.let { "%.1f".format(it) } ?: "—"}")
                }
            }
        }
        item {
            Row(Modifier.padding(vertical = 8.dp)) {
                Button({ onWatch(if (movie) emptyList() else episodes, 0) }, enabled = movie || episodes.isNotEmpty()) { Text(stringResource(R.string.play)) }
                TextButton(onFav) { Text(stringResource(if (fav) R.string.unfavorite else R.string.favorite)) }
                TextButton(onBack) { Text(stringResource(R.string.back)) }
            }
        }
        ex?.let { e ->
            item {
                Column(Modifier.padding(vertical = 8.dp)) {
                    val parts = listOfNotNull(e.runtime?.let { stringResource(R.string.duration_fmt, it) }, e.genres.takeIf { it.isNotEmpty() }?.joinToString(" · "))
                    if (parts.isNotEmpty()) Text(parts.joinToString("  ·  "), color = Purple)
                    if (e.studios.isNotEmpty()) Text(stringResource(R.string.studio_fmt, e.studios.joinToString(", ")), style = MaterialTheme.typography.bodySmall)
                    if (e.cast.isNotEmpty()) Text(stringResource(if (item.type == "anime") R.string.characters_fmt else R.string.cast_fmt, e.cast.joinToString(", ")), style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item { Text(item.synopsis.orEmpty().replace(Regex("<[^>]*>"), ""), style = MaterialTheme.typography.bodyMedium) }
        if (!movie) {
            if (seasons.size > 1) item {
                LazyRow(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(seasons) { s -> FilterChip(season == s.number, { season = s.number }, { Text(stringResource(R.string.season_fmt, s.number)) }) }
                }
            }
            if (loading) item { CircularProgressIndicator(color = Purple) }
            else if (episodes.isEmpty()) item { Text(stringResource(R.string.no_episodes), Modifier.padding(top = 8.dp)) }
            else itemsIndexed(episodes) { i, ep ->
                Card(Modifier.fillMaxWidth().padding(vertical = 3.dp).clickable { onWatch(episodes, i) }) {
                    Column(Modifier.padding(12.dp)) {
                        Text(stringResource(R.string.episode_fmt, ep.number), color = Purple)
                        if (ep.name.isNotBlank()) Text(ep.name, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
