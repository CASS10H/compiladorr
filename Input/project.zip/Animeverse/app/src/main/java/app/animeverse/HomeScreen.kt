package app.animeverse

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import app.animeverse.data.CatalogItem
import app.animeverse.data.Filters
import app.animeverse.data.WatchProgress
import coil.compose.AsyncImage

private fun shelfTitle(key: String) = when (key) {
    "trending" -> R.string.shelf_trending; "anime" -> R.string.shelf_anime; "movies" -> R.string.shelf_movies
    "series" -> R.string.shelf_series; "releases" -> R.string.shelf_releases; else -> R.string.shelf_top
}

@Composable
fun HomeScreen(home: HomeState, recent: List<WatchProgress>, searches: List<String>, onOpen: (CatalogItem) -> Unit,
               onResume: (WatchProgress) -> Unit, onSearch: (String) -> Unit, onRetry: () -> Unit) {
    LazyColumn {
        home.shelves.firstOrNull()?.second?.firstOrNull()?.let { b ->
            item {
                Card(Modifier.fillMaxWidth().padding(vertical = 8.dp).clickable { onOpen(b) }) {
                    Box {
                        AsyncImage(b.poster, b.title, Modifier.fillMaxWidth().height(220.dp), contentScale = ContentScale.Crop)
                        Text(b.title, Modifier.align(Alignment.BottomStart).background(Color(0xAA000000)).padding(8.dp),
                            style = MaterialTheme.typography.titleMedium, color = Color.White)
                    }
                }
            }
        }
        if (home.loading) item { CircularProgressIndicator(color = Purple) }
        if (!home.loading && home.shelves.isEmpty()) item {
            Column { Text(stringResource(R.string.home_unavailable)); Button(onRetry) { Text(stringResource(R.string.retry)) } }
        }
        if (recent.isNotEmpty()) {
            item { Text(stringResource(R.string.continue_watching), style = MaterialTheme.typography.titleMedium) }
            items(recent, key = { it.url }) { r ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(r.title); Text("${if (r.durationMs > 0) r.positionMs * 100 / r.durationMs else 0}%", color = Purple)
                        }
                        Button({ onResume(r) }) { Text(stringResource(R.string.resume)) }
                    }
                }
            }
        }
        home.shelves.forEach { (key, list) ->
            item(key = key) {
                Column(Modifier.padding(top = 16.dp)) {
                    Text(stringResource(shelfTitle(key)), style = MaterialTheme.typography.titleMedium, color = Purple)
                    LazyRow(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(list, key = { it.id }) { it ->
                            Column(Modifier.width(110.dp).clickable { onOpen(it) }) {
                                AsyncImage(it.poster, it.title, Modifier.width(110.dp).height(160.dp).clip(MaterialTheme.shapes.medium), contentScale = ContentScale.Crop)
                                Text(it.title, maxLines = 2, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
        if (searches.isNotEmpty()) item { Text(stringResource(R.string.recent_searches), Modifier.padding(top = 16.dp), style = MaterialTheme.typography.titleMedium) }
        items(searches) { q -> TextButton({ onSearch(q) }) { Text(q) } }
    }
}

@Composable
private fun ChipRow(items: List<Pair<String, String>>, selected: String?, onPick: (String?) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEach { (k, label) -> FilterChip(selected == k, { onPick(if (selected == k) null else k) }, { Text(label) }) }
    }
}

@Composable
fun ExploreFilters(fx: Filters, type: String?, onChange: (Filters) -> Unit) {
    val now = java.time.Year.now().value
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        ChipRow(listOf("Action" to stringResource(R.string.g_action), "Comedy" to stringResource(R.string.g_comedy), "Drama" to stringResource(R.string.g_drama),
            "Fantasy" to stringResource(R.string.g_fantasy), "Romance" to stringResource(R.string.g_romance)), fx.genre) { onChange(fx.copy(genre = it)) }
        ChipRow((0..4).map { (now - it).toString() to (now - it).toString() }, fx.year?.toString()) { onChange(fx.copy(year = it?.toInt())) }
        ChipRow(listOf(6, 7, 8).map { it.toString() to "★ ≥ $it" }, fx.minScore?.toString()) { onChange(fx.copy(minScore = it?.toInt())) }
        if (type == "anime") ChipRow(listOf("RELEASING" to stringResource(R.string.st_releasing), "FINISHED" to stringResource(R.string.st_finished),
            "NOT_YET_RELEASED" to stringResource(R.string.st_upcoming)), fx.status) { onChange(fx.copy(status = it)) }
        ChipRow(listOf("pop" to stringResource(R.string.sort_pop), "rating" to stringResource(R.string.sort_rating), "date" to stringResource(R.string.sort_date)), fx.sort) {
            onChange(fx.copy(sort = it ?: "pop"))
        }
    }
}
