package app.animeverse.data

import app.animeverse.BuildConfig
import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

data class CatalogResult(val items: List<CatalogItem>, val anilistOk: Boolean, val tmdbOk: Boolean, val tmdbMissingKey: Boolean)

data class Filters(val type: String? = null, val genre: String? = null, val year: Int? = null,
                   val minScore: Int? = null, val status: String? = null, val sort: String = "pop")

data class Extra(val banner: String?, val genres: List<String>, val runtime: Int?, val studios: List<String>, val cast: List<String>)

data class SeasonInfo(val number: Int, val count: Int)
data class Episode(val season: Int, val number: Int, val name: String)

object CatalogApi {
    private val http = OkHttpClient()
    private val cache = java.util.concurrent.ConcurrentHashMap<String, CatalogResult>()

    suspend fun search(q: String): CatalogResult = cache[q.lowercase()] ?: coroutineScope {
        val a = async { runCatching { anilist(q) } }
        val t = async { if (BuildConfig.TMDB_KEY.isBlank()) null else runCatching { tmdb(q) } }
        val ar = a.await(); val tr = t.await()
        val r = CatalogResult(
            (ar.getOrNull() ?: emptyList()) + (tr?.getOrNull() ?: emptyList()),
            ar.isSuccess, tr?.isSuccess == true, tr == null
        )
        if (r.anilistOk || r.tmdbOk) cache[q.lowercase()] = r
        r
    }

    private suspend fun call(req: Request): JSONObject = withContext(Dispatchers.IO) {
        http.newCall(req).execute().use {
            if (!it.isSuccessful) error("HTTP ${it.code}")
            JSONObject(it.body!!.string())
        }
    }

    private suspend fun anilist(q: String): List<CatalogItem> {
        val gql = "query(\$s:String){Page(perPage:20){media(search:\$s,type:ANIME){id title{romaji english native} seasonYear coverImage{large} averageScore description(asHtml:false)}}}"
        val body = JSONObject().put("query", gql).put("variables", JSONObject().put("s", q)).toString()
            .toRequestBody("application/json".toMediaType())
        val arr = call(Request.Builder().url("https://graphql.anilist.co").post(body).build())
            .getJSONObject("data").getJSONObject("Page").getJSONArray("media")
        return parseAnilist(arr)
    }

    private fun parseAnilist(arr: JSONArray): List<CatalogItem> {
        return (0 until arr.length()).map {
            val m = arr.getJSONObject(it); val t = m.getJSONObject("title"); val id = m.getInt("id")
            CatalogItem("anilist:$id", "anime", t.optString("english").takeIf { s -> s.isNotBlank() && s != "null" } ?: t.getString("romaji"),
                t.optString("native").takeIf { s -> s != "null" }, m.optInt("seasonYear").takeIf { y -> y > 0 },
                m.optJSONObject("coverImage")?.optString("large"), m.optDouble("averageScore").takeIf { s -> !s.isNaN() }?.div(10),
                m.optString("description").takeIf { s -> s != "null" }, id, null)
        }
    }

    private suspend fun tmdb(q: String): List<CatalogItem> {
        val url = "https://api.themoviedb.org/3/search/multi?language=pt-BR&query=${URLEncoder.encode(q, "UTF-8")}&api_key=${BuildConfig.TMDB_KEY}"
        val arr = call(Request.Builder().url(url).build()).getJSONArray("results")
        return (0 until arr.length()).map { arr.getJSONObject(it) }
            .filter { it.optString("media_type") == "movie" || it.optString("media_type") == "tv" }
            .map {
                val movie = it.getString("media_type") == "movie"; val id = it.getInt("id")
                val date = it.optString(if (movie) "release_date" else "first_air_date")
                CatalogItem("tmdb:${it.getString("media_type")}:$id", if (movie) "movie" else "series",
                    it.optString(if (movie) "title" else "name"), it.optString(if (movie) "original_title" else "original_name"),
                    date.take(4).toIntOrNull(), it.optString("poster_path").takeIf { p -> p.isNotBlank() && p != "null" }?.let { p -> "https://image.tmdb.org/t/p/w342$p" },
                    it.optDouble("vote_average").takeIf { v -> !v.isNaN() }, it.optString("overview"), null, id)
            }
    }

    fun clearCache() = cache.clear()

    suspend fun seasons(item: CatalogItem): List<SeasonInfo> =
        if (item.anilistId != null) {
            val gql = "query(\$id:Int){Media(id:\$id){episodes nextAiringEpisode{episode}}}"
            val body = JSONObject().put("query", gql).put("variables", JSONObject().put("id", item.anilistId)).toString()
                .toRequestBody("application/json".toMediaType())
            val m = call(Request.Builder().url("https://graphql.anilist.co").post(body).build()).getJSONObject("data").getJSONObject("Media")
            val n = if (m.isNull("episodes")) (m.optJSONObject("nextAiringEpisode")?.optInt("episode", 1)?.minus(1) ?: 0) else m.getInt("episodes")
            listOf(SeasonInfo(1, n))
        } else {
            val arr = call(Request.Builder().url("https://api.themoviedb.org/3/tv/${item.tmdbId}?language=pt-BR&api_key=${BuildConfig.TMDB_KEY}").build()).getJSONArray("seasons")
            (0 until arr.length()).map { arr.getJSONObject(it) }.filter { it.getInt("season_number") > 0 }
                .map { SeasonInfo(it.getInt("season_number"), it.optInt("episode_count")) }
        }

    suspend fun episodes(item: CatalogItem, season: Int): List<Episode> =
        if (item.anilistId != null) (1..(seasons(item).firstOrNull()?.count ?: 0)).map { Episode(1, it, "") }
        else {
            val arr = call(Request.Builder().url("https://api.themoviedb.org/3/tv/${item.tmdbId}/season/$season?language=pt-BR&api_key=${BuildConfig.TMDB_KEY}").build()).getJSONArray("episodes")
            (0 until arr.length()).map { arr.getJSONObject(it) }.map { Episode(season, it.getInt("episode_number"), it.optString("name")) }
        }

    private const val FIELDS = "id title{romaji english native} seasonYear coverImage{large} averageScore description(asHtml:false)"

    private suspend fun anilistPage(sort: String, genre: String?, year: Int?, status: String?, min: Int?): List<CatalogItem> {
        val gql = "query(\$sort:[MediaSort],\$genre:String,\$year:Int,\$status:MediaStatus,\$min:Int){Page(perPage:20){media(type:ANIME,sort:\$sort,genre:\$genre,seasonYear:\$year,status:\$status,averageScore_greater:\$min){$FIELDS}}}"
        val v = JSONObject().put("sort", JSONArray().put(sort))
        genre?.let { v.put("genre", it) }; year?.let { v.put("year", it) }; status?.let { v.put("status", it) }; min?.let { v.put("min", it) }
        val body = JSONObject().put("query", gql).put("variables", v).toString().toRequestBody("application/json".toMediaType())
        return parseAnilist(call(Request.Builder().url("https://graphql.anilist.co").post(body).build())
            .getJSONObject("data").getJSONObject("Page").getJSONArray("media"))
    }

    private suspend fun anilistDiscover(f: Filters) = anilistPage(
        when (f.sort) { "rating" -> "SCORE_DESC"; "date" -> "START_DATE_DESC"; else -> "POPULARITY_DESC" },
        f.genre, f.year, f.status, f.minScore?.times(10))

    private suspend fun tmdbPath(path: String, type: String, extra: String = ""): List<CatalogItem> {
        val arr = call(Request.Builder().url("https://api.themoviedb.org/3/$path?language=pt-BR&api_key=${BuildConfig.TMDB_KEY}$extra").build()).getJSONArray("results")
        val movie = type == "movie"
        return (0 until arr.length()).map { arr.getJSONObject(it) }.map {
            val id = it.getInt("id"); val date = it.optString(if (movie) "release_date" else "first_air_date")
            CatalogItem("tmdb:$type:$id", if (movie) "movie" else "series", it.optString(if (movie) "title" else "name"),
                it.optString(if (movie) "original_title" else "original_name"), date.take(4).toIntOrNull(),
                it.optString("poster_path").takeIf { p -> p.isNotBlank() && p != "null" }?.let { p -> "https://image.tmdb.org/t/p/w342$p" },
                it.optDouble("vote_average").takeIf { v -> !v.isNaN() }, it.optString("overview"), null, id)
        }
    }

    private suspend fun tmdbDiscover(f: Filters, type: String): List<CatalogItem> {
        val movie = type == "movie"
        val genreId = when (f.genre) {
            null -> null
            "Action" -> if (movie) 28 else 10759
            "Comedy" -> 35; "Drama" -> 18
            "Fantasy" -> if (movie) 14 else 10765
            "Romance" -> if (movie) 10749 else -1
            else -> -1
        }
        if (genreId == -1) return emptyList()
        val sort = when (f.sort) { "rating" -> "vote_average.desc"; "date" -> if (movie) "primary_release_date.desc" else "first_air_date.desc"; else -> "popularity.desc" }
        var extra = "&sort_by=$sort"
        genreId?.let { extra += "&with_genres=$it" }
        f.year?.let { extra += (if (movie) "&primary_release_year=" else "&first_air_date_year=") + it }
        f.minScore?.let { extra += "&vote_average.gte=$it" }
        if (f.sort == "rating" || f.minScore != null) extra += "&vote_count.gte=200"
        return tmdbPath("discover/$type", type, extra)
    }

    suspend fun discover(f: Filters): CatalogResult = coroutineScope {
        val hasKey = BuildConfig.TMDB_KEY.isNotBlank()
        val wantTmdb = f.type != "anime"
        val a = if (f.type == null || f.type == "anime") async { runCatching { anilistDiscover(f) } } else null
        val m = if ((f.type == null || f.type == "movie") && hasKey) async { runCatching { tmdbDiscover(f, "movie") } } else null
        val t = if ((f.type == null || f.type == "series") && hasKey) async { runCatching { tmdbDiscover(f, "tv") } } else null
        val rs = listOfNotNull(a?.await(), m?.await(), t?.await())
        val offline = rs.isNotEmpty() && rs.all { it.isFailure }
        CatalogResult(rs.flatMap { it.getOrNull() ?: emptyList() }, !offline, !offline, wantTmdb && !hasKey)
    }

    suspend fun home(): List<Pair<String, List<CatalogItem>>> = coroutineScope {
        fun shelf(k: String, block: suspend () -> List<CatalogItem>) = k to async { runCatching { block() }.getOrDefault(emptyList()) }
        val hasKey = BuildConfig.TMDB_KEY.isNotBlank()
        listOfNotNull(
            shelf("trending") { anilistPage("TRENDING_DESC", null, null, null, null) },
            shelf("anime") { anilistPage("POPULARITY_DESC", null, null, null, null) },
            if (hasKey) shelf("movies") { tmdbPath("movie/popular", "movie") } else null,
            if (hasKey) shelf("series") { tmdbPath("tv/popular", "tv") } else null,
            shelf("releases") { anilistPage("POPULARITY_DESC", null, null, "RELEASING", null) },
            shelf("top") { anilistPage("SCORE_DESC", null, null, null, null) }
        ).map { (k, d) -> k to d.await() }.filter { it.second.isNotEmpty() }
    }

    private val extraCache = java.util.concurrent.ConcurrentHashMap<String, Extra>()

    private fun strings(arr: JSONArray?): List<String> = if (arr == null) emptyList() else (0 until arr.length()).map { arr.getString(it) }
    private fun names(arr: JSONArray?, key: String, n: Int = 8): List<String> =
        if (arr == null) emptyList() else (0 until minOf(arr.length(), n)).map { arr.getJSONObject(it).optString(key) }.filter { it.isNotBlank() }

    suspend fun extra(item: CatalogItem): Extra {
        extraCache[item.id]?.let { return it }
        val e = if (item.anilistId != null) {
            val gql = "query(\$id:Int){Media(id:\$id){bannerImage genres duration studios(isMain:true){nodes{name}} characters(sort:ROLE,perPage:8){nodes{name{full}}}}}"
            val body = JSONObject().put("query", gql).put("variables", JSONObject().put("id", item.anilistId)).toString()
                .toRequestBody("application/json".toMediaType())
            val m = call(Request.Builder().url("https://graphql.anilist.co").post(body).build()).getJSONObject("data").getJSONObject("Media")
            val chars = m.optJSONObject("characters")?.optJSONArray("nodes")
            Extra(m.optString("bannerImage").takeIf { it.isNotBlank() && it != "null" }, strings(m.optJSONArray("genres")),
                m.optInt("duration").takeIf { it > 0 }, names(m.optJSONObject("studios")?.optJSONArray("nodes"), "name"),
                if (chars == null) emptyList() else (0 until chars.length()).mapNotNull { chars.getJSONObject(it).optJSONObject("name")?.optString("full") }.filter { it.isNotBlank() })
        } else {
            val type = if (item.type == "movie") "movie" else "tv"
            val j = call(Request.Builder().url("https://api.themoviedb.org/3/$type/${item.tmdbId}?language=pt-BR&append_to_response=credits&api_key=${BuildConfig.TMDB_KEY}").build())
            Extra(j.optString("backdrop_path").takeIf { it.isNotBlank() && it != "null" }?.let { "https://image.tmdb.org/t/p/w780$it" },
                names(j.optJSONArray("genres"), "name"),
                (if (type == "movie") j.optInt("runtime") else j.optJSONArray("episode_run_time")?.optInt(0) ?: 0).takeIf { it > 0 },
                names(j.optJSONArray("production_companies"), "name", 3), names(j.optJSONObject("credits")?.optJSONArray("cast"), "name"))
        }
        extraCache[item.id] = e
        return e
    }
}
