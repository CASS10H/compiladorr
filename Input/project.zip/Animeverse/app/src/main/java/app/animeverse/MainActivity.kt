package app.animeverse

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.viewmodel.compose.viewModel
import app.animeverse.engine.*

val Purple = Color(0xFF9D4EDD)
val Ink = Color(0xFF0B0614)

class MainActivity : AppCompatActivity() {
    private val manager = PlaybackProviderManager().apply {
        register(InternetArchiveProvider())
        register(DemoProvider()) // Fonte de teste manual: pesquise por "demo".
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: CatalogViewModel = viewModel()
            val st by vm.settings.collectAsState()
            val bg = if (st.amoled) Color.Black else Ink
            MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = bg, surface = Color(0xFF1A0F2E))) {
                Surface(Modifier.fillMaxSize(), color = bg) { App(manager, vm) }
            }
        }
    }
}
