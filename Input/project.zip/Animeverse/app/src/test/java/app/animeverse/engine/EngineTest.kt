package app.animeverse.engine

import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

private fun src(p: String, url: String, q: Int) = Source(p, url, StreamFormat.MP4, q, "en")

private class Fake(
    override val id: String, private val out: List<Source> = emptyList(), private val delayMs: Long = 0,
    private val fail: Boolean = false, private val blocked: Set<String> = emptySet()
) : PlaybackProvider {
    var calls = 0
    override suspend fun findSources(query: MediaQuery): List<Source> {
        calls++
        if (delayMs > 0) delay(delayMs)
        if (fail) throw IllegalStateException("boom")
        return out
    }
    override suspend fun isAvailable(source: Source) = source.url !in blocked
}

class EngineTest {
    private val q = MediaQuery("x")
    private fun manager(vararg p: PlaybackProvider, timeout: Long = 1000) =
        PlaybackProviderManager(timeout).apply { p.forEach { register(it) } }

    @Test fun sortsByQualityDescending() = runBlocking {
        val r = manager(Fake("a", listOf(src("a", "u1", 480), src("a", "u2", 1080), src("a", "u3", 720)))).discover(q)
        assertEquals(listOf(1080, 720, 480), r.sources.map { it.qualityP })
    }

    @Test fun deduplicatesByUrl() = runBlocking {
        val r = manager(Fake("a", listOf(src("a", "same", 720))), Fake("b", listOf(src("b", "same", 720)))).discover(q)
        assertEquals(1, r.sources.size)
    }

    @Test fun slowProviderTimesOutAndOthersStillAnswer() = runBlocking {
        val start = System.currentTimeMillis()
        val r = manager(Fake("slow", listOf(src("slow", "s", 1080)), delayMs = 3000), Fake("fast", listOf(src("fast", "f", 720))), timeout = 100).discover(q)
        assertEquals(listOf("fast"), r.sources.map { it.provider })
        assertEquals("timeout", r.errors.single { it.provider == "slow" }.reason)
        assertTrue(System.currentTimeMillis() - start < 2000)
    }

    @Test fun failingProviderIsReportedNotThrown() = runBlocking {
        val r = manager(Fake("bad", fail = true), Fake("ok", listOf(src("ok", "o", 720)))).discover(q)
        assertEquals(1, r.sources.size)
        assertEquals("boom", r.errors.single().reason)
    }

    @Test fun unavailableSourcesAreFilteredOut() = runBlocking {
        val r = manager(Fake("a", listOf(src("a", "good", 720), src("a", "dead", 1080)), blocked = setOf("dead"))).discover(q)
        assertEquals(listOf("good"), r.sources.map { it.url })
    }

    @Test fun noProvidersMeansEmptyWithoutErrors() = runBlocking {
        val r = PlaybackProviderManager().discover(q)
        assertTrue(r.sources.isEmpty()); assertTrue(r.errors.isEmpty())
    }

    @Test fun successfulResultsAreCachedButEmptyOnesAreNot() = runBlocking {
        val full = Fake("a", listOf(src("a", "u", 720))); val m1 = manager(full)
        m1.discover(q); m1.discover(q); assertEquals(1, full.calls)
        val empty = Fake("e"); val m2 = manager(empty)
        m2.discover(q); m2.discover(q); assertEquals(2, empty.calls)
    }

    @Test fun demoProviderAnswersOnlyToDemo() = runBlocking {
        val m = manager(DemoProvider())
        val demo = m.discover(MediaQuery("Demo")).sources
        assertEquals(setOf(StreamFormat.HLS, StreamFormat.MP4), demo.map { it.format }.toSet())
        assertTrue(m.discover(MediaQuery("Naruto")).sources.isEmpty())
    }
}
