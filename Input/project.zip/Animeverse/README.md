# Animeverse — busca de mídia aberta

Projeto Android em Kotlin/Jetpack Compose. Abra a pasta no Android Studio com JDK 17 e compile com `./gradlew assembleDebug` (o wrapper precisa estar disponível; o ZIP original não continha `gradlew` nem `gradle-wrapper.jar`).

## Busca e reprodução
- Catálogo: AniList (anime), TMDB (filmes/séries, requer `TMDB_KEY` em `local.properties`) e pesquisa direta no Internet Archive.
- Reprodução: Media3/ExoPlayer com descoberta paralela de provedores, timeout, deduplicação, ordenação por resolução e fallback automático.
- Provedor integrado: Internet Archive. O app só aceita itens com licença explicitamente reconhecida como CC0, Public Domain Mark, CC BY ou CC BY-SA (versões 3.0/4.0), e arquivos MP4/M4V públicos.
- Fonte de demonstração: pesquise `demo` na aba Assistir para testar o player.

## Limitações importantes
- Isso não é uma busca irrestrita em todos os sites da internet. Cada serviço tem API, regras, formatos e permissões próprios.
- Nem todo título estará no Internet Archive; anime e lançamentos comerciais normalmente não são disponibilizados sob licenças abertas.
- O app não contorna DRM, paywalls, autenticação, bloqueios ou restrições geográficas, e não extrai streams de serviços sem autorização.
- A qualidade exibida vem dos metadados do arquivo ou do nome do arquivo. Se não houver resolução informada, o app usa uma estimativa conservadora de 480p.
- A disponibilidade pode mudar; links podem falhar e o player tenta a próxima fonte encontrada.

## Adicionar provedores
Implemente `PlaybackProvider` em `engine/` e registre-o em `MainActivity`. Use somente APIs/fontes com permissão de reprodução e respeite os termos/licenças de cada origem.

## Configuração TMDB
Crie `local.properties` na raiz do projeto com `TMDB_KEY=sua_chave`. Sem a chave, AniList e Internet Archive continuam disponíveis.
