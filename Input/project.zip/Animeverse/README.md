# Animeverse (núcleo inicial)
Abra a pasta no Android Studio (JDK 17) e rode `./gradlew assembleDebug` (precisa de internet e do Gradle wrapper: `gradle wrapper`).
APK: app/build/outputs/apk/debug/. Digite "demo" na busca para testar o SourceDiscovery Engine + player.
Novo provedor: implemente `PlaybackProvider` e registre em `PlaybackProviderManager.register()`. Só use fontes autorizadas.
Não incluído ainda: AniList/TMDB, Room, DataStore, telas Explorar/Minha lista/Perfil, legendas/áudio no player.
Este código NÃO foi compilado.

## Etapa 2 — catálogo
Crie `local.properties` na raiz com `TMDB_KEY=sua_chave` (https://developer.themoviedb.org). Sem a chave, só o AniList (animes) funciona.
Room guarda catálogo, favoritos e histórico de buscas; sem internet a busca usa os resultados salvos.
Ainda não compilado.

## Etapa 3
Navegação inferior (Início, Explorar, Assistir, Minha lista, Perfil), filtros por tipo, favoritos, progresso salvo e retomada, limpar histórico.
Ainda não compilado.

## Etapa 4
Tela de Detalhes (sinopse, temporadas, episódios via AniList/TMDB), botão assistir por episódio e próximo/anterior no player. Ainda não compilado.
