# TIKMUSIC (Android, local)

Bot de pedidos de música para lives do TikTok. Backend Python + painel HTML rodando
**inteiramente no celular** via Chaquopy. Sem VPS.

## Como gerar o APK

**Pelo GitHub Actions (este repositório):**
1. Faça push para o GitHub (branch `main`).
2. Aba **Actions** → workflow **Build TIKMUSIC APK**.
3. Baixe o artefato **TIKMUSIC-debug** (`TIKMUSIC-debug.apk`) e instale no celular.

**Pelo Compilador Universal:** envie este conteúdo como `input/project.zip`
(o APK sai como `TIKMUSIC-release.apk`, já assinado com a chave de debug, instalável).

O backend escuta em `http://127.0.0.1:8000` (apenas localhost).
Veja `ALTERACOES.md` para o que mudou nesta versão.

## Supabase (1.2.0)
A tela Android usa a ponte nativa `TikMusicAuth` para chamar a Edge Function `register-with-invite` e o endpoint de senha do Supabase Auth. A Publishable Key está no APK (ela é pública); nunca adicione `service_role` ou segredo administrativo ao aplicativo. Tokens retornados são gravados com AES-GCM usando chave do Android Keystore.

Cadastro: nome de usuário (3–20 caracteres), e-mail, senha (mínimo 8 caracteres) e convite `TIKBETA`. Login: e-mail e senha. Após a autenticação online, o app cria/abre a sessão SQLite local para manter o bot existente. A sincronização remota de playlists/favoritos/histórico ainda é uma etapa separada.
