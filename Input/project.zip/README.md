# TIKMUSIC (Android, local)

Bot de pedidos de música para lives do TikTok. Backend Python + painel HTML rodando
**inteiramente no celular** via Chaquopy. Sem VPS.

## Como gerar o APK

**Pelo GitHub Actions (este repositório):**
1. Faça push para o GitHub (branch `main`).
2. Aba **Actions** → workflow **Build TIKMUSIC APK**.
3. Baixe o artefato **TIKMUSIC-debug** (`TIKMUSIC-debug.apk`) e instale no celular.

**Pelo Compilador Universal:** envie este conteúdo como `input/project.zip`
(o APK sai como `TIKMUSIC-release.apk`, já assinado com a chave de debug, instalável).

O backend escuta em `http://127.0.0.1:8000` (apenas localhost).
Veja `ALTERACOES.md` para o que mudou nesta versão.

## Aba Minha LIVE (1.5.0)
O painel inclui uma aba para colar o link compartilhado da sua própria LIVE do TikTok e tentar assisti-la dentro do app. O link informado pode ficar salvo localmente no aparelho. Isso é apenas visualização: o TIKMUSIC não inicia transmissão nem captura a tela.

**Limitação do TikTok:** a reprodução incorporada de LIVE não é garantida; o TikTok pode bloquear o player em WebView/iframe ou exigir o app oficial/login. Se isso ocorrer, use o botão “Abrir no TikTok”. O overlay e o chat só aparecem se o próprio player/plataforma os disponibilizar.

## Supabase (1.2.0)
A tela Android usa a ponte nativa `TikMusicAuth` para chamar a Edge Function `register-with-invite` e o endpoint de senha do Supabase Auth. A Publishable Key está no APK (ela é pública); nunca adicione `service_role` ou segredo administrativo ao aplicativo. Tokens retornados são gravados com AES-GCM usando chave do Android Keystore.

Cadastro: nome de usuário (3–20 caracteres), e-mail, senha (mínimo 8 caracteres) e convite `TIKBETA`. Login: e-mail e senha. Após a autenticação online, o app cria/abre a sessão SQLite local para manter o bot existente. A sincronização remota de playlists/favoritos/histórico ainda é uma etapa separada.
