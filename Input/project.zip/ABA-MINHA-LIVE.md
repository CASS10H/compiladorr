# Aba Minha LIVE

Foi adicionada uma aba ao painel para tentar assistir à LIVE do TikTok usando o link compartilhado.

- Link inicial preenchido com o endereço compartilhado pelo usuário nesta conversa.
- Aceita apenas URLs HTTPS dos domínios TikTok conhecidos.
- Guarda o link escolhido no armazenamento local do WebView.
- Botão para tentar carregar dentro do painel.
- Botão de fallback para abrir no TikTok/navegador.
- Não transmite, não captura a tela e não solicita permissões de câmera/microfone.

## Limitação
O TikTok não garante player incorporável para transmissões LIVE. A página pode bloquear iframe/WebView, solicitar autenticação ou abrir apenas no app oficial. O código oferece uma tentativa de reprodução e um fallback, mas a reprodução interna precisa ser validada no aparelho e na LIVE ativa.
