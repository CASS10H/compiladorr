# TIKMUSIC Live — Roadmap (Opção B)

Transformação do bot de música em **aplicativo de live completo** com transmissão real.

Versão atual: **2.2.0-compose**

---

## Fase 0 — Fundação (FEITO nesta entrega)

- [x] Modelo de cena e fontes (`Scene.kt`, `Source`)
- [x] `StreamConfig` + presets 480p/720p/1080p
- [x] `StreamService` (foreground, câmera|microfone)
- [x] `StreamBridge` (JS ↔ nativo: `window.TikMusicStream`)
- [x] Permissões CAMERA + RECORD_AUDIO
- [x] Dependências CameraX + RootEncoder (Pedro García)
- [x] Página `/live` com controles RTMP, preset, start/stop
- [x] Manifest e Gradle atualizados (JitPack)

O serviço ainda opera em **modo preparação** (estado e API prontos; encoder real na Fase 1).

---

## Fase 1 — Encoder real (FEITO)

Objetivo: câmera + mic → H.264/AAC → RTMP de verdade.

- [x] RootEncoder `RtmpCamera2` no `StreamService`
- [x] Callbacks ConnectChecker (sucesso, falha, bitrate, disconnect)
- [x] `StreamPreviewActivity` com OpenGlView
- [x] Start/stop real + troca de câmera
- [x] Bridge: `openPreview()`, `switchCamera()`
- [x] Página `/live` atualizada

Testar com servidor RTMP local (nginx-rtmp / MediaMTX) ou chave real de TikTok/YouTube/Twitch.

---

## Fase 2 — Editor de cena básico (FEITO)

- [x] `SceneStore` — persistência JSON em SharedPreferences
- [x] Fontes: Camera, Image, WebOverlay, Text
- [x] API JS: listScenes, saveScene, createScene, deleteScene, setActiveScene…
- [x] Página `/scenes` — editor visual (canvas 9:16 / 16:9)
- [x] Preview nativo aplica WebOverlay + Text por cima da câmera
- [x] Cena ativa define facing da câmera no stream

Composição no encoder foi feita na Fase 3.

---

## Fase 3 — Composição no encoder (FEITO, aguardando teste em aparelho)

- [x] `SceneCompositor`: Image / Text / WebOverlay viram `ImageObjectFilterRender` do RootEncoder
- [x] WebOverlay: WebView fora da tela desenhado em Bitmap a 8 fps → textura
- [x] Overlays aparecem no preview (OpenGlView) **e** no RTMP
- [x] Preview não sobrepõe mais views; botão "Overlays" recarrega a composição
- [x] Ponte JS: `reloadOverlays()` e `getComposeInfo()`
- [x] Cor `#RRGGBBAA` (CSS) tratada corretamente (antes o fundo do texto ficava transparente)
- [ ] Transições entre cenas (adiado)
- [ ] Filtros leves: espelhar / cor (adiado)
- [ ] Gravação local MP4 em paralelo (adiado)

Limitações: câmera é sempre tela cheia (x/y/w/h/opacidade da Camera ignorados); overlay HTML limitado a 1280 px por lado.

## Fase 4 — Chat e alertas multiplataforma

1. Manter TikTokLive (já existe)
2. Adicionar YouTube Live Chat / Twitch IRC (ou via serviços intermediários)
3. Widgets de alerta (follow, gift, sub) reutilizando o sistema de eventos atual
4. Overlay unificado consumindo todos os eventos

---

## Fase 5 — Polimento

- Estatísticas em tempo real (bitrate, dropped frames, temperatura)
- Presets por plataforma (TikTok 720p30, YouTube 1080p30, etc.)
- Modo economia de bateria
- Testes em Android 8–15, arm64 e 32-bit
- Assinatura de release e Play Store (se desejado)

---

## API JavaScript (já disponível no WebView)

```js
// Estado
TikMusicStream.isReady()          // boolean
TikMusicStream.getState()         // JSON string
TikMusicStream.getConfig()        // JSON string

// Configuração
TikMusicStream.updateConfig(json) // { rtmpUrl, streamKey, width, height, fps, ... }

// Controle
TikMusicStream.startStream()
TikMusicStream.stopStream()
TikMusicStream.startPreview()
TikMusicStream.stopPreview()

// Callback (opcional)
window.__onStreamState = (state) => { /* ... */ }
```

Página de controles: `http://127.0.0.1:8000/live`

---

## Notas importantes

- **TikTok** exige stream key gerada no app/painel oficial; o app só envia o RTMP.
- Overlay HTML do bot de música continua funcionando em paralelo (porta 8000).
- O `BotService` (Python) e o `StreamService` (nativo) coexistem; um não depende do outro para iniciar.
- minSdk 25 (Android 7.1) mantido; RootEncoder e CameraX suportam esse piso.
