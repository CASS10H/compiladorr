# TIKMUSIC — resumo de continuidade para o próximo chat

## Estado do projeto

Projeto Android Kotlin + WebView HTML/CSS/JS + backend Python/FastAPI via Chaquopy + SQLite local. O bot TikTok, player, fila, biblioteca, overlays e importação CSV/TXT foram preservados. O pacote desta versão é `1.3.0` (`versionCode 4`).

## Supabase

- Project URL: `https://fpqzxqkgkpkbykfceihb.supabase.co`
- Cliente Android usa a Publishable Key pública que já está configurada em `TikMusicAuth.kt`.
- Nunca inserir `service_role`/Secret Key no APK ou no repositório.
- Cadastro: Edge Function `register-with-invite`, com convite `TIKBETA`. O usuário já informou que a função foi implantada e testada com sucesso.
- Tabelas verificadas pelo usuário: `profiles`, `user_settings`, `playlists`, `playlist_tracks`, `favorites`, `play_history`, `devices`.
- RLS verificada: cada tabela limita operações ao `auth.uid()` do dono; `playlist_tracks` também verifica que a playlist pertence ao mesmo usuário.

## Implementações desta versão

1. `TikMusicAuth.kt`
   - Cadastro via Edge Function e login Supabase Auth.
   - Access token e refresh token criptografados com AES-GCM usando Android Keystore.
   - Renovação automática do access token.
   - Mantido o alias de chave v1 para preservar tokens que já estavam salvos.
2. `bot.py`
   - Nova coluna SQLite `usuarios.supabase_uid` com índice único parcial para vincular a conta local ao UUID de `auth.users`.
   - `/api/auth/supabase` valida o JWT no endpoint `/auth/v1/user` antes de emitir sessão local.
   - Migração de perfil SQLite antigo somente se o usuário também comprovar a senha local antiga.
   - Expiração do JWT validado verificada na sessão local.
   - Sincronização PostgREST com JWT individual do usuário; RLS continua ativa.
   - Sincroniza `profiles`, `user_settings`, `favorites`, `play_history`, `playlists`, `playlist_tracks` e `devices`.
   - Favoritos têm fila local de alterações para propagar inclusão/remoção após reconexão.
   - Playlists e faixas têm armazenamento local, endpoints de criar/listar/excluir/adicionar/remover e detecção de exclusões vindas de outro dispositivo.
   - Histórico recente é enviado com fingerprint local para evitar reenvio repetido; histórico remoto é mesclado à biblioteca local.
   - Configurações usam `updated_at` para decidir qual versão prevalece; instalação nova puxa configurações remotas.
   - Offline: SQLite continua utilizável; favoritos e playlists ficam pendentes para próxima sincronização.
3. `painel.html`
   - Login/cadastro vinculados ao UUID Supabase.
   - Restauração da sessão no início e rebind quando o access token é renovado.
   - Sincronização no início, após alterações relevantes e a cada 60 segundos.
   - Área de playlists na Biblioteca para criar, abrir, excluir, adicionar músicas e remover músicas.
   - Importação Spotify CSV/TXT pode receber um nome e criar uma playlist que sincroniza com a conta.
4. `app/build.gradle`
   - Versão `1.3.0`, `versionCode 4`.
5. Documentação de compilação e auditoria atualizada.

## Testes executados

- Python AST/compile: aprovado.
- XML Android: aprovado.
- JavaScript embutido nos HTMLs: `node --check` aprovado.
- Backend FastAPI importado com bibliotecas de mídia/TikTok simuladas; rotas e migrações SQLite verificadas.
- Teste local simulado de autenticação, criação/listagem/exclusão de playlists: aprovado.
- Teste PostgREST simulado de sincronização de perfil, settings, playlist, faixa e device: aprovado.
- Teste simulado de adicionar/remover favorito na nuvem: aprovado.
- Teste simulado de adicionar/remover faixa de playlist: aprovado.
- Teste simulado de sincronização nuvem → SQLite para settings, favoritos, playlists, faixas e histórico: aprovado.
- Teste simulado de importação CSV/TXT diretamente para playlist local: aprovado.
- `TikMusicAuth.kt` compilado isoladamente com stubs mínimos das APIs Android/JSON; apenas aviso de depreciação do construtor `URL`.

## O que ainda não foi validado

- Build Gradle completo / APK: não executado neste ambiente por indisponibilidade de rede para baixar Gradle e dependências Android. O GitHub Actions está preparado para `assembleDebug` e `assembleRelease`.
- Chamadas reais ao projeto Supabase: não executadas neste ambiente por DNS/rede indisponível. Os testes de sincronização foram simulados, não são teste de produção.
- Confirmar constraints/PKs reais das tabelas. O código usa `id` como chave de conflito nas tabelas `profiles`, `playlists`, `playlist_tracks` e `devices`.

## Próximos passos

1. No Supabase SQL Editor, confirmar constraints/PKs com:

```sql
SELECT
  tc.table_name,
  tc.constraint_name,
  tc.constraint_type,
  kcu.column_name,
  ccu.table_name AS foreign_table_name,
  ccu.column_name AS foreign_column_name
FROM information_schema.table_constraints tc
LEFT JOIN information_schema.key_column_usage kcu
  ON tc.constraint_name = kcu.constraint_name
  AND tc.table_schema = kcu.table_schema
LEFT JOIN information_schema.constraint_column_usage ccu
  ON ccu.constraint_name = tc.constraint_name
  AND ccu.table_schema = tc.table_schema
WHERE tc.table_schema = 'public'
  AND tc.table_name IN (
    'profiles','user_settings','playlists','playlist_tracks',
    'favorites','play_history','devices'
  )
ORDER BY tc.table_name, tc.constraint_type, tc.constraint_name, kcu.ordinal_position;
```

2. Publicar o ZIP atualizado no repositório GitHub `CASS10H/Compilador-universal` ou no repositório do TIKMUSIC (confirmar o destino antes de enviar).
3. Executar o workflow `TIKMUSIC - validar e compilar APK` e revisar logs reais do Gradle/Chaquopy.
4. Instalar o APK Debug em Android, testar cadastro/login, renovação de sessão, sincronização com dois dispositivos e modo offline.
5. Se PostgREST retornar `on_conflict` inválido, revisar a constraint `id` apontada pelo erro e corrigir o SQL/endpoint sem desativar RLS.

## Preferências de implementação

O usuário prefere receber arquivos completos, prontos para substituir, com caminhos exatos e sem trechos omitidos/reticências. Antes de alterar código, analisar o projeto existente e preservar as funcionalidades atuais. Responder em português do Brasil.
