# TIKMUSIC 1.3.0 — pacote para o Compilador Universal

## Detecção de plataforma

Este ZIP é um **projeto Android nativo**, não um projeto multiplataforma. O destino correto da detecção automática é Android. Windows, Linux e Web não são destinos de compilação válidos para este código-fonte sem um projeto/port separado.

## Stack detectada

- Kotlin / Android Gradle Plugin 8.7.3
- Android `compileSdk 35`, `minSdk 25`, `targetSdk 35`; ABIs `armeabi-v7a` e `arm64-v8a`
- Java/JVM 17
- Gradle 8.11.1 (bootstrap pelo `gradlew` incluído)
- Chaquopy 17.2.0 com Python 3.11 (compatível com ARMv7 32 bits e ARM64)
- Backend Python: FastAPI, Uvicorn, HTTPX, TikTokLive 6.6.5 e yt-dlp
- Interface HTML/CSS/JavaScript em Android WebView
- SQLite local
- Supabase Auth com convite TIKBETA, refresh de sessão, validação do JWT no backend, RLS e sincronização dos dados

## Compilação

Versão do app: `1.3.0` (`versionCode 4`).

O workflow `.github/workflows/build-apk.yml` executa verificações estáticas, compila `assembleDebug` e `assembleRelease` e publica ambos os APKs como artefato do GitHub Actions.

Também pode ser executado manualmente na aba **Actions** do repositório, usando **TIKMUSIC - validar e compilar APK**.

## Artefatos

- Debug: `app/build/outputs/apk/debug/`
- Release: `app/build/outputs/apk/release/`

O tipo Release está configurado no projeto com assinatura de debug para gerar um APK instalável de teste. Isso **não é assinatura de distribuição**. Antes de publicar na Play Store, configure uma chave de assinatura privada fora do repositório e use GitHub Secrets.

## Configuração Supabase

- Project URL: `https://fpqzxqkgkpkbykfceihb.supabase.co`
- Cliente Android: somente a Publishable Key pública.
- Cadastro: Edge Function `register-with-invite`, com convite `TIKBETA` e a chave administrativa mantida exclusivamente nos secrets da função.
- Backend: valida o access token pelo endpoint Auth `/auth/v1/user` e acessa o PostgREST com o JWT do próprio usuário, respeitando as políticas RLS.
- Nunca coloque `service_role`/Secret Key no APK, no repositório ou em variáveis entregues ao cliente.

## Sincronização incluída

O backend sincroniza `profiles`, `user_settings`, `favorites`, `play_history`, `playlists`, `playlist_tracks` e `devices`. O SQLite continua sendo o cache local e mantém o player/bot funcionando sem depender de uma conexão contínua. Favoritos têm fila de alterações pendentes; playlists e músicas são mantidas localmente e enviadas na sincronização seguinte. O painel tem controles para criar, abrir, excluir e adicionar/remover músicas às playlists. A importação Spotify CSV/TXT também pode criar uma playlist nomeada e sincronizá-la.

A sincronização remota depende de a estrutura e as políticas RLS do projeto Supabase corresponderem às colunas e políticas verificadas pelo usuário. A rede deste ambiente não permite validar chamadas reais ao projeto; os testes locais usam respostas simuladas para validar o fluxo e não substituem um teste no aparelho conectado à internet.
