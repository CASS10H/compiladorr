# Alterações da versão 1.1.0 (TIKMUSIC)

Base: `bot-musica-android-github-1.zip` (original preservado, não modificado).
`applicationId` mantido (`br.com.botmusica.app`): instala por cima da versão anterior
(se o Android recusar por assinatura diferente, desinstale a antiga antes).

## Marca
- Nome do app: **TIKMUSIC** (`strings.xml`, manifest, notificação, título e login do painel).
- Ícone do app (normal, redondo e adaptativo) gerado a partir da foto enviada.
- A mesma foto aparece como capa na tela de login do painel.
- APK gerado com nome `TIKMUSIC-*.apk`.

## Melhorias no app
- Android 15: o painel não fica mais por baixo da barra de status/navegação.
- Notificação com ícone próprio, toque para abrir o app e botão **Parar** (encerra o bot).
- Mantém o processador acordado (WakeLock, no máximo 12 h) para a live não cair com a tela apagada.
- Serviço reinicia sozinho se o Android o encerrar (START_STICKY).
- Links externos abrem no navegador; tentativas de reconexão ao servidor local limitadas e sem repetir o aviso.
- Cache de músicas limitado a 2 GB no celular (antes 10 GB); ajustável via `BOT_MAX_GB`.

## Correções de build
- `requirements.txt`: `uvicorn[standard]` → `uvicorn`. O extra `[standard]` instala uvloop/httptools/watchfiles,
  que não têm versão para Android no Chaquopy e quebrariam o build (o APK anterior usava `uvicorn` simples).
- `gradlew` incluído: baixa e usa o Gradle 8.11.1 fixo (o Gradle do runner pode ser incompatível com o AGP 8.7.3).
- Release assinado com a chave de debug, para o `assembleRelease` do Compilador Universal gerar APK instalável.
- Workflow: cache do Gradle, artefato `TIKMUSIC-debug`, sem `|| true` escondendo erro.

## Não alterado
- `bot.py` (lógica do bot, TikTokLive, yt-dlp, banco de dados) e demais HTMLs.


## Integração inicial Supabase (versão 1.2.0)
- `TikMusicAuth.kt` implementa cadastro pela Edge Function `register-with-invite` e login pelo Supabase Auth.
- A Publishable Key e a Project URL são usadas no cliente; nenhuma `service_role` foi adicionada.
- Access/refresh tokens são armazenados criptografados com AES-GCM e chave Android Keystore.
- `MainActivity.kt` expõe a ponte JavaScript nativa `TikMusicAuth`.
- `painel.html` agora solicita nome, e-mail, senha e convite no cadastro; o login online usa e-mail e senha.
- Após autenticar online, o painel abre/cria uma sessão SQLite local para manter o bot existente funcionando.
- O limite de contas locais Android foi ampliado para 20 perfis por aparelho.

Limitação desta etapa: os tokens já ficam protegidos no Android, mas a sincronização de playlists/favoritos/histórico e a validação JWT nas rotas Python ainda não foram implementadas. Isso será feito na próxima etapa, antes de declarar os dados sincronizados entre dispositivos. A sessão local SQLite é independente da sessão Supabase.

## Integração Supabase completa — sincronização (versão 1.3.0)
- Login Supabase passa a validar o access token no endpoint Auth `/auth/v1/user` antes de criar a sessão SQLite local.
- A conta SQLite é vinculada ao UUID `auth.users.id` em `usuarios.supabase_uid`; a migração de conta SQLite antiga só ocorre quando a senha local antiga também é comprovada.
- Access token e refresh token continuam criptografados pelo Android Keystore; foi mantido o alias da chave anterior para preservar sessões já armazenadas. O app renova o access token automaticamente.
- As rotas de sincronização usam o JWT do usuário e a Publishable Key; nenhuma `service_role`/Secret Key está no APK.
- Sincronização com RLS para `profiles`, `user_settings`, `favorites`, `play_history`, `playlists`, `playlist_tracks` e `devices`.
- Favoritos usam fila local de alterações para propagar inclusão/remoção após reconexão.
- Playlists podem ser criadas, visualizadas, excluídas e receber músicas pela Biblioteca; listas e faixas são sincronizadas entre dispositivos.
- Histórico recente é enviado com identificador local idempotente e o histórico remoto é mesclado à biblioteca/overlay local.
- Configurações usam `updated_at` para decidir qual versão é mais recente; a configuração remota é carregada em uma instalação nova.
- A sincronização automática ocorre ao abrir o painel, após alterações de favoritos/configurações/playlists e em intervalo de 60 segundos.
- Em indisponibilidade de rede, o SQLite permanece utilizável e alterações de favoritos/playlists ficam pendentes para nova tentativa.
- Importação Spotify CSV/TXT agora aceita nome opcional de playlist; quando preenchido, cria a playlist e adiciona as faixas resolvidas para sincronização com a Supabase.

## Versão 1.4.0 — streaming padrão, download manual, seletor de arquivos, layout

> Correção de build (1.4.0): `MainActivity.kt` tinha um comentário KDoc com `audio/*`. Em Kotlin, comentários de bloco aninham, então o `/*` engolia código e o `:app:compileReleaseKotlin` falhava. Comentário reescrito.


### Streaming como padrão
- `app.py` define `BOT_STREAMING=1` ao iniciar o bot no Android; no `bot.py` o padrão agora é streaming (só `BOT_STREAMING=0` volta ao cache antigo). Antes a variável não era definida e o app baixava e guardava cada música pedida.
- `/audio/<id>` corrigido: o cliente HTTP não vaza mais se a conexão com a origem falhar; o cache de links resolvidos deixa de crescer sem limite.

### Download manual (novo `python/downloads.py`)
- Nada baixa sozinho. O botão **Baixar** (cartões de busca, fila, biblioteca, playlist e player) inicia o download no servidor local com progresso; ao terminar, o Android abre o seletor de arquivos (criar documento) para o usuário escolher pasta e nome, e o app copia o arquivo mostrando o progresso.
- O arquivo fica em `tmp_downloads/` só até a entrega; erro, cancelamento ou sobra de execução anterior são apagados (ao iniciar o bot e após 1 h).
- Novas rotas: `POST /api/download/iniciar`, `GET /api/download/status/<token>`, `POST /api/download/cancelar/<token>`, `GET /dl/<token>` e `POST /dl/<token>/fim` (usadas pelo código nativo; token secreto, só em 127.0.0.1).

### Seletor de arquivos do Android
- Causa do defeito: o WebView usava `WebChromeClient()` puro, sem `onShowFileChooser`, então `<input type="file">` não abria nada. `MainActivity.kt` agora implementa o seletor com `ACTION_OPEN_DOCUMENT` (sem permissão de armazenamento, vale para Android 8+), converte o `accept` do input em tipos MIME e trata cancelamento.
- Nova ponte `TikMusicFiles` (`salvarDownload`, `exportarTexto`) com `ACTION_CREATE_DOCUMENT`.
- Importação aceita CSV, TXT, M3U e M3U8. Nova exportação da biblioteca e da playlist aberta em CSV (formato que a própria importação lê).

### Cache e armazenamento
- Aba Configurações → **Armazenamento**: mostra o cache antigo e o botão **Limpar cache antigo** (apaga só arquivos de áudio; biblioteca, histórico, favoritos e playlists ficam intactos).

### Interface
- Títulos com até 2 linhas e quebra de palavras longas; artista em 1 linha; chips sem estourar; sem rolagem horizontal; telas até 420 px com botões empilhados e capas menores.
