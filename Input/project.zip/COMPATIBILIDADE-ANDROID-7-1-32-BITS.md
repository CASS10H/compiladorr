# Compatibilidade Android 7.1 e ARM de 32 bits

Alterações aplicadas ao projeto:

- `minSdk 25`: Android 7.1 (API 25).
- `abiFilters 'armeabi-v7a', 'arm64-v8a'`: inclui ARMv7 de 32 bits e ARM64.
- Chaquopy/Python alterado de Python 3.13 para Python 3.11. Python 3.12 ou superior não oferece ABI `armeabi-v7a` no Chaquopy atual.
- GitHub Actions configura Python 3.11 para que o Python de build corresponda ao Python embutido no APK.

## Limitações importantes

A inclusão de ARMv7 não garante por si só que todas as dependências Python tenham wheels Android de 32 bits. O workflow do GitHub Actions precisa compilar com sucesso; se algum pacote não tiver wheel `armeabi-v7a` para Python 3.11, será necessário ajustar a versão desse pacote ou substituir/remover a dependência incompatível.

O APK resultante deverá ser testado em um aparelho Android 7.1 ARMv7 real. `minSdk 25` também não garante compatibilidade com APIs Android mais novas usadas diretamente pelo código ou por bibliotecas.
