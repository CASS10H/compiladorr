package br.com.botmusica.app.streaming

/**
 * Modelo de cena (estilo OBS simplificado).
 * Cada cena contém uma lista ordenada de fontes (camadas).
 * O painel Web pode editar e salvar cenas em JSON.
 */
data class Scene(
    val id: String,
    val name: String,
    val sources: List<Source> = emptyList()
)

sealed class Source {
    abstract val id: String
    abstract val name: String
    abstract val visible: Boolean
    abstract val x: Float          // 0..1 (relativo à largura da cena)
    abstract val y: Float          // 0..1
    abstract val width: Float      // 0..1
    abstract val height: Float     // 0..1
    abstract val opacity: Float    // 0..1
    abstract val zIndex: Int

    data class Camera(
        override val id: String,
        override val name: String = "Câmera",
        override val visible: Boolean = true,
        override val x: Float = 0f,
        override val y: Float = 0f,
        override val width: Float = 1f,
        override val height: Float = 1f,
        override val opacity: Float = 1f,
        override val zIndex: Int = 0,
        val facing: String = "front"   // "front" | "back"
    ) : Source()

    data class Image(
        override val id: String,
        override val name: String = "Imagem",
        override val visible: Boolean = true,
        override val x: Float = 0f,
        override val y: Float = 0f,
        override val width: Float = 0.3f,
        override val height: Float = 0.3f,
        override val opacity: Float = 1f,
        override val zIndex: Int = 10,
        val uri: String = ""           // content:// ou file://
    ) : Source()

    data class WebOverlay(
        override val id: String,
        override val name: String = "Overlay HTML",
        override val visible: Boolean = true,
        override val x: Float = 0f,
        override val y: Float = 0f,
        override val width: Float = 1f,
        override val height: Float = 1f,
        override val opacity: Float = 1f,
        override val zIndex: Int = 20,
        val url: String = "http://127.0.0.1:8000/overlay-unificado.html"
    ) : Source()

    data class Text(
        override val id: String,
        override val name: String = "Texto",
        override val visible: Boolean = true,
        override val x: Float = 0.05f,
        override val y: Float = 0.05f,
        override val width: Float = 0.4f,
        override val height: Float = 0.1f,
        override val opacity: Float = 1f,
        override val zIndex: Int = 15,
        val text: String = "",
        val fontSize: Float = 32f,
        val color: String = "#FFFFFF",
        val backgroundColor: String = "#00000080"
    ) : Source()
}

/**
 * Cena padrão criada na primeira execução.
 */
object DefaultScenes {
    fun createDefault(): List<Scene> = listOf(
        Scene(
            id = "cena-principal",
            name = "Cena Principal",
            sources = listOf(
                Source.Camera(
                    id = "cam-principal",
                    name = "Câmera Principal",
                    facing = "front",
                    zIndex = 0
                ),
                Source.WebOverlay(
                    id = "overlay-tikmusic",
                    name = "Overlay TIKMUSIC",
                    url = "http://127.0.0.1:8000/overlay-unificado.html",
                    zIndex = 20
                )
            )
        ),
        Scene(
            id = "cena-camera-so",
            name = "Só Câmera",
            sources = listOf(
                Source.Camera(
                    id = "cam-so",
                    name = "Câmera",
                    facing = "front",
                    zIndex = 0
                )
            )
        )
    )
}
