package br.com.botmusica.app

import android.content.Context
import android.webkit.JavascriptInterface
import android.util.Base64
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties

/** Autenticação Supabase. Access/refresh tokens são cifrados com Android Keystore. */
class TikMusicAuth(context: Context) {
    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences("tikmusic_auth", Context.MODE_PRIVATE)

    @JavascriptInterface
    @Synchronized
    fun registrar(nome: String, email: String, senha: String, convite: String): String {
        return try {
        val n = nome.trim()
        val e = email.trim().lowercase()
        if (!Regex("[a-zA-Z0-9_.-]{3,20}").matches(n)) return erro("Use um nome de usuário com 3 a 20 letras, números, ponto, hífen ou sublinhado.")
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(e).matches()) return erro("E-mail inválido.")
        if (senha.length < 8) return erro("A senha precisa ter pelo menos 8 caracteres.")
        if (convite.trim().uppercase() != "TIKBETA") return erro("Código de convite inválido.")
        val body = JSONObject().put("name", n).put("email", e).put("password", senha).put("inviteCode", convite.trim())
        val created = request("POST", "$BASE_URL/functions/v1/register-with-invite", body)
        if (created.first !in 200..299) return erro(mensagem(created.second, "Não foi possível criar a conta."))
        autenticar(e, senha)
    } catch (t: Throwable) { erro(t.message ?: "Falha ao cadastrar.") }
    }

    @JavascriptInterface
    @Synchronized
    fun entrar(email: String, senha: String): String {
        return try {
        val e = email.trim().lowercase()
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(e).matches()) return erro("Informe um e-mail válido.")
        autenticar(e, senha)
    } catch (t: Throwable) { erro(t.message ?: "Falha no login.") }
    }

    @JavascriptInterface
    @Synchronized
    fun obterAccessToken(): String {
        return try {
        val token = decrypt("token") ?: return ""
        val exp = jwtExpiry(token)
        if (exp > System.currentTimeMillis() / 1000 + 90) return token
        val refresh = decrypt("refresh") ?: return ""
        val result = request("POST", "$BASE_URL/auth/v1/token?grant_type=refresh_token", JSONObject().put("refresh_token", refresh))
        if (result.first !in 200..299) {
            prefs.edit().clear().apply()
            return ""
        }
        val data = JSONObject(result.second)
        val access = data.optString("access_token")
        val newRefresh = data.optString("refresh_token")
        if (access.isBlank() || newRefresh.isBlank()) return ""
        saveEncrypted("token", access)
        saveEncrypted("refresh", newRefresh)
        access
    } catch (_: Throwable) { "" }
    }

    @JavascriptInterface fun temSessao(): Boolean = obterAccessToken().isNotBlank()
    @JavascriptInterface fun emailAtual(): String = decrypt("email") ?: ""
    @JavascriptInterface fun userIdAtual(): String = decrypt("user_id") ?: ""

    @JavascriptInterface
    @Synchronized
    fun sair(): String {
        try {
            val token = decrypt("token")
            if (!token.isNullOrBlank()) request("POST", "$BASE_URL/auth/v1/logout", JSONObject(), token)
        } catch (_: Throwable) { }
        prefs.edit().clear().apply()
        return "{\"ok\":true}"
    }

    private fun autenticar(email: String, senha: String): String {
        val result = request("POST", "$BASE_URL/auth/v1/token?grant_type=password", JSONObject().put("email", email).put("password", senha))
        if (result.first !in 200..299) return erro(mensagem(result.second, "E-mail ou senha incorretos."))
        val data = JSONObject(result.second)
        val access = data.optString("access_token")
        val refresh = data.optString("refresh_token")
        if (access.isBlank() || refresh.isBlank()) return erro("A Supabase não retornou uma sessão. Verifique a confirmação de e-mail no Auth.")
        val user = data.optJSONObject("user") ?: JSONObject()
        val userId = user.optString("id")
        if (userId.isBlank()) return erro("A Supabase não retornou o identificador da conta.")
        saveEncrypted("token", access)
        saveEncrypted("refresh", refresh)
        saveEncrypted("email", email)
        saveEncrypted("user_id", userId)
        return """{"ok":true,"userId":${JSONObject.quote(userId)},"email":${JSONObject.quote(email)}}"""
    }

    private fun request(method: String, endpoint: String, body: JSONObject, bearer: String? = null): Pair<Int, String> {
        val conn = URL(endpoint).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = method
            conn.connectTimeout = 15000
            conn.readTimeout = 20000
            conn.setRequestProperty("apikey", PUBLISHABLE_KEY)
            conn.setRequestProperty("Authorization", "Bearer ${bearer ?: PUBLISHABLE_KEY}")
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("Accept", "application/json")
            conn.doOutput = true
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            return code to (stream?.bufferedReader()?.use { it.readText() } ?: "{}")
        } finally { conn.disconnect() }
    }

    private fun jwtExpiry(token: String): Long = try {
        val part = token.split('.')[1]
        val json = JSONObject(String(Base64.decode(part, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING), Charsets.UTF_8))
        json.optLong("exp", 0)
    } catch (_: Throwable) { 0 }

    private fun mensagem(raw: String, fallback: String): String = try {
        val j = JSONObject(raw)
        j.optString("msg").takeIf { it.isNotBlank() }
            ?: j.optString("message").takeIf { it.isNotBlank() }
            ?: j.optString("error_description").takeIf { it.isNotBlank() }
            ?: j.optString("error").takeIf { it.isNotBlank() } ?: fallback
    } catch (_: Exception) { fallback }

    private fun erro(msg: String) = """{"ok":false,"erro":${JSONObject.quote(msg)}}"""

    private fun saveEncrypted(name: String, value: String) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getKey())
        val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        prefs.edit().putString(name, Base64.encodeToString(cipher.iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(encrypted, Base64.NO_WRAP)).apply()
    }

    private fun decrypt(name: String): String? {
        return try {
            val raw = prefs.getString(name, null) ?: return null
            val parts = raw.split(":", limit = 2)
            if (parts.size != 2) return null
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, getKey(), GCMParameterSpec(128, Base64.decode(parts[0], Base64.NO_WRAP)))
            String(cipher.doFinal(Base64.decode(parts[1], Base64.NO_WRAP)), Charsets.UTF_8)
        } catch (_: Throwable) { null }
    }

    private fun getKey(): SecretKey {
        val ks = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true).build())
        return generator.generateKey()
    }

    companion object {
        const val BASE_URL = "https://fpqzxqkgkpkbykfceihb.supabase.co"
        const val PUBLISHABLE_KEY = "sb_publishable_3B2nNM9mJqpXXYy5xQxVJw_tmkxaZhx"
        private const val KEY_ALIAS = "tikmusic_supabase_session_v1"
    }
}
