package br.com.botmusica.app.streaming;

import android.graphics.Bitmap;
import com.pedro.encoder.input.gl.render.filters.BaseFilterRender;
import com.pedro.encoder.input.gl.render.filters.object.ImageObjectFilterRender;

/**
 * Ponte Java para o filtro de imagem do RootEncoder.
 * O pacote Java "object" quebra o import Kotlin com backticks em alguns
 * compiladores (Internal compiler error). Em Java o nome é legal.
 */
public final class ImageFilterHelper {
    private ImageFilterHelper() {}

    public static BaseFilterRender create(Bitmap bitmap) {
        ImageObjectFilterRender filter = new ImageObjectFilterRender();
        if (bitmap != null) {
            filter.setImage(bitmap);
        }
        return filter;
    }

    public static void setImage(BaseFilterRender filter, Bitmap bitmap) {
        if (filter instanceof ImageObjectFilterRender && bitmap != null) {
            ((ImageObjectFilterRender) filter).setImage(bitmap);
        }
    }

    public static void setScale(BaseFilterRender filter, float scaleX, float scaleY) {
        if (filter instanceof ImageObjectFilterRender) {
            ((ImageObjectFilterRender) filter).setScale(scaleX, scaleY);
        }
    }

    public static void setPosition(BaseFilterRender filter, float x, float y) {
        if (filter instanceof ImageObjectFilterRender) {
            ((ImageObjectFilterRender) filter).setPosition(x, y);
        }
    }
}
