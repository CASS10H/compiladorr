package br.com.botmusica.app.streaming

/**
 * Configuração de uma transmissão ao vivo.
 * Serializável para JSON (painel Web + SharedPreferences).
 */
data class StreamConfig(
    val rtmpUrl: String = "",
    val streamKey: String = "",
    val width: Int = 1280,
    val height: Int = 720,
    val videoBitrate: Int = 2_500_000,   // 2.5 Mbps
    val audioBitrate: Int = 128_000,     // 128 kbps
    val fps: Int = 30,
    val cameraFacing: String = "front",  // "front" | "back"
    val rotation: Int = 0,
    val iFrameInterval: Int = 2
) {
    fun fullRtmpUrl(): String {
        val base = rtmpUrl.trim().trimEnd('/')
        val key = streamKey.trim()
        return if (key.isEmpty()) base else "$base/$key"
    }

    fun isValid(): Boolean {
        val url = fullRtmpUrl()
        return url.startsWith("rtmp://") || url.startsWith("rtmps://")
    }

    companion object {
        val PRESETS = mapOf(
            "720p30" to StreamConfig(width = 1280, height = 720, fps = 30, videoBitrate = 2_500_000),
            "720p60" to StreamConfig(width = 1280, height = 720, fps = 60, videoBitrate = 4_000_000),
            "1080p30" to StreamConfig(width = 1920, height = 1080, fps = 30, videoBitrate = 4_500_000),
            "480p30" to StreamConfig(width = 854, height = 480, fps = 30, videoBitrate = 1_200_000)
        )
    }
}

/**
 * Estado atual do streamer (exposto para o painel via JS bridge).
 */
data class StreamState(
    val isStreaming: Boolean = false,
    val isPreviewing: Boolean = false,
    val connected: Boolean = false,
    val bitrate: Long = 0,
    val fps: Float = 0f,
    val droppedFrames: Long = 0,
    val durationMs: Long = 0,
    val error: String? = null
)
