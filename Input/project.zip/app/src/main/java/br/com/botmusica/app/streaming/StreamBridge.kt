package br.com.botmusica.app.streaming

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.IBinder
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject

/**
 * Ponte JavaScript ↔ StreamService + SceneStore.
 * Exposta no WebView como `window.TikMusicStream`.
 */
class StreamBridge(
    private val context: Context,
    private val webView: WebView
) {
    private var service: StreamService? = null
    private var bound = false
    private val sceneStore = SceneStore(context.applicationContext)

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val local = binder as? StreamService.LocalBinder ?: return
            service = local.getService()
            bound = true
            service?.onStateChanged = { state -> pushStateToJs(state) }
            // Aplica cena ativa (facing da câmera etc.)
            service?.applyScene(sceneStore.active())
            service?.getState()?.let { pushStateToJs(it) }
            Log.i(TAG, "StreamService conectado")
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            service = null
            bound = false
        }
    }

    fun bind() {
        val intent = Intent(context, StreamService::class.java)
        context.startForegroundService(intent)
        context.bindService(intent, connection, Context.BIND_AUTO_CREATE)
    }

    fun unbind() {
        if (bound) {
            try {
                context.unbindService(connection)
            } catch (_: Exception) {
            }
            bound = false
            service = null
        }
    }

    // ── Stream ───────────────────────────────────────────────────────────────

    @JavascriptInterface
    fun isReady(): Boolean = bound && service != null

    @JavascriptInterface
    fun getState(): String {
        val s = service?.getState() ?: StreamState()
        return stateToJson(s).toString()
    }

    @JavascriptInterface
    fun getConfig(): String {
        val c = service?.getConfig() ?: StreamConfig()
        return configToJson(c).toString()
    }

    @JavascriptInterface
    fun updateConfig(json: String): String {
        return try {
            val o = JSONObject(json)
            val current = service?.getConfig() ?: StreamConfig()
            val updated = current.copy(
                rtmpUrl = o.optString("rtmpUrl", current.rtmpUrl),
                streamKey = o.optString("streamKey", current.streamKey),
                width = o.optInt("width", current.width),
                height = o.optInt("height", current.height),
                videoBitrate = o.optInt("videoBitrate", current.videoBitrate),
                audioBitrate = o.optInt("audioBitrate", current.audioBitrate),
                fps = o.optInt("fps", current.fps),
                cameraFacing = o.optString("cameraFacing", current.cameraFacing)
            )
            service?.updateConfig(updated)
            JSONObject().put("ok", true).put("config", configToJson(updated)).toString()
        } catch (e: Exception) {
            JSONObject().put("ok", false).put("error", e.message ?: "erro").toString()
        }
    }

    @JavascriptInterface
    fun startStream(): String {
        val svc = service
        if (svc == null) {
            return JSONObject().put("ok", false).put("error", "Serviço não conectado").toString()
        }
        if (!svc.getConfig().isValid()) {
            return JSONObject()
                .put("ok", false)
                .put("error", "Configure a URL RTMP e a Stream Key antes de ir ao vivo")
                .toString()
        }
        svc.applyScene(sceneStore.active())
        svc.startStream()
        return JSONObject().put("ok", true).toString()
    }

    @JavascriptInterface
    fun stopStream(): String {
        service?.stopStream()
        return JSONObject().put("ok", true).toString()
    }

    @JavascriptInterface
    fun startPreview(): String {
        service?.applyScene(sceneStore.active())
        service?.startPreview()
        return JSONObject().put("ok", true).toString()
    }

    @JavascriptInterface
    fun stopPreview(): String {
        service?.stopPreview()
        return JSONObject().put("ok", true).toString()
    }

    @JavascriptInterface
    fun switchCamera(): String {
        service?.switchCamera()
        return JSONObject().put("ok", true).toString()
    }

    @JavascriptInterface
    fun reloadOverlays(): String {
        val svc = service ?: return "{\"ok\":false}"
        svc.applyScene(sceneStore.active())
        svc.reloadOverlays()
        return "{\"ok\":true}"
    }

    /** Fase 3: {"composed": n} = camadas compostas no encoder agora. */
    @JavascriptInterface
    fun getComposeInfo(): String {
        val n = service?.composedLayers() ?: 0
        return "{\"composed\":$n,\"overlayFps\":${SceneCompositor.OVERLAY_FPS}}"
    }

    @JavascriptInterface
    fun openPreview(): String {
        return try {
            val i = Intent(context, StreamPreviewActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(i)
            JSONObject().put("ok", true).toString()
        } catch (e: Exception) {
            JSONObject().put("ok", false).put("error", e.message ?: "erro").toString()
        }
    }

    // ── Cenas ────────────────────────────────────────────────────────────────

    @JavascriptInterface
    fun listScenes(): String {
        val arr = JSONArray()
        sceneStore.list().forEach { arr.put(SceneStore.sceneToJson(it)) }
        return JSONObject()
            .put("ok", true)
            .put("activeSceneId", sceneStore.activeSceneId)
            .put("scenes", arr)
            .toString()
    }

    @JavascriptInterface
    fun getActiveScene(): String {
        val scene = sceneStore.active()
        return if (scene != null) {
            JSONObject().put("ok", true).put("scene", SceneStore.sceneToJson(scene)).toString()
        } else {
            JSONObject().put("ok", false).put("error", "Nenhuma cena").toString()
        }
    }

    @JavascriptInterface
    fun setActiveScene(id: String): String {
        val ok = sceneStore.setActive(id)
        if (ok) service?.applyScene(sceneStore.active())
        return JSONObject().put("ok", ok).put("activeSceneId", sceneStore.activeSceneId).toString()
    }

    @JavascriptInterface
    fun createScene(name: String): String {
        val scene = sceneStore.create(name)
        return JSONObject().put("ok", true).put("scene", SceneStore.sceneToJson(scene)).toString()
    }

    @JavascriptInterface
    fun saveScene(json: String): String {
        return try {
            val scene = SceneStore.sceneFromJson(JSONObject(json))
            sceneStore.upsert(scene)
            if (scene.id == sceneStore.activeSceneId) {
                service?.applyScene(scene)
            }
            JSONObject().put("ok", true).put("scene", SceneStore.sceneToJson(scene)).toString()
        } catch (e: Exception) {
            JSONObject().put("ok", false).put("error", e.message ?: "erro").toString()
        }
    }

    @JavascriptInterface
    fun deleteScene(id: String): String {
        val ok = sceneStore.delete(id)
        if (ok) service?.applyScene(sceneStore.active())
        return JSONObject()
            .put("ok", ok)
            .put("activeSceneId", sceneStore.activeSceneId)
            .toString()
    }

    @JavascriptInterface
    fun duplicateScene(id: String): String {
        val copy = sceneStore.duplicate(id)
        return if (copy != null) {
            JSONObject().put("ok", true).put("scene", SceneStore.sceneToJson(copy)).toString()
        } else {
            JSONObject().put("ok", false).put("error", "Cena não encontrada").toString()
        }
    }

    @JavascriptInterface
    fun exportScenes(): String = sceneStore.exportAll()

    @JavascriptInterface
    fun importScenes(json: String): String {
        val ok = sceneStore.importAll(json)
        if (ok) service?.applyScene(sceneStore.active())
        return JSONObject().put("ok", ok).toString()
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private fun pushStateToJs(state: StreamState) {
        val json = stateToJson(state).toString()
        webView.post {
            webView.evaluateJavascript(
                "window.__onStreamState && window.__onStreamState($json);",
                null
            )
        }
    }

    private fun stateToJson(s: StreamState): JSONObject = JSONObject()
        .put("isStreaming", s.isStreaming)
        .put("isPreviewing", s.isPreviewing)
        .put("connected", s.connected)
        .put("bitrate", s.bitrate)
        .put("fps", s.fps.toDouble())
        .put("droppedFrames", s.droppedFrames)
        .put("durationMs", s.durationMs)
        .put("error", s.error)

    private fun configToJson(c: StreamConfig): JSONObject = JSONObject()
        .put("rtmpUrl", c.rtmpUrl)
        .put("streamKey", c.streamKey)
        .put("width", c.width)
        .put("height", c.height)
        .put("videoBitrate", c.videoBitrate)
        .put("audioBitrate", c.audioBitrate)
        .put("fps", c.fps)
        .put("cameraFacing", c.cameraFacing)
        .put("fullUrl", c.fullRtmpUrl())
        .put("valid", c.isValid())

    companion object {
        private const val TAG = "TIKMUSIC.StreamBridge"
    }
}
