package br.com.botmusica.app.streaming

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.graphics.Color
import android.os.Bundle
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.pedro.library.view.OpenGlView

/**
 * Preview da câmera. Desde a Fase 3 os overlays (HTML/imagem/texto) são compostos
 * no próprio pipeline OpenGL ([SceneCompositor]), então o OpenGlView já mostra
 * exatamente o que vai para o RTMP. Não há mais views sobrepostas aqui.
 */
class StreamPreviewActivity : Activity() {

    private var service: StreamService? = null
    private var bound = false
    private lateinit var openGlView: OpenGlView
    private lateinit var overlayContainer: FrameLayout
    private lateinit var statusText: TextView
    private lateinit var btnLive: Button
    private val sceneStore by lazy { SceneStore(applicationContext) }
    private val overlayViews = mutableListOf<View>()

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val local = binder as? StreamService.LocalBinder ?: return
            service = local.getService()
            bound = true
            service?.attachPreview(openGlView)
            service?.applyScene(sceneStore.active())
            service?.onStateChanged = { state -> runOnUiThread { renderState(state) } }
            service?.getState()?.let { renderState(it) }
            service?.startPreview()
            applyOverlays()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            service = null
            bound = false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this).apply {
            setBackgroundColor(0xFF0A0810.toInt())
        }

        openGlView = OpenGlView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        root.addView(openGlView)

        // Container para overlays HTML/texto da cena
        overlayContainer = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            // não intercepta toques nos controles
            isClickable = false
        }
        root.addView(overlayContainer)

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 48)
            setBackgroundColor(0xCC0A0810.toInt())
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM
            )
        }

        statusText = TextView(this).apply {
            text = "Conectando…"
            setTextColor(0xFFF5F3FB.toInt())
            textSize = 14f
            setPadding(0, 0, 0, 16)
        }
        controls.addView(statusText)

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        btnLive = button("Ir ao vivo").also { b ->
            b.setBackgroundColor(0xFFFE2C55.toInt())
            b.setOnClickListener { toggleLive() }
        }
        val btnSwitch = button("Trocar câmera").also { b ->
            b.setOnClickListener {
                service?.switchCamera()
            }
        }
        val btnReload = button("Overlays").also { b ->
            b.setOnClickListener { applyOverlays() }
        }
        val btnClose = button("Fechar").also { b ->
            b.setOnClickListener { finish() }
        }

        fun lp() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginEnd = 6
        }
        row.addView(btnLive, lp())
        row.addView(btnSwitch, lp())
        row.addView(btnReload, lp())
        row.addView(btnClose, lp())
        controls.addView(row)
        root.addView(controls)
        setContentView(root)

        val intent = Intent(this, StreamService::class.java)
        ContextCompat.startForegroundService(this, intent)
        bindService(intent, connection, Context.BIND_AUTO_CREATE)
    }

    private fun applyOverlays() {
        // Fase 3: recarrega a composição no encoder (preview e RTMP)
        overlayViews.forEach { overlayContainer.removeView(it) }
        overlayViews.clear()
        service?.applyScene(sceneStore.active())
        service?.reloadOverlays()
    }

    @Suppress("unused")
    private fun applyOverlaysLegacyView() {
        overlayViews.forEach { overlayContainer.removeView(it) }
        overlayViews.clear()

        val scene = sceneStore.active() ?: return
        val w = overlayContainer.width.takeIf { it > 0 } ?: resources.displayMetrics.widthPixels
        val h = overlayContainer.height.takeIf { it > 0 } ?: resources.displayMetrics.heightPixels

        scene.sources
            .filter { it.visible }
            .sortedBy { it.zIndex }
            .forEach { src ->
                when (src) {
                    is Source.WebOverlay -> {
                        val web = WebView(this).apply {
                            setBackgroundColor(Color.TRANSPARENT)
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.mediaPlaybackRequiresUserGesture = false
                            settings.cacheMode = WebSettings.LOAD_NO_CACHE
                            // transparente para ver a câmera atrás
                            setLayerType(View.LAYER_TYPE_HARDWARE, null)
                            webViewClient = WebViewClient()
                            loadUrl(src.url)
                        }
                        val lp = FrameLayout.LayoutParams(
                            (src.width * w).toInt().coerceAtLeast(1),
                            (src.height * h).toInt().coerceAtLeast(1)
                        ).apply {
                            leftMargin = (src.x * w).toInt()
                            topMargin = (src.y * h).toInt()
                        }
                        web.alpha = src.opacity
                        overlayContainer.addView(web, lp)
                        overlayViews.add(web)
                    }
                    is Source.Text -> {
                        val tv = TextView(this).apply {
                            text = src.text
                            setTextColor(parseColor(src.color, 0xFFFFFFFF.toInt()))
                            textSize = src.fontSize / resources.displayMetrics.scaledDensity
                            setBackgroundColor(parseColor(src.backgroundColor, 0x80000000.toInt()))
                            setPadding(16, 8, 16, 8)
                            alpha = src.opacity
                        }
                        val lp = FrameLayout.LayoutParams(
                            (src.width * w).toInt().coerceAtLeast(1),
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply {
                            leftMargin = (src.x * w).toInt()
                            topMargin = (src.y * h).toInt()
                        }
                        overlayContainer.addView(tv, lp)
                        overlayViews.add(tv)
                    }
                    else -> { /* camera já está no OpenGlView; image na Fase 3 */ }
                }
            }
    }

    private fun parseColor(hex: String, fallback: Int): Int =
        SceneCompositor.parseColor(hex, fallback)

    private fun button(label: String): Button = Button(this).apply {
        text = label
        setTextColor(0xFFFFFFFF.toInt())
        setBackgroundColor(0xFF272240.toInt())
        isAllCaps = false
        textSize = 12f
        minHeight = (44 * resources.displayMetrics.density).toInt()
    }

    private fun toggleLive() {
        val s = service ?: return
        if (s.isStreaming()) s.stopStream() else {
            s.applyScene(sceneStore.active())
            s.startStream()
        }
    }

    private fun renderState(state: StreamState) {
        val live = state.isStreaming
        val conn = state.connected
        statusText.text = when {
            live && conn -> "AO VIVO • ${state.bitrate / 1000} kbps • ${fmt(state.durationMs)}"
            live -> "Conectando…"
            state.isPreviewing -> {
                val scene = sceneStore.active()?.name ?: "—"
                "Preview • cena: $scene"
            }
            else -> state.error ?: "Parado"
        }
        btnLive.text = if (live) "Encerrar" else "Ir ao vivo"
        btnLive.setBackgroundColor(if (live) 0xFFB91C1C.toInt() else 0xFFFE2C55.toInt())
    }

    private fun fmt(ms: Long): String {
        if (ms <= 0) return "0:00"
        val s = (ms / 1000).toInt()
        val m = s / 60
        return "$m:${(s % 60).toString().padStart(2, '0')}"
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            // re-layout overlays quando o container tem tamanho real
            // nada a fazer: overlays vivem no pipeline do encoder
        }
    }

    override fun onDestroy() {
        service?.attachPreview(null)
        service?.onStateChanged = null
        if (bound) {
            try {
                unbindService(connection)
            } catch (_: Exception) {
            }
            bound = false
        }
        super.onDestroy()
    }
}
