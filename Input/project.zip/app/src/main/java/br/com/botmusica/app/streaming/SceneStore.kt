package br.com.botmusica.app.streaming

import android.content.Context
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * Persistência de cenas em SharedPreferences (JSON).
 * Também mantém a cena ativa em memória.
 */
class SceneStore(context: Context) {

    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Volatile
    private var scenes: MutableList<Scene> = loadFromDisk().toMutableList()

    @Volatile
    var activeSceneId: String = prefs.getString(KEY_ACTIVE, null)
        ?: scenes.firstOrNull()?.id
        ?: ""
        private set

    fun list(): List<Scene> = scenes.toList()

    fun get(id: String): Scene? = scenes.find { it.id == id }

    fun active(): Scene? = get(activeSceneId) ?: scenes.firstOrNull()

    fun setActive(id: String): Boolean {
        if (scenes.none { it.id == id }) return false
        activeSceneId = id
        prefs.edit().putString(KEY_ACTIVE, id).apply()
        return true
    }

    fun upsert(scene: Scene): Scene {
        val idx = scenes.indexOfFirst { it.id == scene.id }
        if (idx >= 0) scenes[idx] = scene else scenes.add(scene)
        persist()
        return scene
    }

    fun create(name: String): Scene {
        val scene = Scene(
            id = "cena-${UUID.randomUUID().toString().take(8)}",
            name = name.ifBlank { "Nova cena" },
            sources = listOf(
                Source.Camera(
                    id = "cam-${UUID.randomUUID().toString().take(6)}",
                    name = "Câmera",
                    facing = "front",
                    zIndex = 0
                )
            )
        )
        scenes.add(scene)
        persist()
        return scene
    }

    fun delete(id: String): Boolean {
        if (scenes.size <= 1) return false // mantém pelo menos uma
        val removed = scenes.removeAll { it.id == id }
        if (removed) {
            if (activeSceneId == id) {
                activeSceneId = scenes.first().id
                prefs.edit().putString(KEY_ACTIVE, activeSceneId).apply()
            }
            persist()
        }
        return removed
    }

    fun duplicate(id: String): Scene? {
        val src = get(id) ?: return null
        val copy = src.copy(
            id = "cena-${UUID.randomUUID().toString().take(8)}",
            name = "${src.name} (cópia)",
            sources = src.sources.map { duplicateSource(it) }
        )
        scenes.add(copy)
        persist()
        return copy
    }

    private fun duplicateSource(s: Source): Source = when (s) {
        is Source.Camera -> s.copy(id = "cam-${UUID.randomUUID().toString().take(6)}")
        is Source.Image -> s.copy(id = "img-${UUID.randomUUID().toString().take(6)}")
        is Source.WebOverlay -> s.copy(id = "web-${UUID.randomUUID().toString().take(6)}")
        is Source.Text -> s.copy(id = "txt-${UUID.randomUUID().toString().take(6)}")
    }

    // ── JSON ─────────────────────────────────────────────────────────────────

    fun toJsonArray(): JSONArray {
        val arr = JSONArray()
        scenes.forEach { arr.put(sceneToJson(it)) }
        return arr
    }

    fun exportAll(): String {
        return JSONObject()
            .put("activeSceneId", activeSceneId)
            .put("scenes", toJsonArray())
            .toString()
    }

    fun importAll(json: String): Boolean {
        return try {
            val root = JSONObject(json)
            val arr = root.getJSONArray("scenes")
            val loaded = mutableListOf<Scene>()
            for (i in 0 until arr.length()) {
                loaded.add(sceneFromJson(arr.getJSONObject(i)))
            }
            if (loaded.isEmpty()) return false
            scenes = loaded
            activeSceneId = root.optString("activeSceneId", loaded.first().id)
            if (scenes.none { it.id == activeSceneId }) {
                activeSceneId = scenes.first().id
            }
            persist()
            true
        } catch (e: Exception) {
            Log.e(TAG, "importAll", e)
            false
        }
    }

    private fun persist() {
        prefs.edit()
            .putString(KEY_SCENES, toJsonArray().toString())
            .putString(KEY_ACTIVE, activeSceneId)
            .apply()
    }

    private fun loadFromDisk(): List<Scene> {
        val raw = prefs.getString(KEY_SCENES, null)
        if (raw.isNullOrBlank()) return DefaultScenes.createDefault()
        return try {
            val arr = JSONArray(raw)
            val list = mutableListOf<Scene>()
            for (i in 0 until arr.length()) {
                list.add(sceneFromJson(arr.getJSONObject(i)))
            }
            if (list.isEmpty()) DefaultScenes.createDefault() else list
        } catch (e: Exception) {
            Log.e(TAG, "loadFromDisk", e)
            DefaultScenes.createDefault()
        }
    }

    companion object {
        private const val TAG = "TIKMUSIC.SceneStore"
        private const val PREFS = "tikmusic_scenes"
        private const val KEY_SCENES = "scenes_json"
        private const val KEY_ACTIVE = "active_scene_id"

        fun sceneToJson(scene: Scene): JSONObject {
            val sources = JSONArray()
            scene.sources.sortedBy { it.zIndex }.forEach { sources.put(sourceToJson(it)) }
            return JSONObject()
                .put("id", scene.id)
                .put("name", scene.name)
                .put("sources", sources)
        }

        fun sceneFromJson(o: JSONObject): Scene {
            val sources = mutableListOf<Source>()
            val arr = o.optJSONArray("sources") ?: JSONArray()
            for (i in 0 until arr.length()) {
                sourceFromJson(arr.getJSONObject(i))?.let { sources.add(it) }
            }
            return Scene(
                id = o.getString("id"),
                name = o.optString("name", "Cena"),
                sources = sources
            )
        }

        fun sourceToJson(s: Source): JSONObject {
            val base = JSONObject()
                .put("id", s.id)
                .put("name", s.name)
                .put("visible", s.visible)
                .put("x", s.x.toDouble())
                .put("y", s.y.toDouble())
                .put("width", s.width.toDouble())
                .put("height", s.height.toDouble())
                .put("opacity", s.opacity.toDouble())
                .put("zIndex", s.zIndex)
            return when (s) {
                is Source.Camera -> base
                    .put("type", "camera")
                    .put("facing", s.facing)
                is Source.Image -> base
                    .put("type", "image")
                    .put("uri", s.uri)
                is Source.WebOverlay -> base
                    .put("type", "web")
                    .put("url", s.url)
                is Source.Text -> base
                    .put("type", "text")
                    .put("text", s.text)
                    .put("fontSize", s.fontSize.toDouble())
                    .put("color", s.color)
                    .put("backgroundColor", s.backgroundColor)
            }
        }

        fun sourceFromJson(o: JSONObject): Source? {
            val id = o.optString("id", UUID.randomUUID().toString().take(8))
            val name = o.optString("name", "Fonte")
            val visible = o.optBoolean("visible", true)
            val x = o.optDouble("x", 0.0).toFloat()
            val y = o.optDouble("y", 0.0).toFloat()
            val w = o.optDouble("width", 1.0).toFloat()
            val h = o.optDouble("height", 1.0).toFloat()
            val opacity = o.optDouble("opacity", 1.0).toFloat()
            val z = o.optInt("zIndex", 0)
            return when (o.optString("type", "camera")) {
                "camera" -> Source.Camera(id, name, visible, x, y, w, h, opacity, z, o.optString("facing", "front"))
                "image" -> Source.Image(id, name, visible, x, y, w, h, opacity, z, o.optString("uri", ""))
                "web" -> Source.WebOverlay(id, name, visible, x, y, w, h, opacity, z, o.optString("url", "http://127.0.0.1:8000/overlay-unificado.html"))
                "text" -> Source.Text(
                    id, name, visible, x, y, w, h, opacity, z,
                    o.optString("text", ""),
                    o.optDouble("fontSize", 32.0).toFloat(),
                    o.optString("color", "#FFFFFF"),
                    o.optString("backgroundColor", "#00000080")
                )
                else -> null
            }
        }
    }
}
