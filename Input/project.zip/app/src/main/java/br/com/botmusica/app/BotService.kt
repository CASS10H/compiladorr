package br.com.botmusica.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.io.File

class BotService : Service() {
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIF_ID, notification("Iniciando o mecanismo local…"))
        acquireWakeLock()
        Thread {
            try {
                copyAssets("bot-musica", File(filesDir, "bot-musica"))
                if (!Python.isStarted()) Python.start(AndroidPlatform(this))
                Python.getInstance()
                    .getModule("app")
                    .callAttr("start", File(filesDir, "bot-musica").absolutePath)
                updateNotification("Ativo neste celular")
            } catch (e: Exception) {
                updateNotification("Erro ao iniciar: ${e.message ?: "verifique os arquivos"}")
                android.util.Log.e("TIKMUSIC", "Falha ao iniciar Python", e)
            }
        }.start()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            releaseWakeLock()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            // Encerra também o servidor Python (thread daemon) junto com o processo.
            android.os.Process.killProcess(android.os.Process.myPid())
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    private fun acquireWakeLock() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "TIKMUSIC::bot").apply {
                setReferenceCounted(false)
                acquire(12 * 60 * 60 * 1000L) // no máximo 12 h por vez
            }
        } catch (e: Exception) {
            android.util.Log.w("TIKMUSIC", "WakeLock indisponível", e)
        }
    }

    private fun releaseWakeLock() {
        try {
            wakeLock?.let { if (it.isHeld) it.release() }
        } catch (_: Exception) {
        }
        wakeLock = null
    }

    private fun copyAssets(assetPath: String, destination: File) {
        destination.mkdirs()
        val children = assets.list(assetPath) ?: emptyArray()
        for (child in children) {
            val childAsset = "$assetPath/$child"
            val out = File(destination, child)
            val nested = assets.list(childAsset) ?: emptyArray()
            if (nested.isNotEmpty()) {
                copyAssets(childAsset, out)
            } else {
                assets.open(childAsset).use { input ->
                    out.outputStream().use { output -> input.copyTo(output) }
                }
            }
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "TIKMUSIC em execução",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(message: String): Notification {
        val openApp = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, BotService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopAction = Notification.Action.Builder(
            Icon.createWithResource(this, R.drawable.ic_stat_tikmusic), "Parar", stop
        ).build()
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, CHANNEL_ID)
        else Notification.Builder(this)
        return builder.setContentTitle("TIKMUSIC")
            .setContentText(message)
            .setSmallIcon(R.drawable.ic_stat_tikmusic)
            .setContentIntent(openApp)
            .addAction(stopAction)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(message: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, notification(message))
    }

    override fun onDestroy() {
        releaseWakeLock()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL_ID = "bot_musica_local"
        private const val NOTIF_ID = 42
        private const val ACTION_STOP = "br.com.botmusica.app.STOP"
    }
}
