package br.com.botmusica.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.DocumentsContract
import android.view.WindowInsets
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.MimeTypeMap
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import br.com.botmusica.app.streaming.StreamBridge
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var tentativas = 0
    private var streamBridge: StreamBridge? = null

    // Seletor de arquivos (<input type="file"> do painel)
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    // Download manual aguardando o usuário escolher onde salvar
    private var pendingDownloadToken: String? = null

    // Exportação de texto (CSV/TXT) aguardando o usuário escolher onde salvar
    private var pendingExportContent: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        askNotificationPermission()
        askStreamPermissions()
        val service = Intent(this, BotService::class.java)
        ContextCompat.startForegroundService(this, service)

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.addJavascriptInterface(TikMusicAuth(this), "TikMusicAuth")
        web.addJavascriptInterface(FilesBridge(), "TikMusicFiles")

        // Ponte de transmissão (câmera / RTMP)
        streamBridge = StreamBridge(this, web).also {
            web.addJavascriptInterface(it, "TikMusicStream")
            it.bind()
        }

        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.settings.allowFileAccess = false
        // Necessário para o WebView ler os arquivos content:// devolvidos pelo seletor do Android.
        web.settings.allowContentAccess = true
        web.setBackgroundColor(ContextCompat.getColor(this, R.color.tikmusic_bg))
        web.webChromeClient = object : WebChromeClient() {
            // Sem este método o <input type="file"> do WebView simplesmente não abre nada.
            override fun onShowFileChooser(
                webView: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: FileChooserParams?
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, mimeTypesFrom(params?.acceptTypes))
                    putExtra(
                        Intent.EXTRA_ALLOW_MULTIPLE,
                        params?.mode == FileChooserParams.MODE_OPEN_MULTIPLE
                    )
                }
                return try {
                    startActivityForResult(intent, REQ_PICK)
                    true
                } catch (e: Exception) {
                    filePathCallback = null
                    callback?.onReceiveValue(null)
                    Toast.makeText(
                        this@MainActivity,
                        "Não foi possível abrir o seletor de arquivos do Android.",
                        Toast.LENGTH_LONG
                    ).show()
                    false
                }
            }
        }
        web.webViewClient = object : WebViewClient() {
            override fun onReceivedError(
                view: WebView?, request: WebResourceRequest?, error: WebResourceError?
            ) {
                // O servidor local leva alguns segundos para subir: tenta de novo, sem repetir o aviso.
                if (request?.isForMainFrame == true && tentativas < MAX_TENTATIVAS) {
                    if (tentativas == 0) {
                        Toast.makeText(this@MainActivity, "Iniciando o TIKMUSIC…", Toast.LENGTH_SHORT).show()
                    }
                    tentativas++
                    web.postDelayed({ web.loadUrl(URL_LOCAL) }, 1800)
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                tentativas = 0
            }

            // Links para fora do painel (ex.: TikTok, YouTube) abrem no navegador, não dentro do app.
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                if (uri.host == "127.0.0.1" || uri.host == "localhost") return false
                return try {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                    true
                } catch (_: Exception) {
                    false
                }
            }
        }
        CookieManager.getInstance().setAcceptCookie(true)

        // Android 15 (targetSdk 35) desenha o app sob as barras do sistema: reserva o espaço delas.
        val root = FrameLayout(this)
        root.setBackgroundColor(ContextCompat.getColor(this, R.color.tikmusic_bg))
        root.setOnApplyWindowInsetsListener { v, insets ->
            if (Build.VERSION.SDK_INT >= 30) {
                val bars = insets.getInsets(
                    WindowInsets.Type.systemBars() or
                        WindowInsets.Type.displayCutout() or
                        WindowInsets.Type.ime()
                )
                v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            } else {
                @Suppress("DEPRECATION")
                v.setPadding(
                    insets.systemWindowInsetLeft, insets.systemWindowInsetTop,
                    insets.systemWindowInsetRight, insets.systemWindowInsetBottom
                )
            }
            insets
        }
        root.addView(web)
        setContentView(root)
        web.loadUrl(URL_LOCAL)
    }

    // Converte o atributo accept do <input> (extensões como .csv/.txt ou tipos MIME) em tipos MIME para o seletor.
    // Obs.: não escrever barra+asterisco dentro de comentários /** */ — em Kotlin eles aninham e quebram a compilação.
    private fun mimeTypesFrom(accept: Array<String>?): Array<String> {
        val out = linkedSetOf<String>()
        accept?.map { it.trim().lowercase() }?.filter { it.isNotEmpty() }?.forEach { a ->
            if (a.startsWith(".")) {
                MimeTypeMap.getSingleton().getMimeTypeFromExtension(a.substring(1))?.let { out.add(it) }
                if (a == ".csv" || a == ".txt") {
                    out.addAll(
                        listOf(
                            "text/plain", "text/csv", "text/comma-separated-values",
                            "application/csv", "application/vnd.ms-excel"
                        )
                    )
                }
                if (a == ".m3u" || a == ".m3u8") {
                    out.addAll(
                        listOf(
                            "audio/x-mpegurl", "audio/mpegurl", "application/x-mpegurl",
                            "application/vnd.apple.mpegurl"
                        )
                    )
                }
            } else {
                out.add(a)
            }
        }
        if (out.isEmpty()) return arrayOf("*/*")
        // Muitos gerenciadores de arquivos classificam CSV/M3U como "octet-stream".
        out.add("application/octet-stream")
        return out.toTypedArray()
    }

    /** Ponte JavaScript → Android para salvar arquivos com o seletor nativo (SAF). */
    inner class FilesBridge {
        /** Copia o download já pronto no servidor local para o local escolhido pelo usuário. */
        @JavascriptInterface
        fun salvarDownload(token: String, nomeArquivo: String) {
            if (!TOKEN_OK.matches(token)) {
                avisarJs(token, -1, true, "Download inválido.")
                return
            }
            runOnUiThread {
                pendingDownloadToken = token
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = mimeDoNome(nomeArquivo)
                    putExtra(Intent.EXTRA_TITLE, nomeArquivo)
                }
                try {
                    startActivityForResult(intent, REQ_SAVE_DOWNLOAD)
                } catch (e: Exception) {
                    pendingDownloadToken = null
                    avisarJs(token, -1, true, "Não foi possível abrir o seletor de arquivos.")
                }
            }
        }

        /** Salva texto (ex.: lista em CSV) no local escolhido pelo usuário. */
        @JavascriptInterface
        fun exportarTexto(nomeArquivo: String, mime: String, conteudo: String) {
            runOnUiThread {
                pendingExportContent = conteudo
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = if (mime.isBlank()) "text/plain" else mime
                    putExtra(Intent.EXTRA_TITLE, nomeArquivo)
                }
                try {
                    startActivityForResult(intent, REQ_EXPORT_TEXT)
                } catch (e: Exception) {
                    pendingExportContent = null
                    avisarJs("export", -1, true, "Não foi possível abrir o seletor de arquivos.")
                }
            }
        }
    }

    private fun mimeDoNome(nome: String): String {
        val ext = nome.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
            ?: if (ext == "m4a") "audio/mp4" else "application/octet-stream"
    }

    /** Avisa o painel: pct 0..100 (andamento), -1 com fim=true (terminou; ok=false/true na mensagem). */
    private fun avisarJs(id: String, pct: Int, fim: Boolean, msg: String, ok: Boolean = false) {
        val js = "window.tmArquivoEvento && window.tmArquivoEvento(" +
            JSONObject.quote(id) + "," + pct + "," + fim + "," + ok + "," + JSONObject.quote(msg) + ")"
        if (!::web.isInitialized) return
        web.post { if (::web.isInitialized) web.evaluateJavascript(js, null) }
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_PICK -> {
                val uris = WebChromeClient.FileChooserParams.parseResult(resultCode, data)
                filePathCallback?.onReceiveValue(uris)
                filePathCallback = null
            }
            REQ_SAVE_DOWNLOAD -> {
                val token = pendingDownloadToken
                pendingDownloadToken = null
                val uri = data?.data
                if (token == null) return
                if (resultCode != RESULT_OK || uri == null) {
                    avisarJs(token, -1, true, "Download cancelado.")
                    return
                }
                copiarDownload(token, uri)
            }
            REQ_EXPORT_TEXT -> {
                val conteudo = pendingExportContent
                pendingExportContent = null
                val uri = data?.data
                if (conteudo == null) return
                if (resultCode != RESULT_OK || uri == null) {
                    avisarJs("export", -1, true, "Exportação cancelada.")
                    return
                }
                try {
                    contentResolver.openOutputStream(uri, "wt")?.use { it.write(conteudo.toByteArray(Charsets.UTF_8)) }
                        ?: throw IllegalStateException("não foi possível gravar o arquivo")
                    avisarJs("export", 100, true, "Arquivo exportado.", true)
                } catch (e: Exception) {
                    android.util.Log.e("TIKMUSIC", "Falha ao exportar", e)
                    avisarJs("export", -1, true, "Falha ao exportar: ${e.message ?: "erro desconhecido"}")
                }
            }
        }
    }

    /** Copia /dl/<token> do servidor local para o arquivo escolhido, informando o progresso. */
    private fun copiarDownload(token: String, destino: Uri) {
        val resolver = contentResolver
        Thread {
            var conn: HttpURLConnection? = null
            try {
                conn = URL("http://127.0.0.1:8000/dl/$token").openConnection() as HttpURLConnection
                conn.connectTimeout = 10_000
                conn.readTimeout = 60_000
                if (conn.responseCode != 200) {
                    throw IllegalStateException("o servidor local respondeu ${conn.responseCode}")
                }
                val total = conn.contentLengthLong
                var copiado = 0L
                var ultimo = -1
                val saida = resolver.openOutputStream(destino, "w")
                    ?: throw IllegalStateException("não foi possível gravar no local escolhido")
                saida.use { out ->
                    conn.inputStream.use { inp ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = inp.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            copiado += n
                            if (total > 0) {
                                val pct = (copiado * 100 / total).toInt()
                                if (pct != ultimo) {
                                    ultimo = pct
                                    avisarJs(token, pct, false, "Salvando… $pct%")
                                }
                            }
                        }
                        out.flush()
                    }
                }
                fimNoServidor(token)
                avisarJs(token, 100, true, "Música salva.", true)
            } catch (e: Exception) {
                android.util.Log.e("TIKMUSIC", "Falha ao salvar download", e)
                try {
                    DocumentsContract.deleteDocument(resolver, destino)   // não deixa arquivo vazio/parcial
                } catch (_: Exception) {
                }
                fimNoServidor(token)
                avisarJs(token, -1, true, "Falha ao salvar: ${e.message ?: "erro desconhecido"}")
            } finally {
                conn?.disconnect()
            }
        }.start()
    }

    private fun fimNoServidor(token: String) {
        try {
            val c = URL("http://127.0.0.1:8000/dl/$token/fim").openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 5_000
            c.readTimeout = 5_000
            c.doOutput = true
            c.outputStream.use { }
            c.responseCode
            c.disconnect()
        } catch (_: Exception) {
        }
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
        }
    }

    /** Solicita câmera + microfone necessários para transmissão. */
    private fun askStreamPermissions() {
        val needed = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.CAMERA)
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.RECORD_AUDIO)
        }
        if (needed.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, needed.toTypedArray(), REQ_STREAM_PERMS)
        }
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        // O serviço de bot continua ativo; a ponte de stream é desligada com a Activity.
        streamBridge?.unbind()
        streamBridge = null
        filePathCallback?.onReceiveValue(null)
        filePathCallback = null
        if (::web.isInitialized) {
            web.destroy()
        }
        super.onDestroy()
    }

    companion object {
        private const val URL_LOCAL = "http://127.0.0.1:8000/"
        private const val MAX_TENTATIVAS = 40
        private const val REQ_PICK = 101
        private const val REQ_SAVE_DOWNLOAD = 102
        private const val REQ_EXPORT_TEXT = 103
        private const val REQ_STREAM_PERMS = 108
        private val TOKEN_OK = Regex("[A-Za-z0-9_-]{20,64}")
    }
}
