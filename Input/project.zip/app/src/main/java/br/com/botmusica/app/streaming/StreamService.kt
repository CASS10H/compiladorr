package br.com.botmusica.app.streaming

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Icon
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.util.Log
import androidx.core.content.ContextCompat
import br.com.botmusica.app.MainActivity
import br.com.botmusica.app.R
import com.pedro.common.ConnectChecker
import com.pedro.library.rtmp.RtmpCamera2
import com.pedro.library.view.GlInterface
import com.pedro.library.view.OpenGlView
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Serviço de transmissão: câmera + microfone → H.264/AAC → RTMP.
 * RootEncoder (RtmpCamera2). Preview opcional via [attachPreview].
 */
class StreamService : Service(), ConnectChecker {

    private val binder = LocalBinder()
    private var wakeLock: PowerManager.WakeLock? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    private val streaming = AtomicBoolean(false)
    private val previewing = AtomicBoolean(false)

    @Volatile private var config: StreamConfig = StreamConfig()
    @Volatile private var state: StreamState = StreamState()

    private var rtmpCamera: RtmpCamera2? = null
    private var startTimeMs: Long = 0
    private var statsRunnable: Runnable? = null

    var onStateChanged: ((StreamState) -> Unit)? = null

    // Fase 3: composição de overlays no pipeline OpenGL (preview + RTMP)
    private val compositor by lazy { SceneCompositor(applicationContext) }
    @Volatile private var activeScene: Scene? = null

    @Volatile private var previewView: OpenGlView? = null

    inner class LocalBinder : Binder() {
        fun getService(): StreamService = this@StreamService
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIF_ID, buildNotification("Pronto para transmitir"))
        acquireWakeLock()
        Log.i(TAG, "StreamService criado")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopStream()
                stopPreview()
                releaseCamera()
                releaseWakeLock()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            ACTION_START_STREAM -> {
                val url = intent.getStringExtra(EXTRA_RTMP_URL)
                val key = intent.getStringExtra(EXTRA_STREAM_KEY)
                if (url != null || key != null) {
                    updateConfig(
                        config.copy(
                            rtmpUrl = url ?: config.rtmpUrl,
                            streamKey = key ?: config.streamKey
                        )
                    )
                }
                startStream()
            }
            ACTION_STOP_STREAM -> stopStream()
        }
        return START_STICKY
    }

    fun getState(): StreamState = state
    fun getConfig(): StreamConfig = config

    fun updateConfig(newConfig: StreamConfig) {
        config = newConfig
        Log.i(TAG, "Config: ${config.width}x${config.height}@${config.fps} → ${config.fullRtmpUrl()}")
    }

    fun attachPreview(view: OpenGlView?) {
        mainHandler.post {
            val cam = rtmpCamera
            try {
                if (view != null) {
                    previewView = view
                    if (cam != null) {
                        cam.replaceView(view)
                    } else {
                        ensureCamera()
                    }
                } else {
                    previewView = null
                    cam?.replaceView(applicationContext)
                }
                reapplyComposition()
            } catch (e: Exception) {
                Log.w(TAG, "attachPreview", e)
            }
        }
    }

    fun startPreview() {
        mainHandler.post {
            if (previewing.getAndSet(true)) return@post
            if (!hasCameraPermission()) {
                publishState(state.copy(error = "Permissão de câmera necessária"))
                previewing.set(false)
                return@post
            }
            val cam = ensureCamera()
            if (cam == null) {
                publishState(state.copy(error = "Não foi possível abrir a câmera"))
                previewing.set(false)
                return@post
            }
            try {
                if (!cam.isOnPreview) {
                    cam.startPreview()
                }
                applyFacing(cam)
                reapplyComposition()
                publishState(state.copy(isPreviewing = true, error = null))
                updateNotification("Pré-visualização ativa")
                Log.i(TAG, "Preview iniciado")
            } catch (e: Exception) {
                previewing.set(false)
                publishState(state.copy(isPreviewing = false, error = e.message ?: "Erro no preview"))
                Log.e(TAG, "startPreview", e)
            }
        }
    }

    fun stopPreview() {
        mainHandler.post {
            if (!previewing.getAndSet(false)) return@post
            val cam = rtmpCamera ?: return@post
            try {
                if (!streaming.get() && cam.isOnPreview) {
                    cam.stopPreview()
                }
            } catch (e: Exception) {
                Log.w(TAG, "stopPreview", e)
            }
            publishState(state.copy(isPreviewing = false))
            if (!streaming.get()) updateNotification("Pronto para transmitir")
            Log.i(TAG, "Preview parado")
        }
    }

    fun startStream() {
        mainHandler.post {
            if (streaming.get()) {
                Log.w(TAG, "Já está transmitindo")
                return@post
            }
            if (!config.isValid()) {
                publishState(state.copy(error = "URL RTMP inválida. Use rtmp://servidor/app + stream key."))
                updateNotification("Erro: URL RTMP inválida")
                return@post
            }
            if (!hasCameraPermission() || !hasMicPermission()) {
                publishState(state.copy(error = "Permissões de câmera e microfone necessárias"))
                return@post
            }

            val cam = ensureCamera()
            if (cam == null) {
                publishState(state.copy(error = "Câmera indisponível"))
                return@post
            }

            try {
                // Camera2Base: prepareVideo(width, height, fps, bitrate, rotation)
                val prepared = cam.prepareVideo(
                    config.width,
                    config.height,
                    config.fps,
                    config.videoBitrate,
                    0
                ) && cam.prepareAudio(
                    44100,
                    true,
                    config.audioBitrate
                )

                if (!prepared) {
                    publishState(state.copy(error = "Aparelho não suporta ${config.width}x${config.height}@${config.fps}"))
                    updateNotification("Erro ao preparar encoder")
                    return@post
                }

                applyFacing(cam)
                reapplyComposition()

                streaming.set(true)
                startTimeMs = System.currentTimeMillis()
                publishState(
                    StreamState(
                        isStreaming = true,
                        isPreviewing = previewing.get() || cam.isOnPreview,
                        connected = false,
                        error = null
                    )
                )
                updateNotification("Conectando…")
                Log.i(TAG, "startStream → ${config.fullRtmpUrl()}")

                cam.startStream(config.fullRtmpUrl())
                startStatsLoop()
            } catch (e: Exception) {
                streaming.set(false)
                publishState(state.copy(isStreaming = false, error = e.message ?: "Falha ao iniciar stream"))
                updateNotification("Erro: ${e.message}")
                Log.e(TAG, "startStream", e)
            }
        }
    }

    fun stopStream() {
        mainHandler.post {
            if (!streaming.getAndSet(false)) return@post
            stopStatsLoop()
            try {
                rtmpCamera?.let { cam ->
                    if (cam.isStreaming) cam.stopStream()
                }
            } catch (e: Exception) {
                Log.w(TAG, "stopStream", e)
            }
            val duration = if (startTimeMs > 0) System.currentTimeMillis() - startTimeMs else 0
            publishState(
                StreamState(
                    isStreaming = false,
                    isPreviewing = previewing.get(),
                    connected = false,
                    durationMs = duration
                )
            )
            updateNotification(
                if (previewing.get()) "Pré-visualização ativa" else "Pronto para transmitir"
            )
            Log.i(TAG, "Stream parado (${duration}ms)")
        }
    }

    fun switchCamera() {
        mainHandler.post {
            try {
                rtmpCamera?.switchCamera()
                val facing = if (config.cameraFacing == "front") "back" else "front"
                updateConfig(config.copy(cameraFacing = facing))
            } catch (e: Exception) {
                Log.w(TAG, "switchCamera", e)
            }
        }
    }

    /**
     * Aplica propriedades da cena ativa (ex.: facing da câmera).
     * Overlays são compostos no encoder via [SceneCompositor] (Fase 3).
     */
    fun applyScene(scene: Scene?) {
        if (scene == null) return
        mainHandler.post {
            val camSource = scene.sources
                .filterIsInstance<Source.Camera>()
                .firstOrNull { it.visible }
            if (camSource != null) {
                val facing = camSource.facing
                if (config.cameraFacing != facing) {
                    updateConfig(config.copy(cameraFacing = facing))
                    val cam = rtmpCamera
                    if (cam != null && (previewing.get() || streaming.get())) {
                        applyFacing(cam)
                    }
                }
            }
            activeScene = scene
            reapplyComposition()
            Log.i(TAG, "Cena aplicada: ${scene.name} (${scene.sources.size} fontes)")
        }
    }

    /** Recarrega os overlays (ex.: botão "Overlays" ou página do overlay mudou). */
    fun reloadOverlays() {
        mainHandler.post { reapplyComposition() }
    }

    /** Quantidade de camadas (imagem/texto/HTML) compostas no encoder agora. */
    fun composedLayers(): Int = compositor.layerCount()

    /**
     * Fase 3: monta os filtros OpenGL da cena ativa na câmera atual.
     * Deve rodar na main thread. Sem câmera criada ainda, não faz nada
     * (será chamado de novo em startPreview/startStream).
     */
    private fun reapplyComposition() {
        val cam = rtmpCamera ?: return
        val gl = glInterfaceOf(cam)
        if (gl == null) {
            Log.w(TAG, "GlInterface indisponível; overlays não compostos")
            return
        }
        compositor.apply(gl, activeScene, config.width, config.height)
    }

    private fun glInterfaceOf(cam: RtmpCamera2): GlInterface? = try {
        cam.javaClass.getMethod("getGlInterface").invoke(cam) as? GlInterface
    } catch (e: Exception) {
        Log.w(TAG, "glInterface", e)
        null
    }

    fun isStreaming(): Boolean = streaming.get()
    fun isPreviewing(): Boolean = previewing.get()

    // ConnectChecker
    override fun onConnectionStarted(url: String) {
        Log.i(TAG, "Conexão iniciada: $url")
        mainHandler.post {
            publishState(state.copy(isStreaming = true, connected = false, error = null))
            updateNotification("Conectando…")
        }
    }

    override fun onConnectionSuccess() {
        Log.i(TAG, "Conectado")
        mainHandler.post {
            publishState(
                state.copy(
                    isStreaming = true,
                    connected = true,
                    error = null,
                    bitrate = config.videoBitrate.toLong(),
                    fps = config.fps.toFloat()
                )
            )
            updateNotification("AO VIVO • ${config.width}x${config.height}")
        }
    }

    override fun onConnectionFailed(reason: String) {
        Log.e(TAG, "Falha: $reason")
        mainHandler.post {
            streaming.set(false)
            stopStatsLoop()
            try {
                if (rtmpCamera?.isStreaming == true) rtmpCamera?.stopStream()
            } catch (_: Exception) {
            }
            publishState(
                state.copy(isStreaming = false, connected = false, error = "Falha RTMP: $reason")
            )
            updateNotification("Falha: $reason")
        }
    }

    override fun onNewBitrate(bitrate: Long) {
        mainHandler.post {
            if (streaming.get()) {
                publishState(state.copy(bitrate = bitrate, connected = true))
            }
        }
    }

    override fun onDisconnect() {
        Log.i(TAG, "Desconectado")
        mainHandler.post {
            val was = streaming.getAndSet(false)
            stopStatsLoop()
            if (was) {
                publishState(
                    state.copy(
                        isStreaming = false,
                        connected = false,
                        durationMs = if (startTimeMs > 0) System.currentTimeMillis() - startTimeMs else 0
                    )
                )
                updateNotification(
                    if (previewing.get()) "Pré-visualização ativa" else "Pronto para transmitir"
                )
            }
        }
    }

    override fun onAuthError() {
        onConnectionFailed("Erro de autenticação RTMP")
    }

    override fun onAuthSuccess() {
        Log.i(TAG, "Auth RTMP OK")
    }

    private fun ensureCamera(): RtmpCamera2? {
        rtmpCamera?.let { return it }
        return try {
            val cam = if (previewView != null) {
                RtmpCamera2(previewView!!, this)
            } else {
                RtmpCamera2(applicationContext, this)
            }
            rtmpCamera = cam
            cam
        } catch (e: Exception) {
            Log.e(TAG, "RtmpCamera2 create", e)
            null
        }
    }

    private fun releaseCamera() {
        mainHandler.post {
            try {
                compositor.release()
            } catch (_: Exception) {
            }
            try {
                rtmpCamera?.let { cam ->
                    if (cam.isStreaming) cam.stopStream()
                    if (cam.isOnPreview) cam.stopPreview()
                    // release resources if API exists
                    try {
                        cam.javaClass.getMethod("stop").invoke(cam)
                    } catch (_: Exception) {
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "releaseCamera", e)
            }
            rtmpCamera = null
        }
    }

    private fun applyFacing(cam: RtmpCamera2) {
        try {
            val wantFront = config.cameraFacing == "front"
            val isFront = try {
                cam.javaClass.getMethod("isFrontCamera").invoke(cam) as? Boolean
            } catch (_: Exception) {
                null
            }
            if (isFront != null && isFront != wantFront) {
                cam.switchCamera()
            }
        } catch (e: Exception) {
            Log.w(TAG, "applyFacing", e)
        }
    }

    private fun hasCameraPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED

    private fun hasMicPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    private fun startStatsLoop() {
        stopStatsLoop()
        statsRunnable = object : Runnable {
            override fun run() {
                if (!streaming.get()) return
                val elapsed = System.currentTimeMillis() - startTimeMs
                publishState(state.copy(durationMs = elapsed, isStreaming = true))
                mainHandler.postDelayed(this, 1000)
            }
        }
        mainHandler.post(statsRunnable!!)
    }

    private fun stopStatsLoop() {
        statsRunnable?.let { mainHandler.removeCallbacks(it) }
        statsRunnable = null
    }

    private fun publishState(newState: StreamState) {
        state = newState
        onStateChanged?.invoke(newState)
    }

    private fun acquireWakeLock() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "TIKMUSIC::stream").apply {
                setReferenceCounted(false)
                acquire(8 * 60 * 60 * 1000L)
            }
        } catch (e: Exception) {
            Log.w(TAG, "WakeLock", e)
        }
    }

    private fun releaseWakeLock() {
        try {
            wakeLock?.let { if (it.isHeld) it.release() }
        } catch (_: Exception) {
        }
        wakeLock = null
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Transmissão ao vivo",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Notificação enquanto a live está ativa"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(message: String): Notification {
        val openApp = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 2,
            Intent(this, StreamService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopAction = Notification.Action.Builder(
            Icon.createWithResource(this, R.drawable.ic_stat_tikmusic),
            "Parar live",
            stop
        ).build()

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, CHANNEL_ID)
        else
            @Suppress("DEPRECATION")
            Notification.Builder(this)

        return builder
            .setContentTitle("TIKMUSIC Live")
            .setContentText(message)
            .setSmallIcon(R.drawable.ic_stat_tikmusic)
            .setContentIntent(openApp)
            .addAction(stopAction)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun updateNotification(message: String) {
        getSystemService(NotificationManager::class.java)
            .notify(NOTIF_ID, buildNotification(message))
    }

    override fun onDestroy() {
        stopStream()
        stopPreview()
        releaseCamera()
        releaseWakeLock()
        super.onDestroy()
        Log.i(TAG, "StreamService destruído")
    }

    companion object {
        private const val TAG = "TIKMUSIC.Stream"
        private const val CHANNEL_ID = "tikmusic_stream"
        private const val NOTIF_ID = 43

        const val ACTION_START_STREAM = "br.com.botmusica.app.START_STREAM"
        const val ACTION_STOP_STREAM = "br.com.botmusica.app.STOP_STREAM"
        const val ACTION_STOP = "br.com.botmusica.app.STOP_STREAM_SERVICE"
        const val EXTRA_RTMP_URL = "rtmp_url"
        const val EXTRA_STREAM_KEY = "stream_key"
    }
}
