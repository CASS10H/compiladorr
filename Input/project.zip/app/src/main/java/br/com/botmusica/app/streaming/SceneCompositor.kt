package br.com.botmusica.app.streaming

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.Log
import android.view.View
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import com.pedro.encoder.input.gl.render.filters.`object`.ImageObjectFilterRender
import com.pedro.library.view.GlInterface

/**
 * Fase 3 — composição no encoder.
 *
 * Cada fonte visual da cena (Image, Text, WebOverlay) vira um bitmap que é
 * entregue a um [ImageObjectFilterRender] do RootEncoder. Como os filtros rodam
 * no pipeline OpenGL, eles aparecem tanto no preview quanto no vídeo enviado
 * por RTMP. A câmera continua sendo o fundo (tela cheia).
 *
 * WebOverlay: um WebView fora da tela é desenhado em Bitmap a ~[OVERLAY_FPS] fps.
 *
 * Todas as chamadas públicas devem ocorrer na thread principal.
 */
class SceneCompositor(private val context: Context) {

    private class Layer(
        val src: Source,
        val filter: ImageObjectFilterRender,
        val web: WebView? = null,
        val bmpW: Int,
        val bmpH: Int,
        // altura relativa (0..1) do bitmap em relação ao stream; texto é "wrap content"
        val relH: Float
    )

    private val main = Handler(Looper.getMainLooper())
    private var layers: List<Layer> = emptyList()
    private var gl: GlInterface? = null
    private var running = false
    private var sceneId: String? = null

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            try {
                updateLayers()
            } catch (e: Exception) {
                Log.w(TAG, "tick", e)
            }
            main.postDelayed(this, 1000L / OVERLAY_FPS)
        }
    }

    /** Monta os filtros da cena. Pode ser chamado de novo (nova cena, novo tamanho, reload). */
    fun apply(glInterface: GlInterface?, scene: Scene?, streamW: Int, streamH: Int) {
        release(keepGl = true)
        gl = glInterface
        val g = glInterface ?: return
        if (scene == null) return
        sceneId = scene.id

        val built = mutableListOf<Layer>()
        scene.sources
            .filter { it.visible }
            .sortedBy { it.zIndex }
            .forEach { src ->
                try {
                    buildLayer(src, streamW, streamH)?.let { built.add(it) }
                } catch (e: Exception) {
                    Log.w(TAG, "fonte ${src.name} ignorada", e)
                }
            }

        try {
            g.clearFilters()
            built.forEach { g.addFilter(it.filter) }
        } catch (e: Exception) {
            Log.e(TAG, "falha ao aplicar filtros", e)
        }
        layers = built
        running = true
        updateLayers()
        main.removeCallbacks(tick)
        main.postDelayed(tick, 1000L / OVERLAY_FPS)
        Log.i(TAG, "Composição: ${built.size} camadas na cena ${scene.name}")
    }

    fun layerCount(): Int = layers.size

    fun release(keepGl: Boolean = false) {
        running = false
        main.removeCallbacks(tick)
        layers.forEach { l ->
            l.web?.let {
                try {
                    it.stopLoading()
                    it.onPause()
                    it.destroy()
                } catch (_: Exception) {
                }
            }
        }
        if (!keepGl) {
            try {
                gl?.clearFilters()
            } catch (_: Exception) {
            }
            gl = null
        }
        layers = emptyList()
    }

    // ---------- construção ----------

    private fun buildLayer(src: Source, sw: Int, sh: Int): Layer? {
        return when (src) {
            is Source.Image -> {
                val bmp = loadImage(src.uri, src.opacity) ?: return null
                val f = ImageObjectFilterRender().apply { setImage(bmp) }
                Layer(src, f, null, bmp.width, bmp.height, src.height)
            }
            is Source.Text -> {
                val bmp = renderText(src, sw)
                val f = ImageObjectFilterRender().apply { setImage(bmp) }
                val relH = bmp.height.toFloat() / sh.toFloat()
                Layer(src, f, null, bmp.width, bmp.height, relH)
            }
            is Source.WebOverlay -> {
                val w = (src.width * sw).toInt().coerceIn(2, MAX_WEB_PX)
                val h = (src.height * sh).toInt().coerceIn(2, MAX_WEB_PX)
                val web = createWebView(src.url, w, h)
                val f = ImageObjectFilterRender().apply {
                    setImage(Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888))
                }
                Layer(src, f, web, w, h, src.height)
            }
            else -> null // Camera = fundo do pipeline
        }
    }

    private fun createWebView(url: String, w: Int, h: Int): WebView {
        return WebView(context).apply {
            setBackgroundColor(Color.TRANSPARENT)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.cacheMode = WebSettings.LOAD_NO_CACHE
            // software: permite draw() num Canvas de Bitmap
            setLayerType(View.LAYER_TYPE_SOFTWARE, null)
            webViewClient = WebViewClient()
            measure(
                View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(h, View.MeasureSpec.EXACTLY)
            )
            layout(0, 0, w, h)
            onResume()
            resumeTimers()
            loadUrl(url)
        }
    }

    // ---------- atualização por frame ----------

    private fun updateLayers() {
        for (l in layers) {
            val web = l.web
            if (web != null) {
                val bmp = Bitmap.createBitmap(l.bmpW, l.bmpH, Bitmap.Config.ARGB_8888)
                val c = Canvas(bmp)
                c.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
                web.draw(c)
                l.filter.setImage(if (l.src.opacity < 0.999f) withOpacity(bmp, l.src.opacity) else bmp)
            }
            // geometria reaplicada sempre: setImage pode resetar a escala padrão
            l.filter.setScale(l.src.width * 100f, l.relH * 100f)
            l.filter.setPosition(l.src.x * 100f, l.src.y * 100f)
        }
    }

    // ---------- helpers de bitmap ----------

    private fun withOpacity(src: Bitmap, opacity: Float): Bitmap {
        if (opacity >= 0.999f) return src
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val p = Paint().apply { alpha = (opacity.coerceIn(0f, 1f) * 255).toInt() }
        Canvas(out).drawBitmap(src, 0f, 0f, p)
        return out
    }

    private fun loadImage(uri: String, opacity: Float): Bitmap? {
        if (uri.isBlank()) return null
        val u = Uri.parse(uri)
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > MAX_IMAGE_PX) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = context.contentResolver.openInputStream(u)?.use {
            BitmapFactory.decodeStream(it, null, opts)
        } ?: return null
        return withOpacity(bmp, opacity)
    }

    private fun renderText(src: Source.Text, streamW: Int): Bitmap {
        val scale = streamW / REFERENCE_WIDTH
        val width = (src.width * streamW).toInt().coerceAtLeast(8)
        val pad = (12f * scale).toInt().coerceAtLeast(4)
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = parseColor(src.color, Color.WHITE)
            textSize = (src.fontSize * scale).coerceAtLeast(8f)
        }
        val layout = StaticLayout.Builder
            .obtain(src.text, 0, src.text.length, paint, (width - pad * 2).coerceAtLeast(4))
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .build()
        val height = layout.height + pad * 2
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(parseColor(src.backgroundColor, 0x80000000.toInt()))
        c.translate(pad.toFloat(), pad.toFloat())
        layout.draw(c)
        return withOpacity(bmp, src.opacity)
    }

    companion object {
        private const val TAG = "TIKMUSIC.Compose"
        const val OVERLAY_FPS = 8
        private const val MAX_WEB_PX = 1280
        private const val MAX_IMAGE_PX = 1280
        private const val REFERENCE_WIDTH = 1080f

        /**
         * Aceita #RRGGBB, #AARRGGBB (Android) e #RRGGBBAA (CSS, usado nos defaults
         * como "#00000080"). Android lê 8 dígitos como AARRGGBB, o que deixava o
         * fundo padrão do texto totalmente transparente.
         */
        fun parseColor(hex: String, fallback: Int): Int {
            return try {
                val h = hex.trim().removePrefix("#")
                if (h.length == 8) {
                    val r = h.substring(0, 2)
                    val g = h.substring(2, 4)
                    val b = h.substring(4, 6)
                    val a = h.substring(6, 8)
                    Color.parseColor("#$a$r$g$b")
                } else {
                    Color.parseColor("#$h")
                }
            } catch (_: Exception) {
                fallback
            }
        }
    }
}
