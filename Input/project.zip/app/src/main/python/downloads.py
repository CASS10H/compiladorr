"""Downloads MANUAIS do TIKMUSIC.

Regras:
- Nada aqui roda sozinho: um download só começa quando o usuário clica no botão de download.
- O arquivo fica numa pasta TEMPORÁRIA só até o Android copiá-lo para o local que o usuário
  escolheu (seletor de arquivos). Depois da entrega (ou de erro/cancelamento) ele é apagado.
- Sobras de downloads interrompidos são removidas ao iniciar o bot e depois de 1 hora.
- Este módulo não conhece FastAPI/Android: o bot.py só chama estas funções.
"""
import re
import secrets
import threading
import time
from pathlib import Path

TTL_SEGUNDOS = 3600          # arquivo pronto não entregue é apagado após 1 h
MAX_SIMULTANEOS = 2


class Cancelado(Exception):
    pass


def nome_seguro(texto, padrao="musica"):
    """Nome de arquivo válido no Android/Windows: sem / \\ : * ? " < > | nem controles."""
    t = re.sub(r'[\\/:*?"<>|\x00-\x1f]', " ", str(texto or ""))
    t = re.sub(r"\s+", " ", t).strip(" .")
    return (t[:120].strip(" .")) or padrao


class GerenciadorDownloads:
    def __init__(self, pasta, ydl_cls, opts_base):
        self.pasta = Path(pasta)
        self.ydl_cls = ydl_cls
        self.opts_base = opts_base          # função: devolve dict de opções base do yt-dlp
        self.jobs = {}
        self.lock = threading.Lock()
        self.sem = threading.Semaphore(MAX_SIMULTANEOS)
        self.pasta.mkdir(parents=True, exist_ok=True)

    # ---------- limpeza ----------
    def limpar_tudo(self):
        """Chamado ao iniciar: nada de downloads antigos sobra no armazenamento do app."""
        for p in self.pasta.glob("*"):
            try:
                p.unlink()
            except Exception:
                pass
        with self.lock:
            self.jobs.clear()

    def limpar_antigos(self):
        agora = time.time()
        with self.lock:
            velhos = [t for t, j in self.jobs.items()
                      if j["estado"] != "baixando" and agora - j["criado"] > TTL_SEGUNDOS]
        for t in velhos:
            self._remover(t)

    def _remover(self, token):
        with self.lock:
            j = self.jobs.pop(token, None)
        if j and j.get("arquivo"):
            try:
                Path(j["arquivo"]).unlink(missing_ok=True)
            except Exception:
                pass

    # ---------- API usada pelo bot.py ----------
    def iniciar(self, uid, vid, titulo="", artista=""):
        if not re.fullmatch(r"[A-Za-z0-9_-]{6,20}", str(vid or "")):
            raise ValueError("id de música inválido")
        self.limpar_antigos()
        token = secrets.token_urlsafe(24)
        job = {"token": token, "uid": uid, "vid": vid, "estado": "baixando", "progresso": 0,
               "msg": "Preparando…", "arquivo": None, "nome": nome_seguro(f"{artista} - {titulo}" if artista else titulo, vid),
               "criado": time.time(), "cancelar": False}
        with self.lock:
            self.jobs[token] = job
        threading.Thread(target=self._rodar, args=(token,), daemon=True).start()
        return token

    def status(self, uid, token):
        with self.lock:
            j = self.jobs.get(token)
            if not j or j["uid"] != uid:
                return None
            nome_arq = j["nome"] + (Path(j["arquivo"]).suffix if j["arquivo"] else "")
            return {"estado": j["estado"], "progresso": j["progresso"], "msg": j["msg"],
                    "nome": j["nome"], "nome_arquivo": nome_arq}

    def arquivo(self, token):
        """Usado pela rota que o Android lê. Só entrega downloads PRONTOS."""
        with self.lock:
            j = self.jobs.get(token)
            if not j or j["estado"] != "pronto" or not j["arquivo"]:
                return None
            p = Path(j["arquivo"])
            if not p.exists():
                return None
            return p, j["nome"] + p.suffix

    def descartar(self, uid, token):
        """Cancela se estiver baixando; apaga o arquivo temporário se já estiver pronto."""
        with self.lock:
            j = self.jobs.get(token)
            if not j or j["uid"] != uid:
                return False
            j["cancelar"] = True
            baixando = j["estado"] == "baixando"
        if not baixando:
            self._remover(token)
        return True

    def entregue(self, token):
        """O Android terminou de copiar o arquivo: apaga a cópia temporária."""
        self._remover(token)

    # ---------- execução ----------
    def _set(self, token, **kw):
        with self.lock:
            j = self.jobs.get(token)
            if j:
                j.update(kw)

    def _rodar(self, token):
        with self.sem:
            with self.lock:
                j = self.jobs.get(token)
                if not j:
                    return
                vid = j["vid"]
            if j["cancelar"]:
                self._remover(token)
                return

            def hook(d):
                with self.lock:
                    jj = self.jobs.get(token)
                    cancelar = bool(jj and jj["cancelar"])
                if cancelar:
                    raise Cancelado()
                if d.get("status") == "downloading":
                    total = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
                    feito = d.get("downloaded_bytes") or 0
                    pct = int(min(98, feito * 100 / total)) if total else 0
                    self._set(token, progresso=pct, msg=f"Baixando… {pct}%")
                elif d.get("status") == "finished":
                    self._set(token, progresso=99, msg="Finalizando…")

            opts = {**self.opts_base(), "format": "bestaudio[ext=m4a]/bestaudio/best",
                    "outtmpl": str(self.pasta / f"{token}.%(ext)s"),
                    "progress_hooks": [hook], "noprogress": True}
            try:
                with self.ydl_cls(opts) as y:
                    info = y.extract_info(f"https://www.youtube.com/watch?v={vid}", download=True)
                    reqs = info.get("requested_downloads") or [{}]
                    arq = reqs[0].get("filepath") or y.prepare_filename(info)
                if not arq or not Path(arq).exists():
                    raise RuntimeError("o arquivo não foi criado")
                self._set(token, estado="pronto", progresso=100, msg="Pronto", arquivo=str(arq))
            except Cancelado:
                self._set(token, estado="cancelado", msg="Cancelado")
                self._limpar_parciais(token)
                self._remover(token)
            except Exception as e:
                self._set(token, estado="erro", msg=("Falha no download: " + str(e))[:200])
                self._limpar_parciais(token)

    def _limpar_parciais(self, token):
        for p in self.pasta.glob(f"{token}.*"):
            try:
                p.unlink()
            except Exception:
                pass
