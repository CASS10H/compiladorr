"""
Bot de músicas para live do TikTok - versão MULTIUSUÁRIO (v3)
- Cada usuário tem conta própria, sua live do TikTok, fila, biblioteca e configurações.
- Os arquivos de áudio ficam em cache compartilhado (uma música baixada serve a todos).
- O som toca no navegador de cada usuário (painel aberto no aparelho ligado à caixa de som).

Variáveis de ambiente (todas opcionais, exceto trocar o convite):
  BOT_CONVITE       código exigido para criar conta   (padrão: troque-este-codigo)
  BOT_MAX_USUARIOS  limite de contas                  (padrão: 20)
  BOT_MAX_GB        limite de disco do cache          (padrão: 10)
  BOT_YT_COOKIES    caminho de um cookies.txt do YouTube (ajuda quando o servidor é bloqueado)
  BOT_STREAMING     padrão 1 = não salva NENHUM arquivo: o áudio passa direto pelo servidor até o painel
                    (0 = modo antigo, que baixa e guarda cada música no cache)
  BOT_SO_BIBLIOTECA 1 = não baixa nada novo: só toca o que já está salvo (busca também só na biblioteca)
  HOST / PORT       endereço e porta                  (padrão: 0.0.0.0 / 8000)
"""
import asyncio
import base64
import csv
from datetime import datetime, timezone
import hashlib
import hmac
import io
import json
import os
import re
import secrets
import sqlite3
import time
import uuid
from collections import deque
from pathlib import Path

import httpx
import uvicorn
import yt_dlp
from downloads import GerenciadorDownloads
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, Response, StreamingResponse
from TikTokLive import TikTokLiveClient
from TikTokLive.events import (CommentEvent, ConnectEvent, DisconnectEvent,
                               FollowEvent, GiftEvent, JoinEvent)

HOST = os.getenv("HOST", "0.0.0.0")
PORT = int(os.getenv("PORT", "8000"))
CONVITE = os.getenv("BOT_CONVITE", "local-android")
MAX_USUARIOS = int(os.getenv("BOT_MAX_USUARIOS", "20"))
MAX_GB = float(os.getenv("BOT_MAX_GB", "10"))
YT_COOKIES = os.getenv("BOT_YT_COOKIES", "")
SO_BIBLIOTECA = os.getenv("BOT_SO_BIBLIOTECA", "") == "1"
STREAMING = os.getenv("BOT_STREAMING", "1") != "0"   # streaming é o padrão; BOT_STREAMING=0 volta ao cache antigo
DOWNLOADS_SIMULTANEOS = 2

CFG_PADRAO = {"max_duracao": 600, "max_por_pessoa": 3, "votos_pular": 3,
              "bloqueadas": [], "mods": [], "autoplay": True, "volume": 80}

BASE = Path(os.getenv("BOT_DATA_DIR", str(Path(__file__).parent)))
MUSIC_DIR = BASE / "musicas"
HTML_PATH = BASE / "painel.html"
CHAT_PATH = BASE / "chat.html"
OVERLAY_PATH = BASE / "overlay.html"
UNIFICADO_PATH = BASE / "overlay-unificado.html"
MUSICAS_PATH = BASE / "overlay-musicas.html"
MIMES = {".m4a": "audio/mp4", ".mp4": "audio/mp4", ".webm": "audio/webm",
         ".opus": "audio/ogg", ".mp3": "audio/mpeg"}

# ---------------- banco de dados ----------------
db = sqlite3.connect(BASE / "dados.db", check_same_thread=False)
db.row_factory = sqlite3.Row
db.executescript("""
CREATE TABLE IF NOT EXISTS usuarios(
  id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT UNIQUE, senha TEXT, sal TEXT,
  tiktok TEXT DEFAULT '', cfg TEXT, overlay TEXT, criado REAL);
CREATE TABLE IF NOT EXISTS sessoes(token TEXT PRIMARY KEY, uid INTEGER, criada REAL);
CREATE TABLE IF NOT EXISTS faixas(
  id TEXT PRIMARY KEY, titulo TEXT, artista TEXT, duracao INTEGER,
  arquivo TEXT, tamanho INTEGER DEFAULT 0, usada REAL DEFAULT 0);
CREATE TABLE IF NOT EXISTS biblioteca(
  uid INTEGER, vid TEXT, tocadas INTEGER DEFAULT 0, ultima REAL DEFAULT 0,
  favorita INTEGER DEFAULT 0, PRIMARY KEY(uid, vid));
CREATE TABLE IF NOT EXISTS playlists_local(
  id TEXT PRIMARY KEY, uid INTEGER NOT NULL, nome TEXT NOT NULL, descricao TEXT DEFAULT '',
  cover_url TEXT DEFAULT '', is_public INTEGER DEFAULT 0, updated_at TEXT);
CREATE TABLE IF NOT EXISTS playlist_tracks_local(
  id TEXT PRIMARY KEY, playlist_id TEXT NOT NULL, uid INTEGER NOT NULL, vid TEXT NOT NULL,
  titulo TEXT NOT NULL, artista TEXT DEFAULT '', album TEXT DEFAULT '', duracao INTEGER DEFAULT 0,
  artwork_url TEXT DEFAULT '', source_url TEXT DEFAULT '', position INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS sync_meta(chave TEXT PRIMARY KEY, valor TEXT);
CREATE TABLE IF NOT EXISTS favorite_changes(uid INTEGER NOT NULL, vid TEXT NOT NULL, is_favorite INTEGER NOT NULL, PRIMARY KEY(uid,vid));
CREATE TABLE IF NOT EXISTS playlist_deletions(uid INTEGER NOT NULL, playlist_id TEXT NOT NULL, PRIMARY KEY(uid,playlist_id));
CREATE TABLE IF NOT EXISTS playlist_track_deletions(uid INTEGER NOT NULL, track_id TEXT NOT NULL, PRIMARY KEY(uid,track_id));
""")
db.commit()


def _migrar():
    """Migrações idempotentes: preservam todos os dados existentes."""
    cols = {r["name"] for r in db.execute("PRAGMA table_info(usuarios)")}
    if "ovcfg" not in cols:
        db.execute("ALTER TABLE usuarios ADD COLUMN ovcfg TEXT")
    if "ovmcfg" not in cols:
        db.execute("ALTER TABLE usuarios ADD COLUMN ovmcfg TEXT")
    if "supabase_uid" not in cols:
        db.execute("ALTER TABLE usuarios ADD COLUMN supabase_uid TEXT")
    db.execute("CREATE UNIQUE INDEX IF NOT EXISTS ix_usuarios_supabase_uid ON usuarios(supabase_uid) WHERE supabase_uid IS NOT NULL")
    db.executescript("""
CREATE TABLE IF NOT EXISTS pedidos(
  id INTEGER PRIMARY KEY AUTOINCREMENT, uid INTEGER, vid TEXT, titulo TEXT, artista TEXT,
  por TEXT, tid TEXT, quando REAL);
CREATE INDEX IF NOT EXISTS ix_pedidos_uid ON pedidos(uid, id);
""")
    db.commit()


_migrar()

# ---------------- configuração do overlay unificado (salva por usuário) ----------------
OV_PADRAO = {"cor1": "#fe2c55", "cor2": "#25f4ee", "max": 4, "capas": True, "avatares": True,
             "pedido": True, "tempo": True, "escala": 100, "posicao": "ie", "margem": 36,
             "vel": 100, "espaco": 8, "estilo": "vidro", "auto_ocultar": 0}
OV_ENUMS = {"posicao": ("se", "sd", "ie", "id", "c"), "estilo": ("vidro", "solido", "minimo")}
OV_NUMS = {"max": (1, 8), "escala": (50, 150), "margem": (0, 200), "vel": (50, 200),
           "espaco": (0, 24), "auto_ocultar": (0, 3600)}


def limpar_ov(d, base):
    """Valida a configuração recebida; valores inválidos mantêm o que já existia."""
    out = dict(base)
    if not isinstance(d, dict):
        return out
    for k in ("cor1", "cor2"):
        v = d.get(k)
        if isinstance(v, str) and re.fullmatch(r"#[0-9a-fA-F]{6}", v):
            out[k] = v.lower()
    for k, (lo, hi) in OV_NUMS.items():
        try:
            out[k] = max(lo, min(hi, int(d[k])))
        except (KeyError, TypeError, ValueError):
            pass
    for k in ("capas", "avatares", "pedido", "tempo"):
        if isinstance(d.get(k), bool):
            out[k] = d[k]
    for k, ok in OV_ENUMS.items():
        if d.get(k) in ok:
            out[k] = d[k]
    return out


# ---------------- configuração do overlay de músicas (estilo lista, salva por usuário) ----------------
OVM_PADRAO = {
    "capa": 72, "espaco": 14, "tam_titulo": 22, "tam_info": 15, "raio": 10, "fonte": "sistema", "sombra": True,
    "cor_titulo": "#ffffff", "cor_artista": "#cfd2dc", "cor_pedido": "#25f4ee", "cor_tempo": "#ffd166",
    "posicao": "se", "pos_x": 3, "pos_y": 5, "margem": 32,
    "m_capas": True, "m_artistas": True, "m_pedido": True, "m_tempo": True, "m_inicio": True,
    "m_barra": True, "m_eq": True, "max": 5,
    "anim": True, "vel": 100, "t_entrada": 500, "t_saida": 350}
OVM_ENUMS = {"posicao": ("se", "sd", "ie", "id", "c", "pers"),
             "fonte": ("sistema", "arial", "verdana", "tahoma", "trebuchet", "georgia", "courier", "impact")}
OVM_NUMS = {"capa": (40, 160), "espaco": (0, 48), "tam_titulo": (12, 44), "tam_info": (10, 30), "raio": (0, 50),
            "pos_x": (0, 100), "pos_y": (0, 100), "margem": (0, 200), "max": (1, 10),
            "vel": (50, 200), "t_entrada": (100, 2000), "t_saida": (100, 2000)}
OVM_CORES = ("cor_titulo", "cor_artista", "cor_pedido", "cor_tempo")
OVM_BOOLS = ("sombra", "m_capas", "m_artistas", "m_pedido", "m_tempo", "m_inicio", "m_barra", "m_eq", "anim")


def limpar_ovm(d, base):
    """Valida a configuração do overlay de músicas; valores inválidos mantêm o que já existia."""
    out = dict(base)
    if not isinstance(d, dict):
        return out
    for k in OVM_CORES:
        v = d.get(k)
        if isinstance(v, str) and re.fullmatch(r"#[0-9a-fA-F]{6}", v):
            out[k] = v.lower()
    for k, (lo, hi) in OVM_NUMS.items():
        try:
            out[k] = max(lo, min(hi, int(float(d[k]))))
        except (KeyError, TypeError, ValueError):
            pass
    for k in OVM_BOOLS:
        if isinstance(d.get(k), bool):
            out[k] = d[k]
    for k, ok in OVM_ENUMS.items():
        if d.get(k) in ok:
            out[k] = d[k]
    return out


def solicitante_de(x):
    """Nome de quem pediu, vindo dos dados reais do pedido. Nunca inventa: sem nome => 'Desconhecido'."""
    por = str(x.get("por") or "").strip()
    if por == "painel":
        return "Administrador"
    if por == "autoplay":
        return "Autoplay"
    return por or "Desconhecido"


def avatar_de(user):
    """Primeira URL https de avatar do usuário do TikTok (tolerante a versões da lib)."""
    for attr in ("avatar_thumb", "avatar_medium", "avatar_large"):
        img = getattr(user, attr, None)
        for campo in ("urls", "url_list", "m_urls"):
            for u in (getattr(img, campo, None) or []) if img else []:
                if isinstance(u, str) and u.startswith("https://") and len(u) < 600:
                    return u
    return ""


def origem_de(por):
    return "auto" if por == "autoplay" else "admin" if por == "painel" else ("chat" if por else "")


sem_download = asyncio.Semaphore(DOWNLOADS_SIMULTANEOS)
baixando: dict = {}
_tarefas: set = set()
SESSOES: dict = {}


def bg(coro):
    t = asyncio.create_task(coro)
    _tarefas.add(t)
    t.add_done_callback(_tarefas.discard)
    return t


# ---------------- busca e download (compartilhados) ----------------
def _opts_base():
    o = {"quiet": True, "no_warnings": True, "noplaylist": True}
    if YT_COOKIES and Path(YT_COOKIES).exists():
        o["cookiefile"] = YT_COOKIES
    return o


# Downloads MANUAIS (só quando o usuário clica): pasta temporária, apagada após a entrega.
GER_DL = GerenciadorDownloads(BASE / "tmp_downloads", yt_dlp.YoutubeDL, _opts_base)


def _buscar_sync(query, n):
    opts = {**_opts_base(), "extract_flat": True, "skip_download": True}
    with yt_dlp.YoutubeDL(opts) as y:
        if re.match(r"https?://", query):
            entries = [y.extract_info(query, download=False)]
        else:
            entries = (y.extract_info(f"ytsearch{n}:{query}", download=False).get("entries") or [])
    out = []
    for e in entries:
        if e and e.get("id"):
            out.append({"id": e["id"], "titulo": e.get("title") or "Sem título",
                        "artista": e.get("channel") or e.get("uploader") or "",
                        "duracao": int(e.get("duration") or 0)})
    return out


async def buscar(query, n=1):
    return await asyncio.to_thread(_buscar_sync, query, n)


def buscar_local(q, n=1):
    """Busca só nas músicas já salvas (modo sem downloads)."""
    termos = [t for t in q.split() if t][:6]
    if not termos:
        return []
    sql = "SELECT id,titulo,artista,duracao FROM faixas WHERE arquivo IS NOT NULL"
    args = []
    for t in termos:
        sql += " AND (titulo LIKE ? OR artista LIKE ?)"
        args += [f"%{t}%", f"%{t}%"]
    return [dict(r) for r in db.execute(sql + " ORDER BY usada DESC LIMIT ?", args + [n]).fetchall()]


async def buscar_auto(q, n=1):
    return buscar_local(q, n) if SO_BIBLIOTECA else await buscar(q, n)


# ---- modo streaming: nada é salvo em disco ----
_urls: dict = {}


def _resolver_sync(vid):
    opts = {**_opts_base(), "format": "bestaudio[ext=m4a]/bestaudio/best"}
    with yt_dlp.YoutubeDL(opts) as y:
        info = y.extract_info(f"https://www.youtube.com/watch?v={vid}", download=False)
    return info["url"], info.get("http_headers") or {}


async def resolver(vid):
    c = _urls.get(vid)
    if c and c[2] > time.time():
        return c[0], c[1]
    url, h = await asyncio.to_thread(_resolver_sync, vid)
    if len(_urls) > 200:   # descarta links expirados para não crescer sem limite
        for k in [k for k, v in _urls.items() if v[2] <= time.time()]:
            _urls.pop(k, None)
    _urls[vid] = (url, h, time.time() + 3000)
    return url, h


def salvar_meta(f):
    """Guarda só título/artista/duração (sem arquivo) para a biblioteca."""
    db.execute(
        """INSERT INTO faixas(id,titulo,artista,duracao,arquivo,tamanho,usada) VALUES(?,?,?,?,'',0,?)
           ON CONFLICT(id) DO UPDATE SET titulo=excluded.titulo, artista=excluded.artista,
             duracao=excluded.duracao""",
        (f["id"], f["titulo"], f["artista"], f["duracao"], time.time()))
    db.commit()


def _baixar_sync(vid):
    opts = {**_opts_base(), "format": "bestaudio[ext=m4a]/bestaudio/best",
            "outtmpl": str(MUSIC_DIR / "%(id)s.%(ext)s")}
    with yt_dlp.YoutubeDL(opts) as y:
        info = y.extract_info(f"https://www.youtube.com/watch?v={vid}", download=True)
        reqs = info.get("requested_downloads") or [{}]
        arquivo = reqs[0].get("filepath") or y.prepare_filename(info)
    return info, arquivo


async def _baixar(vid):
    async with sem_download:
        info, arquivo = await asyncio.to_thread(_baixar_sync, vid)
    db.execute(
        """INSERT INTO faixas(id,titulo,artista,duracao,arquivo,tamanho,usada)
           VALUES(?,?,?,?,?,?,?)
           ON CONFLICT(id) DO UPDATE SET titulo=excluded.titulo, artista=excluded.artista,
             duracao=excluded.duracao, arquivo=excluded.arquivo, tamanho=excluded.tamanho""",
        (vid, info.get("title") or "Sem título", info.get("uploader") or "",
         int(info.get("duration") or 0), arquivo,
         os.path.getsize(arquivo) if os.path.exists(arquivo) else 0, time.time()))
    db.commit()
    limpar_disco()
    return arquivo


async def garantir_arquivo(vid):
    if STREAMING:
        try:
            await resolver(vid)
            return "stream"
        except Exception as e:
            print(f"(stream {vid}) {str(e)[:200]}")
            return None
    r = db.execute("SELECT arquivo FROM faixas WHERE id=?", (vid,)).fetchone()
    if r and r["arquivo"] and Path(r["arquivo"]).exists():
        return r["arquivo"]
    if SO_BIBLIOTECA:
        return None
    t = baixando.get(vid)
    if not t:
        t = asyncio.create_task(_baixar(vid))
        baixando[vid] = t
        t.add_done_callback(lambda _, v=vid: baixando.pop(v, None))
    try:
        return await t
    except Exception as e:
        print(f"(download {vid}) {str(e)[:200]}")
        return None


def limpar_disco():
    """Apaga as músicas menos usadas quando o cache passa do limite."""
    limite = MAX_GB * 1024 ** 3
    total = db.execute("SELECT COALESCE(SUM(tamanho),0) FROM faixas").fetchone()[0]
    if total <= limite:
        return
    em_uso = {x["id"] for s in SESSOES.values() for x in s.fila + ([s.atual] if s.atual else [])}
    for r in db.execute("SELECT id,arquivo,tamanho FROM faixas ORDER BY usada ASC").fetchall():
        if total <= limite * 0.9:
            break
        if r["id"] in em_uso:
            continue
        try:
            Path(r["arquivo"]).unlink(missing_ok=True)
        except Exception:
            pass
        db.execute("DELETE FROM faixas WHERE id=?", (r["id"],))
        total -= r["tamanho"]
    db.commit()


# ---------------- sessão de cada usuário ----------------
class Sessao:
    def __init__(self, row):
        self.uid = row["id"]
        self.supabase_uid = row["supabase_uid"] if "supabase_uid" in row.keys() else None
        self.supabase_token = None
        self.supabase_expires_at = 0
        self.nome = row["nome"]
        self.tiktok = (row["tiktok"] or "").lstrip("@")
        self.overlay = row["overlay"]
        self.cfg = {**CFG_PADRAO, **json.loads(row["cfg"] or "{}")}
        try:
            self.ov = limpar_ov(json.loads(row["ovcfg"] or "{}"), OV_PADRAO)
        except Exception:
            self.ov = dict(OV_PADRAO)
        try:
            self.ovm = limpar_ovm(json.loads((row["ovmcfg"] if "ovmcfg" in row.keys() else None) or "{}"), OVM_PADRAO)
        except Exception:
            self.ovm = dict(OVM_PADRAO)
        self.fila = []
        self.atual = None
        self.tocando = False
        self.pausado = False
        self.volume = self.cfg["volume"]
        self.autoplay = self.cfg["autoplay"]
        self.votos = set()
        self.conectado = False
        self.seq = 0
        self.evt_fim = None
        self.acordar = asyncio.Event()
        self.log = deque(maxlen=60)
        self.eventos = deque(maxlen=300)   # chat, presentes, seguidores, entradas
        self.ev_id = 0
        self._ult_join = 0.0
        self.imp = {"rodando": False, "total": 0, "feitas": 0, "falhas": 0}
        self.t_player = None
        self.t_tiktok = None
        # posição da música (para o overlay): o painel informa; entre avisos o servidor estima
        self.pos, self.pos_t, self.pos_dur = 0.0, 0.0, 0
        self.historico = deque(maxlen=30)   # mais recente primeiro
        for r in db.execute(
                "SELECT f.id,f.titulo,f.artista,f.duracao,b.ultima FROM biblioteca b JOIN faixas f ON f.id=b.vid "
                "WHERE b.uid=? AND b.tocadas>0 ORDER BY b.ultima DESC LIMIT 30", (self.uid,)).fetchall():
            self.historico.append({"id": r["id"], "titulo": r["titulo"], "artista": r["artista"],
                                   "duracao": r["duracao"], "por": "", "quando": r["ultima"]})

    # ---- util ----
    def say(self, msg):
        print(f"[{self.nome}] {msg}")
        self.log.appendleft(f"{time.strftime('%H:%M:%S')}  {msg}")

    def push(self, tipo, nome, txt="", qtd=0):
        self.ev_id += 1
        self.eventos.append({"id": self.ev_id, "t": tipo, "nome": str(nome)[:60],
                             "txt": str(txt)[:300], "qtd": qtd})

    def salvar(self):
        self.cfg["autoplay"] = self.autoplay
        self.cfg["volume"] = self.volume
        db.execute("UPDATE usuarios SET tiktok=?, cfg=? WHERE id=?",
                   (self.tiktok, json.dumps(self.cfg), self.uid))
        db.execute("INSERT INTO sync_meta(chave,valor) VALUES(?,?) ON CONFLICT(chave) DO UPDATE SET valor=excluded.valor",
                   ("settings_local_updated:" + str(self.supabase_uid or self.uid), utc_iso()))
        db.commit()

    def iniciar(self):
        self.t_player = asyncio.create_task(self.loop_player())
        self.reiniciar_tiktok()

    def reiniciar_tiktok(self):
        if self.t_tiktok:
            self.t_tiktok.cancel()
            self.t_tiktok = None
        self.conectado = False
        if self.tiktok:
            self.t_tiktok = asyncio.create_task(self.loop_tiktok())

    def estado(self):
        return {"atual": self.atual, "tocando": self.tocando, "pausado": self.pausado,
                "volume": self.volume, "autoplay": self.autoplay, "conectado": self.conectado,
                "fila": self.fila, "log": list(self.log)[:25], "imp": self.imp,
                "seq": self.seq, "tiktok": self.tiktok}

    # ---- fila ----
    async def enfileirar(self, f, por="painel", tid="painel", checar=False, avatar=""):
        c = self.cfg
        if checar:
            if c["max_duracao"] and f["duracao"] and f["duracao"] > c["max_duracao"]:
                return False, f"muito longa ({f['duracao'] // 60} min): {f['titulo']}"
            if sum(1 for x in self.fila if x.get("tid") == tid) >= c["max_por_pessoa"]:
                return False, f"{por} já tem {c['max_por_pessoa']} músicas na fila"
            if any(p.lower() in f["titulo"].lower() for p in c["bloqueadas"]):
                return False, f"título bloqueado: {f['titulo']}"
        if any(x["id"] == f["id"] for x in self.fila) or (self.atual and self.atual["id"] == f["id"]):
            return False, f"já está na fila: {f['titulo']}"
        if not (isinstance(avatar, str) and avatar.startswith("https://") and len(avatar) < 600):
            avatar = ""
        agora = time.time()
        self.fila.append({**f, "por": por, "tid": tid, "avatar": avatar, "pedido_em": agora})
        db.execute("INSERT INTO pedidos(uid,vid,titulo,artista,por,tid,quando) VALUES(?,?,?,?,?,?,?)",
                   (self.uid, f["id"], f["titulo"], f.get("artista", ""), por, tid, agora))
        db.execute("DELETE FROM pedidos WHERE uid=? AND id <= (SELECT MAX(id) FROM pedidos WHERE uid=?) - 2000",
                   (self.uid, self.uid))
        if STREAMING:
            salvar_meta(f)
        db.execute("INSERT OR IGNORE INTO biblioteca(uid,vid) VALUES(?,?)", (self.uid, f["id"]))
        db.commit()
        self.acordar.set()
        bg(garantir_arquivo(f["id"]))  # baixa já, antes de chegar a vez
        return True, f"adicionada: {f['titulo']} (fila: {len(self.fila)})"

    async def pular(self):
        if self.tocando and self.evt_fim:
            self.evt_fim.set()
            self.say("⏭ Música pulada")
            return True
        return False

    def posicao(self):
        """Segundo atual da música (reportado pelo painel, estimado entre os avisos)."""
        if not self.atual or not self.tocando:
            return 0.0
        p = self.pos if self.pausado else self.pos + (time.time() - self.pos_t)
        return max(0.0, min(p, self.pos_dur)) if self.pos_dur else max(0.0, p)

    def dados_overlay(self):
        a = self.atual

        def mini(x):
            return {"id": x["id"], "titulo": x["titulo"], "artista": x.get("artista", ""),
                    "duracao": x.get("duracao", 0), "por": x.get("por", ""), "quando": x.get("quando", 0),
                    "tid": x.get("tid", "") if x.get("tid") not in ("painel", "autoplay") else "",
                    "avatar": x.get("avatar", ""), "pedido_em": x.get("pedido_em", 0),
                    "origem": origem_de(x.get("por", ""))}
        return {"titulo": a["titulo"] if a and self.tocando else "",   # campos originais
                "por": a["por"] if a else "",
                "atual": mini(a) if a else None, "tocando": self.tocando, "pausado": self.pausado,
                "cfg": self.ov,
                "seq": self.seq, "pos": round(self.posicao(), 2),
                "dur": self.pos_dur or (a.get("duracao", 0) if a else 0),
                "fila": [mini(x) for x in self.fila[:8]], "fila_total": len(self.fila),
                "historico": [mini(x) for x in list(self.historico)[:12]]}

    def dados_ovm(self):
        """Dados do overlay de músicas. 'inicia' = segundos até cada música da fila começar (a partir de agora)."""
        a = self.atual

        def mini(x):
            return {"id": x["id"], "titulo": x["titulo"], "artista": x.get("artista", ""),
                    "duracao": int(x.get("duracao") or 0), "por": solicitante_de(x),
                    "chave": f"{x['id']}:{x.get('pedido_em', 0)}"}
        dur = int(self.pos_dur or (a.get("duracao", 0) if a else 0) or 0)
        pos = self.posicao() if a else 0.0
        acum = max(0.0, dur - pos) if a else 0.0
        fila = []
        for x in self.fila[:10]:   # o overlay corta pelo "max" salvo; a prévia do painel pode pedir até 10
            m = mini(x)
            m["inicia"] = int(round(acum))
            fila.append(m)
            acum += m["duracao"]
        return {"atual": mini(a) if a else None, "tocando": self.tocando, "pausado": self.pausado,
                "seq": self.seq, "pos": round(pos, 2), "dur": dur, "fila": fila,
                "fila_total": len(self.fila), "cfg": self.ovm}

    def assinatura_ovm(self):
        """Muda só quando algo estrutural muda (não a cada segundo de música)."""
        d = self.dados_ovm()
        for x in d["fila"]:
            x.pop("inicia", None)
        d.pop("pos", None)
        return json.dumps(d, sort_keys=True, default=str)

    def pausa(self, forcar=None):
        if not self.tocando:
            return False
        self.pos, self.pos_t = self.posicao(), time.time()
        self.pausado = (not self.pausado) if forcar is None else forcar
        self.pos_t = time.time()
        self.say("⏸ Pausado" if self.pausado else "▶️ Continuando")
        return True

    def definir_volume(self, v):
        self.volume = max(0, min(130, int(v)))
        self.salvar()

    async def loop_player(self):
        ultimo = None
        while True:
            if not self.fila:
                if self.autoplay:
                    r = db.execute(
                        "SELECT f.* FROM biblioteca b JOIN faixas f ON f.id=b.vid "
                        "WHERE b.uid=? AND f.id != ? ORDER BY RANDOM() LIMIT 1",
                        (self.uid, ultimo or "")).fetchone()
                    if r and (STREAMING or Path(r["arquivo"]).exists()):
                        self.fila.append({"id": r["id"], "titulo": r["titulo"],
                                          "artista": r["artista"], "duracao": r["duracao"],
                                          "por": "autoplay", "tid": "autoplay",
                                          "avatar": "", "pedido_em": time.time()})
                if not self.fila:
                    self.acordar.clear()
                    await self.acordar.wait()
                    continue
            item = self.fila.pop(0)
            self.atual, self.pausado = item, False
            self.votos.clear()
            arquivo = await garantir_arquivo(item["id"])
            if arquivo:
                self.say(f"🎵 Tocando agora: {item['titulo']}")
                db.execute("UPDATE biblioteca SET tocadas=tocadas+1, ultima=? WHERE uid=? AND vid=?",
                           (time.time(), self.uid, item["id"]))
                db.execute("UPDATE faixas SET usada=? WHERE id=?", (time.time(), item["id"]))
                db.commit()
                ultimo = item["id"]
                self.seq += 1
                self.evt_fim = asyncio.Event()
                self.pos, self.pos_t, self.pos_dur = 0.0, time.time(), int(item.get("duracao") or 0)
                self.tocando = True
                await self.evt_fim.wait()   # o painel avisa quando termina
                self.tocando = False
                self.historico.appendleft({**item, "quando": time.time()})
            else:
                self.say(f"❌ Não consegui baixar: {item['titulo']} (veja os logs do servidor)")
            self.atual = None

    # ---- comandos do chat ----
    async def comando(self, texto, tid, nome, eh_mod, avatar=""):
        t = texto.strip()
        low = t.lower()
        c = self.cfg
        if low.startswith(("!song ", "!tocar ")):
            q = t.split(" ", 1)[1].strip()
            if not q:
                return
            self.say(f"📩 Pedido de {nome}: {q}")
            try:
                res = await buscar_auto(q, 1)
            except Exception as e:
                self.say(f"❌ Erro na busca: {str(e)[:100]}")
                return
            if not res:
                self.say("❌ Não encontrei a música" + (" na biblioteca" if SO_BIBLIOTECA else ""))
                return
            ok, msg = await self.enfileirar(res[0], por=nome, tid=tid, checar=not eh_mod, avatar=avatar)
            self.say(("✅ " if ok else "⛔ ") + msg)
        elif low == "!skip":
            if eh_mod:
                await self.pular()
        elif low == "!voteskip":
            if self.atual:
                self.votos.add(tid)
                self.say(f"🗳 Votos para pular: {len(self.votos)}/{c['votos_pular']}")
                if len(self.votos) >= c["votos_pular"]:
                    await self.pular()
        elif low == "!pause":
            if eh_mod:
                self.pausa(True)
        elif low in ("!play", "!continuar"):
            if eh_mod:
                self.pausa(False)
        elif low.startswith("!volume "):
            if eh_mod and low.split()[1].isdigit():
                self.definir_volume(low.split()[1])
        elif low == "!atual":
            self.say(f"🎵 Agora: {self.atual['titulo']}" if self.atual else "Nada tocando")
        elif low == "!remover":
            meus = [x for x in self.fila if x.get("tid") == tid]
            if meus:
                self.fila.remove(meus[-1])
                self.say(f"🗑 {nome} removeu: {meus[-1]['titulo']}")
        elif low == "!fila":
            self.say(f"📋 Fila ({len(self.fila)}): " + " | ".join(
                f"{i}. {x['titulo']}" for i, x in enumerate(self.fila[:8], 1)) if self.fila else "Fila vazia")

    def montar_cliente(self):
        cli = TikTokLiveClient(unique_id="@" + self.tiktok)

        async def on_connect(ev: ConnectEvent):
            self.conectado = True
            self.say(f"✅ Conectado na live de @{self.tiktok}")

        async def on_disconnect(ev: DisconnectEvent):
            self.conectado = False
            self.say("⚠️ Conexão com a live caiu")

        async def on_comment(ev: CommentEvent):
            try:
                self.push("chat", ev.user.nickname, ev.comment)
                tid = ev.user.unique_id
                eh_mod = (getattr(ev.user, "is_moderator", False)
                          or tid.lower() == self.tiktok.lower()
                          or tid.lower() in [m.lower().lstrip("@") for m in self.cfg["mods"]])
                await self.comando(ev.comment, tid, ev.user.nickname, eh_mod, avatar_de(ev.user))
            except Exception as e:
                self.say(f"Erro no comando: {e}")

        cli.add_listener(ConnectEvent, on_connect)
        cli.add_listener(DisconnectEvent, on_disconnect)
        async def on_gift(ev: GiftEvent):
            try:
                g = ev.gift
                if getattr(g, "streakable", False) and getattr(ev, "streaking", False):
                    return  # só registra quando a sequência de presentes termina
                self.push("gift", ev.user.nickname, g.name, getattr(ev, "repeat_count", 1) or 1)
            except Exception as e:
                print(f"[{self.nome}] (gift) {e}")

        async def on_follow(ev: FollowEvent):
            self.push("follow", ev.user.nickname)

        async def on_join(ev: JoinEvent):
            agora = time.time()
            if agora - self._ult_join >= 0.7:   # evita inundar em lives grandes
                self._ult_join = agora
                self.push("join", ev.user.nickname)

        cli.add_listener(CommentEvent, on_comment)
        cli.add_listener(GiftEvent, on_gift)
        cli.add_listener(FollowEvent, on_follow)
        cli.add_listener(JoinEvent, on_join)
        return cli

    async def loop_tiktok(self):
        while True:
            cli = self.montar_cliente()
            try:
                r = await cli.start()
                if r is not None and asyncio.isfuture(r):
                    await r
            except asyncio.CancelledError:
                try:
                    await cli.disconnect()
                except Exception:
                    pass
                raise
            except Exception as e:
                print(f"[{self.nome}] (tiktok) {type(e).__name__}: {e}")
            self.conectado = False
            self.say("Aguardando a live começar... (nova tentativa em 45s)")
            await asyncio.sleep(45)

    # ---- importação (Spotify) ----
    @staticmethod
    def parse_importacao(texto):
        linhas = [l for l in texto.splitlines() if l.strip()]
        if not linhas:
            return []
        if "track name" in linhas[0].lower():  # CSV do Exportify
            rd = csv.DictReader(io.StringIO(texto))
            ik = next(k for k in rd.fieldnames if "track name" in k.lower())
            ia = next((k for k in rd.fieldnames if "artist" in k.lower()), None)
            out = []
            for r in rd:
                art = re.split(r"[;,]", r.get(ia) or "")[0].strip() if ia else ""
                out.append(f"{art} {r[ik]}".strip())
            return out
        return [l.strip() for l in linhas]

    async def importar(self, qs, playlist_id=None):
        self.imp = {"rodando": True, "total": len(qs), "feitas": 0, "falhas": 0}
        self.say(f"📥 Importando {len(qs)} músicas...")
        for q in qs:
            try:
                res = await buscar(q, 1)
                if res and STREAMING:
                    salvar_meta(res[0])
                if not res or (not STREAMING and not await garantir_arquivo(res[0]["id"])):
                    raise RuntimeError("falhou")
                db.execute("INSERT OR IGNORE INTO biblioteca(uid,vid) VALUES(?,?)",
                           (self.uid, res[0]["id"]))
                if playlist_id:
                    pos=db.execute("SELECT COALESCE(MAX(position),-1)+1 FROM playlist_tracks_local WHERE playlist_id=?",(playlist_id,)).fetchone()[0]
                    db.execute("INSERT INTO playlist_tracks_local(id,playlist_id,uid,vid,titulo,artista,duracao,position) VALUES(?,?,?,?,?,?,?,?)",
                        (str(uuid.uuid4()),playlist_id,self.uid,res[0]["id"],res[0].get("titulo") or res[0].get("title") or "Música",res[0].get("artista") or res[0].get("artist") or "",int(res[0].get("duracao") or res[0].get("duration") or 0),pos))
                    db.execute("UPDATE playlists_local SET updated_at=? WHERE id=? AND uid=?",(utc_iso(),playlist_id,self.uid))
                db.commit()
            except Exception:
                self.imp["falhas"] += 1
            self.imp["feitas"] += 1
        self.imp["rodando"] = False
        self.say(f"📥 Importação concluída ({self.imp['falhas']} falhas)")


def criar_sessao(row):
    s = Sessao(row)
    SESSOES[s.uid] = s
    s.iniciar()
    return s


# ---------------- autenticação ----------------
def hash_senha(senha, sal):
    return hashlib.pbkdf2_hmac("sha256", senha.encode(), bytes.fromhex(sal), 200_000).hex()


def erro(msg, code=400):
    return JSONResponse({"erro": msg}, status_code=code)


def entrar_como(uid):
    token = secrets.token_urlsafe(32)
    db.execute("INSERT INTO sessoes(token,uid,criada) VALUES(?,?,?)", (token, uid, time.time()))
    db.commit()
    resp = JSONResponse({"ok": True})
    resp.set_cookie("sessao", token, httponly=True, samesite="lax", max_age=30 * 86400)
    return resp


def auth(req: Request) -> Sessao:
    tok = req.cookies.get("sessao")
    r = db.execute("SELECT uid FROM sessoes WHERE token=? AND criada>?", (tok, time.time() - 30 * 86400)).fetchone() if tok else None
    s = SESSOES.get(r["uid"]) if r else None
    if not s:
        raise HTTPException(401)
    if s.supabase_uid and s.supabase_token and s.supabase_expires_at and time.time() >= s.supabase_expires_at:
        raise HTTPException(401, "Sessão Supabase expirada. Renove o login.")
    return s


app = FastAPI()

# Supabase: somente a publishable key fica no app; todas as operações REST usam o JWT do usuário
# e continuam protegidas pelas políticas RLS já instaladas no projeto.
SUPABASE_URL = "https://fpqzxqkgkpkbykfceihb.supabase.co"
SUPABASE_KEY = "sb_publishable_3B2nNM9mJqpXXYy5xQxVJw_tmkxaZhx"

def utc_iso():
    return datetime.now(timezone.utc).isoformat()


def timestamp_epoch(value):
    try:
        raw=str(value or "").replace("Z", "+00:00")
        dt=datetime.fromisoformat(raw)
        if dt.tzinfo is None: dt=dt.replace(tzinfo=timezone.utc)
        return dt.timestamp()
    except Exception:
        return 0.0

async def sb_request(token, method, table_or_path, params=None, payload=None, prefer=None):
    headers = {"apikey": SUPABASE_KEY, "Authorization": "Bearer " + token, "Content-Type": "application/json"}
    if prefer:
        headers["Prefer"] = prefer
    url = table_or_path if table_or_path.startswith("https://") else f"{SUPABASE_URL}/rest/v1/{table_or_path}"
    async with httpx.AsyncClient(timeout=20) as client:
        response = await client.request(method, url, params=params, json=payload, headers=headers)
    if response.status_code >= 400:
        raise RuntimeError(f"Supabase {response.status_code}: {response.text[:500]}")
    if response.status_code == 204 or not response.text.strip():
        return []
    try:
        return response.json()
    except Exception:
        return []

async def validar_supabase_token(token):
    headers = {"apikey": SUPABASE_KEY, "Authorization": "Bearer " + token}
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            r = await client.get(SUPABASE_URL + "/auth/v1/user", headers=headers)
    except httpx.RequestError:
        raise HTTPException(503, "Supabase indisponível. Verifique sua conexão.")
    if r.status_code in (401, 403):
        raise HTTPException(401, "Sessão Supabase inválida ou expirada")
    if r.status_code != 200:
        raise HTTPException(503, "Não foi possível validar a sessão na Supabase.")
    return r.json()



@app.post("/api/auth/supabase")
async def api_auth_supabase(req: Request):
    auth_header = req.headers.get("authorization", "")
    token = auth_header[7:].strip() if auth_header.lower().startswith("bearer ") else ""
    if not token:
        return erro("Sessão Supabase ausente.", 401)
    try:
        user = await validar_supabase_token(token)
    except HTTPException as e:
        return erro(str(e.detail), e.status_code)
    suid = str(user.get("id") or "")
    if not suid:
        return erro("A Supabase não retornou o ID do usuário.", 401)
    body = await req.json() if req.headers.get("content-length", "0") not in ("", "0") else {}
    meta = user.get("user_metadata") or {}
    nome = str(body.get("nome") or meta.get("name") or meta.get("display_name") or (user.get("email") or "usuario").split("@")[0]).strip().lower()
    nome = re.sub(r"[^a-z0-9_.-]", "", nome)[:20] or "usuario"
    senha_legada = str(body.get("senha") or "")
    row = db.execute("SELECT * FROM usuarios WHERE supabase_uid=?", (suid,)).fetchone()
    if not row:
        # Migra uma conta SQLite antiga somente se a senha local também for comprovada.
        candidate = db.execute("SELECT * FROM usuarios WHERE nome=? AND (supabase_uid IS NULL OR supabase_uid='')", (nome,)).fetchone()
        migrated = False
        if candidate and candidate["senha"] and senha_legada:
            legacy_hash = await asyncio.to_thread(hash_senha, senha_legada, candidate["sal"])
            if hmac.compare_digest(legacy_hash, candidate["senha"]):
                db.execute("UPDATE usuarios SET supabase_uid=? WHERE id=?", (suid, candidate["id"]))
                migrated = True
        if not migrated:
            base, suffix = nome, 1
            while db.execute("SELECT 1 FROM usuarios WHERE nome=?", (nome,)).fetchone():
                tail = str(suffix); nome = base[:20-len(tail)] + tail; suffix += 1
            salt = secrets.token_hex(16)
            cur = db.execute("INSERT INTO usuarios(nome,senha,sal,cfg,overlay,criado,supabase_uid) VALUES(?,?,?,?,?,?,?)",
                (nome, "", salt, json.dumps(CFG_PADRAO), secrets.token_urlsafe(12), time.time(), suid))
            db.commit()
            row = db.execute("SELECT * FROM usuarios WHERE id=?", (cur.lastrowid,)).fetchone()
        db.commit()
        row = db.execute("SELECT * FROM usuarios WHERE supabase_uid=?", (suid,)).fetchone()
    if not row:
        return erro("Não foi possível preparar o perfil local.", 500)
    s = SESSOES.get(row["id"]) or criar_sessao(row)
    s.supabase_uid, s.supabase_token = suid, token
    try:
        payload = token.split(".")[1]
        payload += "=" * (-len(payload) % 4)
        s.supabase_expires_at = int(json.loads(base64.urlsafe_b64decode(payload.encode()).decode()).get("exp") or 0)
    except Exception:
        s.supabase_expires_at = 0
    response = entrar_como(row["id"])
    response.headers["X-TikMusic-Auth"] = "supabase"
    return response

@app.post("/api/supabase/sync")
async def api_supabase_sync(req: Request):
    s = auth(req)
    if not s.supabase_uid or not s.supabase_token:
        return erro("A sessão não está vinculada à Supabase. Entre novamente.", 401)
    token, uid = s.supabase_token, s.supabase_uid
    try:
        # Perfil e configurações: upsert com o JWT do usuário, respeitando RLS.
        await sb_request(token, "POST", "profiles?on_conflict=id", payload={"id": uid, "display_name": s.nome}, prefer="resolution=merge-duplicates,return=minimal")
        remote_settings = await sb_request(token, "GET", "user_settings", params={"select":"settings,updated_at", "user_id":f"eq.{uid}", "limit":"1"})
        local_mark = db.execute("SELECT valor FROM sync_meta WHERE chave=?", ("settings_local_updated:" + uid,)).fetchone()
        if remote_settings and isinstance(remote_settings[0].get("settings"), dict):
            remote_cfg = remote_settings[0]["settings"]
            remote_updated = str(remote_settings[0].get("updated_at") or "")
            local_updated = str(local_mark["valor"] if local_mark else "")
            if local_updated and timestamp_epoch(local_updated) > timestamp_epoch(remote_updated):
                await sb_request(token, "PATCH", "user_settings", params={"user_id":f"eq.{uid}"}, payload={"settings": s.cfg, "updated_at":utc_iso()}, prefer="return=minimal")
            else:
                s.cfg = {**CFG_PADRAO, **remote_cfg}
                s.volume = max(0, min(130, int(s.cfg.get("volume", 80))))
                s.autoplay = bool(s.cfg.get("autoplay", True))
                db.execute("UPDATE usuarios SET cfg=? WHERE id=?", (json.dumps(s.cfg), s.uid))
                db.execute("INSERT INTO sync_meta(chave,valor) VALUES(?,?) ON CONFLICT(chave) DO UPDATE SET valor=excluded.valor", ("settings_local_updated:" + uid, remote_updated or utc_iso()))
        else:
            now_iso=utc_iso()
            await sb_request(token, "POST", "user_settings", payload={"user_id":uid,"settings":s.cfg,"updated_at":now_iso}, prefer="return=minimal")
            db.execute("INSERT INTO sync_meta(chave,valor) VALUES(?,?) ON CONFLICT(chave) DO UPDATE SET valor=excluded.valor", ("settings_local_updated:" + uid, now_iso))

        # Biblioteca/favoritos: importa favoritos remotos para o SQLite e envia os favoritos locais.
        pending_favs = db.execute("SELECT vid,is_favorite FROM favorite_changes WHERE uid=?", (s.uid,)).fetchall()
        for change in pending_favs:
            vid = change["vid"]
            if change["is_favorite"]:
                meta = db.execute("SELECT f.titulo,f.artista,f.duracao FROM faixas f WHERE f.id=?", (vid,)).fetchone()
                if meta:
                    payload={"user_id":uid,"track_key":vid,"title":meta["titulo"],"artist":meta["artista"],"duration_ms":int(meta["duracao"] or 0)*1000}
                    exists=await sb_request(token,"GET","favorites",params={"select":"track_key","user_id":f"eq.{uid}","track_key":f"eq.{vid}","limit":"1"})
                    if exists: await sb_request(token,"PATCH","favorites",params={"user_id":f"eq.{uid}","track_key":f"eq.{vid}"},payload=payload,prefer="return=minimal")
                    else: await sb_request(token,"POST","favorites",payload=payload,prefer="return=minimal")
            else:
                await sb_request(token,"DELETE","favorites",params={"user_id":f"eq.{uid}","track_key":f"eq.{vid}"},prefer="return=minimal")
        db.execute("DELETE FROM favorite_changes WHERE uid=?", (s.uid,))
        remote_favs = await sb_request(token, "GET", "favorites", params={"select":"track_key,title,artist,duration_ms", "user_id":f"eq.{uid}", "limit":"1000"})
        db.execute("UPDATE biblioteca SET favorita=0 WHERE uid=?", (s.uid,))
        for f in remote_favs:
            vid = str(f.get("track_key") or "")
            if not re.fullmatch(r"[A-Za-z0-9_-]{1,40}", vid): continue
            db.execute("INSERT OR IGNORE INTO faixas(id,titulo,artista,duracao) VALUES(?,?,?,?)", (vid, f.get("title") or vid, f.get("artist") or "", int((f.get("duration_ms") or 0)/1000)))
            db.execute("INSERT OR IGNORE INTO biblioteca(uid,vid) VALUES(?,?)", (s.uid, vid))
            db.execute("UPDATE biblioteca SET favorita=1 WHERE uid=? AND vid=?", (s.uid, vid))

        # Playlists e faixas são mantidas localmente mesmo quando o painel estiver offline.
        pending_deletes = db.execute("SELECT playlist_id FROM playlist_deletions WHERE uid=?", (s.uid,)).fetchall()
        for gone in pending_deletes:
            await sb_request(token, "DELETE", "playlist_tracks", params={"playlist_id":f"eq.{gone['playlist_id']}","user_id":f"eq.{uid}"}, prefer="return=minimal")
            await sb_request(token, "DELETE", "playlists", params={"id":f"eq.{gone['playlist_id']}","user_id":f"eq.{uid}"}, prefer="return=minimal")
        db.execute("DELETE FROM playlist_deletions WHERE uid=?", (s.uid,))
        remote_lists = await sb_request(token, "GET", "playlists", params={"select":"id,name,description,cover_url,is_public,updated_at", "user_id":f"eq.{uid}", "limit":"500"})
        remote_by_id = {str(x.get("id")):x for x in remote_lists}
        local_lists = db.execute("SELECT * FROM playlists_local WHERE uid=?", (s.uid,)).fetchall()
        for pl in local_lists:
            pid=str(pl["id"])
            remote_pl=remote_by_id.get(pid)
            local_updated=str(pl["updated_at"] or "")
            remote_updated=str((remote_pl or {}).get("updated_at") or "")
            seen=db.execute("SELECT valor FROM sync_meta WHERE chave=?",("playlist_seen:"+uid+":"+pid,)).fetchone()
            if not remote_pl and seen and timestamp_epoch(local_updated) <= timestamp_epoch(seen["valor"]):
                # A playlist existia na nuvem e foi apagada em outro aparelho.
                db.execute("DELETE FROM playlist_tracks_local WHERE playlist_id=? AND uid=?",(pid,s.uid))
                db.execute("DELETE FROM playlists_local WHERE id=? AND uid=?",(pid,s.uid))
                continue
            if not remote_pl or timestamp_epoch(local_updated) > timestamp_epoch(remote_updated):
                await sb_request(token, "POST", "playlists?on_conflict=id", payload={"id":pid,"user_id":uid,"name":pl["nome"],"description":pl["descricao"],"cover_url":pl["cover_url"],"is_public":bool(pl["is_public"]),"updated_at":local_updated or utc_iso()}, prefer="resolution=merge-duplicates,return=minimal")
        remote_lists = await sb_request(token, "GET", "playlists", params={"select":"id,name,description,cover_url,is_public,updated_at", "user_id":f"eq.{uid}", "limit":"500"})
        for pl in remote_lists:
            db.execute("INSERT INTO playlists_local(id,uid,nome,descricao,cover_url,is_public,updated_at) VALUES(?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET nome=excluded.nome,descricao=excluded.descricao,cover_url=excluded.cover_url,is_public=excluded.is_public,updated_at=excluded.updated_at",
                (pl["id"],s.uid,pl.get("name") or "Playlist",pl.get("description") or "",pl.get("cover_url") or "",int(bool(pl.get("is_public"))),pl.get("updated_at")))
            db.execute("INSERT INTO sync_meta(chave,valor) VALUES(?,?) ON CONFLICT(chave) DO UPDATE SET valor=excluded.valor",("playlist_seen:"+uid+":"+str(pl["id"]),str(pl.get("updated_at") or utc_iso())))
        pending_track_deletes=db.execute("SELECT track_id FROM playlist_track_deletions WHERE uid=?",(s.uid,)).fetchall()
        for gone in pending_track_deletes:
            await sb_request(token,"DELETE","playlist_tracks",params={"id":f"eq.{gone['track_id']}","user_id":f"eq.{uid}"},prefer="return=minimal")
        db.execute("DELETE FROM playlist_track_deletions WHERE uid=?",(s.uid,))
        remote_tracks = await sb_request(token, "GET", "playlist_tracks", params={"select":"id,playlist_id,track_key,title,artist,album,duration_ms,artwork_url,source_url,position", "user_id":f"eq.{uid}", "limit":"5000"})
        remote_track_ids={str(x.get("id")) for x in remote_tracks}
        local_tracks = db.execute("SELECT * FROM playlist_tracks_local WHERE uid=?", (s.uid,)).fetchall()
        for tr in local_tracks:
            tid=str(tr["id"])
            seen=db.execute("SELECT 1 FROM sync_meta WHERE chave=?",("playlist_track_seen:"+uid+":"+tid,)).fetchone()
            if seen and tid not in remote_track_ids:
                # Faixa removida da playlist em outro dispositivo.
                db.execute("DELETE FROM playlist_tracks_local WHERE id=? AND uid=?",(tid,s.uid))
                continue
            await sb_request(token, "POST", "playlist_tracks?on_conflict=id", payload={"id":tid,"playlist_id":tr["playlist_id"],"user_id":uid,"track_key":tr["vid"],"title":tr["titulo"],"artist":tr["artista"],"album":tr["album"],"duration_ms":int(tr["duracao"] or 0)*1000,"artwork_url":tr["artwork_url"],"source_url":tr["source_url"],"position":tr["position"]}, prefer="resolution=merge-duplicates,return=minimal")
        remote_tracks = await sb_request(token, "GET", "playlist_tracks", params={"select":"id,playlist_id,track_key,title,artist,album,duration_ms,artwork_url,source_url,position", "user_id":f"eq.{uid}", "limit":"5000"})
        for tr in remote_tracks:
            if not db.execute("SELECT 1 FROM playlists_local WHERE id=? AND uid=?",(tr.get("playlist_id"),s.uid)).fetchone():
                continue
            db.execute("INSERT INTO sync_meta(chave,valor) VALUES(?,?) ON CONFLICT(chave) DO UPDATE SET valor=excluded.valor",("playlist_track_seen:"+uid+":"+str(tr.get("id")),"1"))
            vid = str(tr.get("track_key") or "")
            if not vid or not re.fullmatch(r"[A-Za-z0-9_-]{1,40}", vid): continue
            db.execute("INSERT OR IGNORE INTO faixas(id,titulo,artista,duracao) VALUES(?,?,?,?)", (vid,tr.get("title") or vid,tr.get("artist") or "",int((tr.get("duration_ms") or 0)/1000)))
            db.execute("INSERT INTO playlist_tracks_local(id,playlist_id,uid,vid,titulo,artista,album,duracao,artwork_url,source_url,position) VALUES(?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET titulo=excluded.titulo,artista=excluded.artista,position=excluded.position",
                (tr["id"],tr["playlist_id"],s.uid,vid,tr.get("title") or vid,tr.get("artist") or "",tr.get("album") or "",int((tr.get("duration_ms") or 0)/1000),tr.get("artwork_url") or "",tr.get("source_url") or "",int(tr.get("position") or 0)))

        # Histórico remoto é preservado; envia entradas locais ainda não vistas (fingerprint idempotente).
        remote_hist = await sb_request(token, "GET", "play_history", params={"select":"track_key,title,artist,played_at", "user_id":f"eq.{uid}", "order":"played_at.desc", "limit":"1000"})
        known_history = {(x.get("track_key"), str(x.get("played_at") or "")[:19]) for x in remote_hist}
        for h in list(s.historico)[:30]:
            played = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(float(h.get("quando") or time.time())))
            fingerprint = f"history:{uid}:{h['id']}:{played}"
            sent = db.execute("SELECT 1 FROM sync_meta WHERE chave=?", (fingerprint,)).fetchone()
            if not sent and (h["id"], played[:19]) not in known_history:
                await sb_request(token, "POST", "play_history", payload={"user_id":uid,"track_key":h["id"],"title":h.get("titulo"),"artist":h.get("artista"),"played_at":played}, prefer="return=minimal")
            db.execute("INSERT OR IGNORE INTO sync_meta(chave,valor) VALUES(?, '1')", (fingerprint,))
        # Traz também o histórico dos outros dispositivos para a biblioteca e o overlay local.
        remote_items=[]
        remote_play_counts={}
        for h in remote_hist:
            vid=str(h.get("track_key") or "")
            if not re.fullmatch(r"[A-Za-z0-9_-]{1,40}",vid): continue
            db.execute("INSERT OR IGNORE INTO faixas(id,titulo,artista,duracao) VALUES(?,?,?,0)",(vid,h.get("title") or vid,h.get("artist") or ""))
            db.execute("INSERT OR IGNORE INTO biblioteca(uid,vid) VALUES(?,?)",(s.uid,vid))
            try: stamp=time.mktime(time.strptime(str(h.get("played_at"))[:19],"%Y-%m-%dT%H:%M:%S"))
            except Exception: stamp=time.time()
            remote_play_counts[vid]=remote_play_counts.get(vid,0)+1
            db.execute("UPDATE biblioteca SET ultima=MAX(ultima,?) WHERE uid=? AND vid=?",(stamp,s.uid,vid))
            remote_items.append({"id":vid,"titulo":h.get("title") or vid,"artista":h.get("artist") or "","duracao":0,"por":"","quando":stamp})
        for vid,count in remote_play_counts.items():
            db.execute("UPDATE biblioteca SET tocadas=MAX(tocadas,?) WHERE uid=? AND vid=?",(count,s.uid,vid))
        combined={x.get("id"):x for x in remote_items}
        for h in list(s.historico): combined.setdefault(h.get("id"),h)
        s.historico=deque(sorted(combined.values(),key=lambda x:float(x.get("quando") or 0),reverse=True)[:30],maxlen=30)

        # Um registro de dispositivo por instalação (UUID persistido no SQLite).
        device_key="device_id:" + uid
        dev = db.execute("SELECT valor FROM sync_meta WHERE chave=?",(device_key,)).fetchone()
        if not dev:
            device_id = str(uuid.uuid4())
            db.execute("INSERT INTO sync_meta(chave,valor) VALUES(?,?)", (device_key,device_id))
        else: device_id = dev["valor"]
        await sb_request(token, "POST", "devices?on_conflict=id", payload={"id":device_id,"user_id":uid,"device_name":"TIKMUSIC Android","last_seen":utc_iso()}, prefer="resolution=merge-duplicates,return=minimal")
        db.commit()
        return {"ok":True,"favoritos":len(remote_favs),"playlists":len(remote_lists),"faixas_playlist":len(remote_tracks),"historico_remoto":len(remote_hist)}
    except Exception as e:
        db.rollback()
        print("[Supabase sync]", repr(e))
        return erro("Falha na sincronização: " + str(e)[:220], 502)

@app.get("/api/playlists")
async def api_playlists(req: Request):
    s=auth(req)
    return [dict(r) for r in db.execute("SELECT id,nome,descricao,cover_url,is_public FROM playlists_local WHERE uid=? ORDER BY nome",(s.uid,)).fetchall()]

@app.post("/api/playlists")
async def api_playlist_criar(req: Request):
    s=auth(req); d=await req.json(); nome=str(d.get("nome") or "").strip()[:80]
    if not nome: return erro("Informe o nome da playlist.")
    pid=str(uuid.uuid4())
    db.execute("INSERT INTO playlists_local(id,uid,nome,descricao,cover_url,is_public,updated_at) VALUES(?,?,?,?,?,?,?)",(pid,s.uid,nome,str(d.get("descricao") or "")[:300],str(d.get("cover_url") or "")[:1000],int(bool(d.get("is_public"))),time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime())))
    db.commit()
    return {"ok":True,"id":pid}

@app.delete("/api/playlists/{playlist_id}")
async def api_playlist_excluir(playlist_id: str, req: Request):
    s=auth(req)
    row=db.execute("SELECT id FROM playlists_local WHERE id=? AND uid=?",(playlist_id,s.uid)).fetchone()
    if not row: return erro("Playlist não encontrada.",404)
    db.execute("INSERT OR IGNORE INTO playlist_deletions(uid,playlist_id) VALUES(?,?)",(s.uid,playlist_id))
    db.execute("DELETE FROM playlist_tracks_local WHERE playlist_id=? AND uid=?",(playlist_id,s.uid))
    db.execute("DELETE FROM playlists_local WHERE id=? AND uid=?",(playlist_id,s.uid)); db.commit()
    return {"ok":True}

@app.post("/api/playlists/{playlist_id}/tracks")
async def api_playlist_add_track(playlist_id: str, req: Request):
    s=auth(req); d=await req.json()
    pl=db.execute("SELECT id FROM playlists_local WHERE id=? AND uid=?",(playlist_id,s.uid)).fetchone()
    if not pl: return erro("Playlist não encontrada.",404)
    vid=str(d.get("id") or "")
    f=db.execute("SELECT * FROM faixas WHERE id=?",(vid,)).fetchone()
    if not f: return erro("Música não encontrada na biblioteca.",404)
    tid=str(uuid.uuid4()); pos=db.execute("SELECT COALESCE(MAX(position),-1)+1 FROM playlist_tracks_local WHERE playlist_id=?",(playlist_id,)).fetchone()[0]
    db.execute("INSERT INTO playlist_tracks_local(id,playlist_id,uid,vid,titulo,artista,duracao,position) VALUES(?,?,?,?,?,?,?,?)",(tid,playlist_id,s.uid,vid,f["titulo"],f["artista"],f["duracao"],pos))
    db.execute("UPDATE playlists_local SET updated_at=? WHERE id=? AND uid=?",(time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),playlist_id,s.uid)); db.commit()
    return {"ok":True,"id":tid,"position":pos}

@app.delete("/api/playlists/{playlist_id}/tracks/{track_id}")
async def api_playlist_track_excluir(playlist_id: str, track_id: str, req: Request):
    s=auth(req)
    row=db.execute("SELECT id FROM playlist_tracks_local WHERE id=? AND playlist_id=? AND uid=?",(track_id,playlist_id,s.uid)).fetchone()
    if not row: return erro("Música não encontrada nesta playlist.",404)
    db.execute("INSERT OR IGNORE INTO playlist_track_deletions(uid,track_id) VALUES(?,?)",(s.uid,track_id))
    db.execute("DELETE FROM playlist_tracks_local WHERE id=? AND playlist_id=? AND uid=?",(track_id,playlist_id,s.uid))
    db.execute("UPDATE playlists_local SET updated_at=? WHERE id=? AND uid=?",(utc_iso(),playlist_id,s.uid)); db.commit()
    return {"ok":True}

@app.get("/api/playlists/{playlist_id}/tracks")
async def api_playlist_tracks(playlist_id: str, req: Request):
    s=auth(req)
    if not db.execute("SELECT 1 FROM playlists_local WHERE id=? AND uid=?",(playlist_id,s.uid)).fetchone(): return erro("Playlist não encontrada.",404)
    return [dict(r) for r in db.execute("SELECT * FROM playlist_tracks_local WHERE playlist_id=? AND uid=? ORDER BY position",(playlist_id,s.uid)).fetchall()]

@app.post("/api/registrar")
async def api_registrar(req: Request):
    d = await req.json()
    nome = str(d.get("nome", "")).strip().lower()
    senha = str(d.get("senha", ""))
    if os.getenv("BOT_LOCAL_ANDROID", "") != "1" and not hmac.compare_digest(str(d.get("convite", "")).encode(), CONVITE.encode()):
        return erro("código de convite inválido")
    if not re.fullmatch(r"[a-z0-9_.-]{3,20}", nome):
        return erro("nome de usuário: 3 a 20 letras, números, . _ -")
    if len(senha) < 6:
        return erro("a senha precisa ter pelo menos 6 caracteres")
    if db.execute("SELECT COUNT(*) FROM usuarios").fetchone()[0] >= MAX_USUARIOS:
        return erro("limite de usuários atingido")
    if db.execute("SELECT 1 FROM usuarios WHERE nome=?", (nome,)).fetchone():
        return erro("esse nome já existe")
    sal = secrets.token_hex(16)
    h = await asyncio.to_thread(hash_senha, senha, sal)
    cur = db.execute(
        "INSERT INTO usuarios(nome,senha,sal,cfg,overlay,criado) VALUES(?,?,?,?,?,?)",
        (nome, h, sal, json.dumps(CFG_PADRAO), secrets.token_urlsafe(12), time.time()))
    db.commit()
    criar_sessao(db.execute("SELECT * FROM usuarios WHERE id=?", (cur.lastrowid,)).fetchone())
    return entrar_como(cur.lastrowid)


@app.post("/api/entrar")
async def api_entrar(req: Request):
    d = await req.json()
    r = db.execute("SELECT * FROM usuarios WHERE nome=?", (str(d.get("nome", "")).strip().lower(),)).fetchone()
    await asyncio.sleep(0.8)  # atrapalha tentativas em massa
    if not r:
        return erro("usuário ou senha incorretos", 401)
    h = await asyncio.to_thread(hash_senha, str(d.get("senha", "")), r["sal"])
    if not hmac.compare_digest(h, r["senha"]):
        return erro("usuário ou senha incorretos", 401)
    return entrar_como(r["id"])


@app.post("/api/sair")
async def api_sair(req: Request):
    tok = req.cookies.get("sessao")
    if tok:
        db.execute("DELETE FROM sessoes WHERE token=?", (tok,))
        db.commit()
    return {"ok": True}


@app.get("/api/eu")
async def api_eu(req: Request):
    s = auth(req)
    return {"nome": s.nome, "tiktok": s.tiktok, "cfg": s.cfg, "overlay": s.overlay, "ov": s.ov, "ovm": s.ovm}


@app.post("/api/config")
async def api_config(req: Request):
    s = auth(req)
    d = await req.json()

    def num(k, lo, hi):
        try:
            s.cfg[k] = max(lo, min(hi, int(d.get(k, s.cfg[k]))))
        except (TypeError, ValueError):
            pass

    num("max_duracao", 0, 3600)
    num("max_por_pessoa", 1, 20)
    num("votos_pular", 1, 50)
    for k in ("bloqueadas", "mods"):
        v = d.get(k, s.cfg[k])
        if isinstance(v, str):
            v = v.split(",")
        s.cfg[k] = [x.strip() for x in v if str(x).strip()][:50]
    novo = str(d.get("tiktok", s.tiktok)).strip().lstrip("@")
    if not re.fullmatch(r"[A-Za-z0-9_.]{0,40}", novo):
        return erro("usuário do TikTok inválido")
    mudou = novo != s.tiktok
    s.tiktok = novo
    s.salvar()
    if mudou:
        s.reiniciar_tiktok()
    return {"ok": True, "msg": "salvo"}


# ---------------- páginas ----------------
@app.get("/", response_class=HTMLResponse)
async def painel():
    return HTML_PATH.read_text(encoding="utf-8")


@app.get("/chat", response_class=HTMLResponse)
async def pagina_chat():
    return CHAT_PATH.read_text(encoding="utf-8")


@app.get("/api/eventos")
async def api_eventos(req: Request, desde: int = 0, t: str = ""):
    if t:  # acesso por token (overlay), sem login
        s = next((x for x in SESSOES.values() if x.overlay == t), None)
        if not s:
            return Response(status_code=404)
    else:
        s = auth(req)
    return {"ultimo": s.ev_id, "eventos": [e for e in s.eventos if e["id"] > desde][-120:]}


def _overlay_html():
    return HTMLResponse(OVERLAY_PATH.read_text(encoding="utf-8"), headers={"Cache-Control": "no-store"})


@app.get("/overlay/{token}", response_class=HTMLResponse)
async def overlay(token: str):
    if not re.fullmatch(r"[A-Za-z0-9_-]+", token):
        return Response(status_code=404)
    return _overlay_html()


@app.get("/overlay/{token}/{vista}", response_class=HTMLResponse)
async def overlay_vista(token: str, vista: str):
    """Mesmo token das outras páginas: /overlay/TOKEN/fila e /overlay/TOKEN/historico."""
    if not re.fullmatch(r"[A-Za-z0-9_-]+", token) or vista not in ("agora", "fila", "historico", "unificado", "musicas"):
        return Response(status_code=404)
    if vista == "musicas":
        return HTMLResponse(MUSICAS_PATH.read_text(encoding="utf-8"), headers={"Cache-Control": "no-store"})
    if vista == "unificado":
        return HTMLResponse(UNIFICADO_PATH.read_text(encoding="utf-8"), headers={"Cache-Control": "no-store"})
    return _overlay_html()


@app.get("/api/overlay/{token}")
async def api_overlay(token: str):
    for s in SESSOES.values():
        if s.overlay == token:
            return JSONResponse(s.dados_overlay(), headers={"Cache-Control": "no-store"})
    return Response(status_code=404)


def sessao_por_token(token):
    """Cada token de overlay pertence a UM usuário; só ele (e quem tem o link) vê a fila dele."""
    if not isinstance(token, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", token):
        return None
    for x in SESSOES.values():
        if x.overlay and hmac.compare_digest(x.overlay.encode(), token.encode()):
            return x
    return None


async def fluxo_ovm(s, desconectou):
    """Server-Sent Events do overlay de músicas: só envia quando algo muda (ou a posição sai do previsto)."""
    sig, ult_t, ult_pos, ult_run = None, 0.0, 0.0, False
    ult_envio = 0.0
    while not await desconectou():
        agora = time.time()
        nova = s.assinatura_ovm()
        pos = s.posicao()
        previsto = ult_pos + (agora - ult_t) if ult_run else ult_pos
        if nova != sig or abs(pos - previsto) > 1.5 or agora - ult_envio > 20:
            d = s.dados_ovm()
            sig, ult_t, ult_pos, ult_run, ult_envio = nova, agora, d["pos"], bool(d["tocando"] and not d["pausado"]), agora
            yield f"data: {json.dumps(d, ensure_ascii=False)}\n\n"
        elif agora - ult_envio > 12:
            ult_envio = agora
            yield ": ping\n\n"
        await asyncio.sleep(0.4)


@app.get("/api/overlay-musicas/{token}")
async def api_ovm_snapshot(token: str):
    s = sessao_por_token(token)
    if not s:
        return Response(status_code=404)
    return JSONResponse(s.dados_ovm(), headers={"Cache-Control": "no-store"})


@app.get("/api/overlay-musicas/{token}/stream")
async def api_ovm_stream(token: str, req: Request):
    s = sessao_por_token(token)
    if not s:
        return Response(status_code=404)
    return StreamingResponse(fluxo_ovm(s, req.is_disconnected), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache, no-transform", "X-Accel-Buffering": "no",
                                      "Connection": "keep-alive"})


@app.get("/api/overlay-musicas-config")
async def api_ovm_get(req: Request):
    return auth(req).ovm


@app.post("/api/overlay-musicas-config")
async def api_ovm_set(req: Request):
    s = auth(req)
    try:
        d = await req.json()
    except Exception:
        return erro("dados inválidos")
    s.ovm = limpar_ovm(d, s.ovm)
    db.execute("UPDATE usuarios SET ovmcfg=? WHERE id=?", (json.dumps(s.ovm), s.uid))
    db.commit()
    return {"ok": True, "cfg": s.ovm, "msg": "overlay de músicas salvo"}


@app.get("/api/overlay-config")
async def api_ov_get(req: Request):
    return auth(req).ov


@app.post("/api/overlay-config")
async def api_ov_set(req: Request):
    s = auth(req)
    try:
        d = await req.json()
    except Exception:
        return erro("dados inválidos")
    s.ov = limpar_ov(d, s.ov)
    db.execute("UPDATE usuarios SET ovcfg=? WHERE id=?", (json.dumps(s.ov), s.uid))
    db.commit()
    return {"ok": True, "cfg": s.ov, "msg": "overlay salvo"}


@app.get("/api/stats")
async def api_stats(req: Request):
    s = auth(req)
    q = lambda sql, *a: [dict(r) for r in db.execute(sql, a).fetchall()]
    tot = db.execute("SELECT COALESCE(SUM(tocadas),0) t, COUNT(*) n, COALESCE(SUM(favorita),0) f "
                     "FROM biblioteca WHERE uid=?", (s.uid,)).fetchone()
    return {"tocadas": tot["t"], "biblioteca": tot["n"], "favoritas": tot["f"],
            "top": q("SELECT f.id,f.titulo,f.artista,b.tocadas FROM biblioteca b JOIN faixas f ON f.id=b.vid "
                     "WHERE b.uid=? AND b.tocadas>0 ORDER BY b.tocadas DESC, b.ultima DESC LIMIT 5", s.uid),
            "pedidores": q("SELECT MAX(por) por, COUNT(*) n FROM pedidos WHERE uid=? "
                           "AND tid NOT IN ('painel','autoplay') GROUP BY tid ORDER BY n DESC LIMIT 5", s.uid),
            "recentes": q("SELECT titulo,artista,por,tid,quando FROM pedidos WHERE uid=? ORDER BY id DESC LIMIT 8", s.uid)}


@app.post("/api/posicao")
async def api_posicao(req: Request):
    """O painel (que toca o áudio) informa em que segundo a música está."""
    s = auth(req)
    d = await req.json()
    if d.get("seq") == s.seq and s.tocando:
        try:
            s.pos, s.pos_t = max(0.0, float(d.get("pos", 0))), time.time()
            if d.get("dur"):
                s.pos_dur = int(float(d["dur"]))
        except (TypeError, ValueError):
            pass
    return {"ok": True}


@app.get("/audio/{vid}")
async def audio(vid: str, req: Request):
    auth(req)
    if STREAMING:
        try:
            url, h = await resolver(vid)
        except Exception:
            return Response(status_code=502)
        headers = {k: v for k, v in h.items() if k.lower() in ("user-agent", "accept", "accept-language")}
        if req.headers.get("range"):
            headers["Range"] = req.headers["range"]
        cli = httpx.AsyncClient(timeout=30, follow_redirects=True)
        try:
            up = await cli.send(cli.build_request("GET", url, headers=headers), stream=True)
        except Exception:
            await cli.aclose()
            _urls.pop(vid, None)
            return Response(status_code=502)
        if up.status_code >= 400:
            await up.aclose()
            await cli.aclose()
            _urls.pop(vid, None)
            return Response(status_code=502)
        hdr = {k: up.headers[k] for k in ("content-type", "content-length", "content-range", "accept-ranges")
               if k in up.headers}

        async def gen():
            try:
                async for chunk in up.aiter_raw():
                    yield chunk
            finally:
                await up.aclose()
                await cli.aclose()

        return StreamingResponse(gen(), status_code=up.status_code, headers=hdr)
    r = db.execute("SELECT arquivo FROM faixas WHERE id=?", (vid,)).fetchone()
    if not r or not r["arquivo"] or not Path(r["arquivo"]).exists():
        return Response(status_code=404)
    return FileResponse(r["arquivo"], media_type=MIMES.get(Path(r["arquivo"]).suffix.lower(),
                                                           "application/octet-stream"))


# ---------------- download MANUAL (só quando o usuário clica no botão) ----------------
@app.post("/api/download/iniciar")
async def api_dl_iniciar(req: Request):
    s = auth(req)
    d = await req.json()
    vid = str(d.get("id") or "")
    r = db.execute("SELECT titulo,artista FROM faixas WHERE id=?", (vid,)).fetchone()
    titulo = str(d.get("titulo") or (r["titulo"] if r else ""))[:200]
    artista = str(d.get("artista") or (r["artista"] if r else ""))[:120]
    try:
        token = GER_DL.iniciar(s.uid, vid, titulo, artista)
    except ValueError as e:
        return {"ok": False, "erro": str(e)}
    return {"ok": True, "token": token}


@app.get("/api/download/status/{token}")
async def api_dl_status(token: str, req: Request):
    st = GER_DL.status(auth(req).uid, token)
    return {"ok": True, **st} if st else {"ok": False, "erro": "download não encontrado"}


@app.post("/api/download/cancelar/{token}")
async def api_dl_cancelar(token: str, req: Request):
    return {"ok": GER_DL.descartar(auth(req).uid, token)}


@app.get("/dl/{token}")
async def dl_arquivo(token: str):
    # Sem cookie: quem lê é o código nativo do Android (127.0.0.1). O token é secreto, de uso
    # único e só existe para um download que o próprio usuário pediu.
    r = GER_DL.arquivo(token)
    if not r:
        return Response(status_code=404)
    p, nome = r
    return FileResponse(p, filename=nome, media_type=MIMES.get(p.suffix.lower(), "application/octet-stream"))


@app.post("/dl/{token}/fim")
async def dl_fim(token: str):
    GER_DL.entregue(token)   # o Android já copiou o arquivo: apaga a cópia temporária
    return {"ok": True}


# ---------------- cache antigo (músicas salvas por versões anteriores) ----------------
def _cache_info():
    arqs = [p for p in MUSIC_DIR.glob("*") if p.is_file()] if MUSIC_DIR.exists() else []
    return arqs, sum(p.stat().st_size for p in arqs)


@app.get("/api/cache")
async def api_cache(req: Request):
    auth(req)
    arqs, total = _cache_info()
    return {"ok": True, "streaming": STREAMING, "arquivos": len(arqs), "bytes": total}


@app.post("/api/cache/limpar")
async def api_cache_limpar(req: Request):
    """Apaga só os ARQUIVOS de áudio em cache. Biblioteca, histórico, favoritos e playlists ficam intactos."""
    auth(req)
    em_uso = {x["id"] for s in SESSOES.values() for x in s.fila + ([s.atual] if s.atual else [])} if not STREAMING else set()
    apagados, liberado = 0, 0
    for r in db.execute("SELECT id,arquivo FROM faixas WHERE arquivo IS NOT NULL AND arquivo<>''").fetchall():
        if r["id"] in em_uso:
            continue
        try:
            p = Path(r["arquivo"])
            if p.is_file():
                liberado += p.stat().st_size
                p.unlink()
                apagados += 1
            db.execute("UPDATE faixas SET arquivo='', tamanho=0 WHERE id=?", (r["id"],))
        except Exception as e:
            print(f"(cache) {str(e)[:120]}")
    db.commit()
    arqs, _ = _cache_info()
    for p in arqs:   # arquivos soltos que não estão no banco
        if p.stem in em_uso:
            continue
        try:
            liberado += p.stat().st_size
            p.unlink()
            apagados += 1
        except Exception:
            pass
    return {"ok": True, "apagados": apagados, "bytes": liberado}


# ---------------- API do painel ----------------
@app.get("/api/estado")
async def api_estado(req: Request):
    return auth(req).estado()


@app.post("/api/buscar")
async def api_buscar(req: Request):
    auth(req)
    d = await req.json()
    try:
        return await buscar_auto(str(d.get("q", "")).strip(), 6)
    except Exception:
        return []


@app.post("/api/add")
async def api_add(req: Request):
    s = auth(req)
    try:
        d = await req.json()
        f = {"id": str(d["id"]), "titulo": str(d.get("titulo", ""))[:200],
             "artista": str(d.get("artista", ""))[:100], "duracao": int(d.get("duracao") or 0)}
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,40}", f["id"]):
            raise ValueError
    except Exception:
        return erro("música inválida")
    ok, msg = await s.enfileirar(f)
    s.say(("✅ " if ok else "⛔ ") + msg)
    return {"ok": ok, "msg": msg}


@app.post("/api/pular")
async def api_pular(req: Request):
    return {"ok": await auth(req).pular()}


@app.post("/api/pausa")
async def api_pausa(req: Request):
    return {"ok": auth(req).pausa()}


@app.post("/api/volume")
async def api_volume(req: Request):
    s = auth(req)
    s.definir_volume((await req.json())["v"])
    return {"ok": True}


@app.post("/api/autoplay")
async def api_autoplay(req: Request):
    s = auth(req)
    s.autoplay = bool((await req.json())["on"])
    s.salvar()
    s.acordar.set()
    return {"ok": True}


@app.post("/api/remover")
async def api_remover(req: Request):
    s = auth(req)
    try:
        i = int((await req.json())["i"])
    except Exception:
        return erro("posição inválida")
    if 0 <= i < len(s.fila):
        s.fila.pop(i)
    return {"ok": True}


@app.post("/api/limpar")
async def api_limpar(req: Request):
    auth(req).fila.clear()
    return {"ok": True}


@app.post("/api/terminou")
async def api_terminou(req: Request):
    s = auth(req)
    d = await req.json()
    if d.get("seq") == s.seq and s.evt_fim:
        s.evt_fim.set()
    return {"ok": True}


@app.get("/api/biblioteca")
async def api_biblioteca(req: Request, filtro: str = "historico", q: str = ""):
    s = auth(req)
    sql = ("SELECT f.id,f.titulo,f.artista,f.duracao,b.tocadas,b.favorita FROM biblioteca b "
           "JOIN faixas f ON f.id=b.vid WHERE b.uid=?")
    args = [s.uid]
    ordem = " ORDER BY f.titulo"
    if filtro == "historico":
        sql += " AND b.tocadas>0"
        ordem = " ORDER BY b.ultima DESC"
    elif filtro == "favoritas":
        sql += " AND b.favorita=1"
    if q:
        sql += " AND (f.titulo LIKE ? OR f.artista LIKE ?)"
        args += [f"%{q}%", f"%{q}%"]
    return [dict(r) for r in db.execute(sql + ordem + " LIMIT 300", args).fetchall()]


@app.post("/api/usar")
async def api_usar(req: Request):
    s = auth(req)
    r = db.execute("SELECT * FROM faixas WHERE id=?", ((await req.json())["id"],)).fetchone()
    if not r:
        return {"ok": False}
    ok, msg = await s.enfileirar({"id": r["id"], "titulo": r["titulo"],
                                  "artista": r["artista"], "duracao": r["duracao"]})
    return {"ok": ok, "msg": msg}


@app.post("/api/fav")
async def api_fav(req: Request):
    s = auth(req)
    vid=str((await req.json())["id"])
    db.execute("UPDATE biblioteca SET favorita = 1 - favorita WHERE uid=? AND vid=?", (s.uid, vid))
    state=db.execute("SELECT favorita FROM biblioteca WHERE uid=? AND vid=?",(s.uid,vid)).fetchone()
    if state:
        db.execute("INSERT INTO favorite_changes(uid,vid,is_favorite) VALUES(?,?,?) ON CONFLICT(uid,vid) DO UPDATE SET is_favorite=excluded.is_favorite",(s.uid,vid,int(state["favorita"])))
    db.commit()
    if s.supabase_token:
        try: await api_supabase_sync(req)
        except Exception: pass
    return {"ok": True}


@app.post("/api/importar")
async def api_importar(req: Request):
    s = auth(req)
    d = await req.json()
    if SO_BIBLIOTECA:
        return {"ok": False, "msg": "downloads desativados neste servidor (modo só biblioteca)"}
    if s.imp["rodando"]:
        return {"ok": False, "msg": "já existe uma importação em andamento"}
    try:
        qs = s.parse_importacao(d.get("texto", ""))
    except Exception:
        return {"ok": False, "msg": "não consegui ler o arquivo"}
    if not qs:
        return {"ok": False, "msg": "lista vazia"}
    qs = qs[:500]
    playlist_nome=str(d.get("playlist_nome") or "").strip()[:80]
    playlist_id=None
    if playlist_nome:
        playlist_id=str(uuid.uuid4())
        db.execute("INSERT INTO playlists_local(id,uid,nome,descricao,cover_url,is_public,updated_at) VALUES(?,?,?,?,?,?,?)",
            (playlist_id,s.uid,playlist_nome,"Importada pelo TIKMUSIC","",0,utc_iso()))
        db.commit()
    bg(s.importar(qs, playlist_id))
    return {"ok": True, "msg": f"importando {len(qs)} músicas" + (f" para {playlist_nome}" if playlist_nome else ""), "playlist_id":playlist_id}


async def main():
    MUSIC_DIR.mkdir(exist_ok=True)
    GER_DL.limpar_tudo()   # sobras de downloads interrompidos nunca ficam no armazenamento
    for r in db.execute("SELECT * FROM usuarios").fetchall():
        criar_sessao(r)
    if STREAMING:
        print("Modo streaming: nenhum arquivo de áudio será salvo.")
    if SO_BIBLIOTECA:
        print("Modo só biblioteca: nenhum download novo será feito.")
    if CONVITE == "troque-este-codigo":
        print("⚠️  Defina BOT_CONVITE com um código seu antes de abrir o bot para outras pessoas.")
    print(f"Painel: http://localhost:{PORT}   ({len(SESSOES)} usuário(s) carregado(s))")
    await uvicorn.Server(uvicorn.Config(app, host=HOST, port=PORT, log_level="warning")).serve()


_android_thread = None
_android_server = None

def android_start():
    """Inicia o backend local em uma thread dedicada, chamado pelo serviço Android."""
    global _android_thread
    import threading
    if _android_thread and _android_thread.is_alive():
        return
    def runner():
        try:
            asyncio.run(main())
        except Exception as exc:
            print(f"[Android] Falha ao iniciar backend: {exc}")
    _android_thread = threading.Thread(target=runner, name="BotMusicaLocal", daemon=True)
    _android_thread.start()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass

