# Universal Compiler 2.0 — Windows

## Estrutura
- `input/project.zip`: coloque aqui o projeto que deseja compilar.
- `scripts/build.py`: detector e compilador.
- `.github/workflows/universal-build.yml`: workflow Windows do GitHub Actions.

## Como usar
1. Envie o conteúdo deste pacote para um repositório novo.
2. Coloque o ZIP do projeto em `input/project.zip`.
3. No GitHub, abra Actions e execute **Universal Compiler Windows**.
4. Ao terminar, baixe o artefato `universal-compiler-windows-results`.

## Suporte implementado
Flutter, React Native Android com pasta `android` já existente, Gradle/Android,
Node/Web, Python e CMake.

## Observações
- O workflow usa runner hospedado `windows-latest`; a fila do GitHub ainda depende da disponibilidade e dos limites da conta.
- A compilação Android depende das versões de SDK/Gradle exigidas pelo projeto.
- Projetos React Native que precisam gerar a pasta `android` via Expo/prebuild exigem configuração adicional.
- IPA/iOS não pode ser compilado em runner Windows.
- O compilador coleta APK/AAB e alguns outros artefatos; nem todo projeto gera todos esses formatos.
